import { AsyncLocalStorage } from 'async_hooks';

export interface TenantContextData {
  tenantId: string;
  userId: string;
  correlationId: string;
  roles: string[];
}

export class TenantContext {
  private static storage = new AsyncLocalStorage<TenantContextData>();

  static run(data: TenantContextData, callback: () => void) {
    this.storage.run(data, callback);
  }

  static get(): TenantContextData {
    const store = this.storage.getStore();
    if (!store) {
      throw new Error('TenantContext is not initialized. Ensure TenantGuard is applied.');
    }
    return store;
  }

  static getTenantId(): string {
    return this.get().tenantId;
  }

  static getUserId(): string {
    return this.get().userId;
  }

  static getCorrelationId(): string {
    return this.get().correlationId;
  }

  static getRoles(): string[] {
    return this.get().roles;
  }
}
