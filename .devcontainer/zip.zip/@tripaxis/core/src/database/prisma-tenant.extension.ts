import { PrismaClient } from '@prisma/client';
import { TenantContext } from '../context/tenant.context';

export function withTenantContext(prisma: PrismaClient) {
  return prisma.$extends({
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          let tenantId: string;
          try {
            tenantId = TenantContext.getTenantId();
          } catch {
            // Fallback if executed outside of request context (e.g., system cron jobs)
            return query(args);
          }

          return prisma.$transaction(async (tx) => {
            // 1. Enforce RLS via PostgreSQL session variables
            await tx.$executeRawUnsafe(`SELECT set_config('app.current_tenant_id', '${tenantId}', true);`);
            
            // 2. Auto-filter soft deleted records
            if (args.where) {
              args.where = { ...args.where, deletedAt: null };
            } else {
              args.where = { deletedAt: null };
            }

            return query(args);
          });
        },
      },
    },
  });
}
