export class ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
  };

  static success<T>(data: T): ApiResponse<T> {
    return { success: true, data };
  }

  static failure(code: string, message: string): ApiResponse<any> {
    return { success: false, error: { code, message } };
  }
}
