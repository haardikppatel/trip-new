export class DomainError extends Error {
  constructor(public readonly code: string, message: string) {
    super(message);
    this.name = 'DomainError';
  }
}

export class PolicyViolationError extends DomainError {
  constructor(message: string) {
    super('POLICY_VIOLATION', message);
  }
}

export class ResourceNotFoundError extends DomainError {
  constructor(resource: string, id: string) {
    super('NOT_FOUND', `${resource} with ID ${id} not found`);
  }
}

export class InvalidStateTransitionError extends DomainError {
  constructor(current: string, target: string) {
    super('INVALID_STATE_TRANSITION', `Cannot transition from ${current} to ${target}`);
  }
}
