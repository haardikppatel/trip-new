import { Injectable, LoggerService } from '@nestjs/common';
import { trace, context } from '@opentelemetry/api';

@Injectable()
export class TelemetryLogger implements LoggerService {
  log(message: any, contextName?: string) {
    this.print('INFO', message, contextName);
  }

  error(message: any, traceStr?: string, contextName?: string) {
    this.print('ERROR', message, contextName, traceStr);
  }

  warn(message: any, contextName?: string) {
    this.print('WARN', message, contextName);
  }

  debug?(message: any, contextName?: string) {
    this.print('DEBUG', message, contextName);
  }

  verbose?(message: any, contextName?: string) {
    this.print('VERBOSE', message, contextName);
  }

  private print(level: string, message: any, contextName?: string, traceStr?: string) {
    const span = trace.getSpan(context.active());
    const traceId = span ? span.spanContext().traceId : 'no-trace-id';
    
    const logObj = {
      timestamp: new Date().toISOString(),
      level,
      traceId,
      context: contextName,
      message,
      ...(traceStr ? { stack: traceStr } : {}),
    };

    // In production, this would pipe to stdout for FluentBit/Loki to scrape
    console.log(JSON.stringify(logObj));
  }
}
