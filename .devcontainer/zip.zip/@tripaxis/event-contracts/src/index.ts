import { z } from 'zod';
import { v4 as uuidv4 } from 'uuid';

// Base Event Wrapper
export const BaseEventSchema = z.object({
  eventId: z.string().uuid(),
  correlationId: z.string().uuid(),
  tenantId: z.string().uuid(),
  timestamp: z.string().datetime(),
  version: z.string(),
});

// 1. Travel Request Approved (v1)
export const TravelRequestApprovedV1Schema = BaseEventSchema.extend({
  eventType: z.literal('TravelRequestApproved:v1'),
  payload: z.object({
    travelRequestId: z.string().uuid(),
    employeeId: z.string().uuid(),
    destination: z.string(),
    startDate: z.string().datetime(),
    endDate: z.string().datetime(),
    budget: z.number(),
    currency: z.string().length(3),
  }),
});
export type TravelRequestApprovedV1 = z.infer<typeof TravelRequestApprovedV1Schema>;

// 2. Booking Confirmed (v1)
export const BookingConfirmedV1Schema = BaseEventSchema.extend({
  eventType: z.literal('BookingConfirmed:v1'),
  payload: z.object({
    travelRequestId: z.string().uuid(),
    bookingReference: z.string(),
    provider: z.string(),
    totalCost: z.number(),
    currency: z.string().length(3),
  }),
});
export type BookingConfirmedV1 = z.infer<typeof BookingConfirmedV1Schema>;

// Typed Publisher Interface
export interface IEventPublisher {
  publish<T extends z.infer<typeof BaseEventSchema>>(event: T): Promise<void>;
}

// Typed Consumer Interface
export interface IEventConsumer<T extends z.infer<typeof BaseEventSchema>> {
  handle(event: T): Promise<void>;
}

// Helper to create standardized events
export function createEvent<T>(
  eventType: string,
  version: string,
  tenantId: string,
  correlationId: string,
  payload: T
) {
  return {
    eventId: uuidv4(),
    correlationId,
    tenantId,
    timestamp: new Date().toISOString(),
    version,
    eventType: `${eventType}:${version}`,
    payload,
  };
}
