# Event Schema Migration Strategy (v1 to v2)

In a distributed microservices architecture, breaking changes to event schemas must be handled gracefully to ensure zero downtime. TripAxis uses a **Concurrent Versioning Strategy (Upcasting)**.

## Scenario
We need to upgrade `tripaxis.travel.submitted.v1` to `v2`.
* **v1 payload:** `{ "total_budget": 1000, "currency": "USD" }`
* **v2 payload:** `{ "budget": { "amount": 1000, "currency": "USD" }, "is_billable": true }`

## Step-by-Step Migration

### Phase 1: Consumer Preparation (Upcasting)
1. Update the `@tripaxis/events` shared library to include the `v2` Zod schema.
2. Update the Consumer services (e.g., Notification Service, Approval Service) to bind to **both** routing keys:
   - `tripaxis.travel.submitted.v1`
   - `tripaxis.travel.submitted.v2`
3. Implement an **Upcaster** in the consumer. If a `v1` event is received, map it to the `v2` shape in memory before passing it to the business logic handler.

```typescript
// Consumer Adapter Example
async function handleTravelSubmitted(rawEvent: any) {
  let eventV2: ITravelSubmittedEventV2;

  if (rawEvent.version === 'v1') {
    // Upcast v1 to v2
    const v1 = TravelSubmittedEventV1.parse(rawEvent);
    eventV2 = {
      ...v1,
      version: 'v2',
      payload: {
        budget: { amount: v1.payload.total_budget, currency: v1.payload.currency },
        is_billable: false, // Default fallback
      }
    };
  } else {
    eventV2 = TravelSubmittedEventV2.parse(rawEvent);
  }

  await processBusinessLogic(eventV2);
}
```

### Phase 2: Producer Rollout
1. Update the Travel Service (Producer) to publish `tripaxis.travel.submitted.v2`.
2. Deploy the Travel Service.
3. At this point, Consumers are seamlessly handling the new `v2` events, while still being capable of processing any lingering `v1` events in the queue or DLQ.

### Phase 3: Cleanup (Deprecation)
1. Monitor OpenTelemetry/Prometheus metrics to ensure `v1` events are no longer being produced.
2. Remove the `v1` schema from `@tripaxis/events`.
3. Remove the Upcaster logic and the `v1` routing key binding from the Consumers.
4. Deploy the cleaned-up Consumers.
