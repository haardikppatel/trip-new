import * as amqp from 'amqplib';
import { trace, context, propagation, SpanKind } from '@opentelemetry/api';
import { ZodSchema } from 'zod';

export interface ConsumerOptions {
  queueName: string;
  routingKeys: string[];
  maxRetries?: number;
}

export class EventConsumer {
  private channel: amqp.Channel;
  private readonly exchange = 'tripaxis.events.topic';
  private readonly dlxExchange = 'tripaxis.dlx.topic';
  private readonly retryExchange = 'tripaxis.retry.topic';

  constructor(private readonly connection: amqp.Connection) {}

  async init(options: ConsumerOptions) {
    this.channel = await this.connection.createChannel();
    await this.channel.prefetch(10); // Fair dispatch

    // 1. Setup Dead Letter Exchange (DLX)
    await this.channel.assertExchange(this.dlxExchange, 'topic', { durable: true });
    await this.channel.assertQueue('tripaxis.dlq', { durable: true });
    await this.channel.bindQueue('tripaxis.dlq', this.dlxExchange, '#');

    // 2. Setup Retry Exchange (Delayed via TTL)
    await this.channel.assertExchange(this.retryExchange, 'topic', { durable: true });
    const retryQueue = `${options.queueName}.retry`;
    await this.channel.assertQueue(retryQueue, {
      durable: true,
      deadLetterExchange: this.exchange, // Route back to main exchange after TTL
      messageTtl: 5000, // 5 seconds exponential backoff base
    });
    await this.channel.bindQueue(retryQueue, this.retryExchange, '#');

    // 3. Setup Main Queue
    await this.channel.assertExchange(this.exchange, 'topic', { durable: true });
    await this.channel.assertQueue(options.queueName, {
      durable: true,
      deadLetterExchange: this.dlxExchange, // If rejected without requeue, goes to DLQ
    });

    for (const rk of options.routingKeys) {
      await this.channel.bindQueue(options.queueName, this.exchange, rk);
    }
  }

  async consume<T>(
    queueName: string,
    schema: ZodSchema<T>,
    handler: (event: T) => Promise<void>,
    maxRetries = 3
  ) {
    const tracer = trace.getTracer('tripaxis-event-consumer');

    await this.channel.consume(queueName, async (msg) => {
      if (!msg) return;

      // Extract OTel Context from headers
      const parentContext = propagation.extract(context.active(), msg.properties.headers || {});
      
      await tracer.startActiveSpan(
        `consume ${msg.fields.routingKey}`,
        { kind: SpanKind.CONSUMER },
        parentContext,
        async (span) => {
          try {
            const rawContent = JSON.parse(msg.content.toString());
            
            // Validate payload against Zod schema
            const event = schema.parse(rawContent);

            // Execute business logic
            await handler(event);

            this.channel.ack(msg);
            span.setAttribute('messaging.consume.status', 'success');
          } catch (error: any) {
            span.recordException(error);
            span.setAttribute('messaging.consume.status', 'failure');
            
            await this.handleFailure(msg, queueName, maxRetries);
          } finally {
            span.end();
          }
        }
      );
    });
  }

  private async handleFailure(msg: amqp.ConsumeMessage, queueName: string, maxRetries: number) {
    const headers = msg.properties.headers || {};
    const deathHeader = headers['x-death'];
    const retryCount = deathHeader ? deathHeader[0].count : 0;

    if (retryCount >= maxRetries) {
      // Exceeded retries, send to DLQ
      console.error(`[DLQ] Message ${msg.properties.messageId} failed after ${maxRetries} retries.`);
      this.channel.reject(msg, false); // false = don't requeue, route to DLX
    } else {
      // Send to Retry Exchange
      console.warn(`[RETRY] Message ${msg.properties.messageId} failed. Attempt ${retryCount + 1}/${maxRetries}`);
      this.channel.ack(msg); // Ack from main queue
      this.channel.publish(this.retryExchange, msg.fields.routingKey, msg.content, {
        ...msg.properties,
        headers: { ...headers, 'x-retry-count': retryCount + 1 }
      });
    }
  }
}
