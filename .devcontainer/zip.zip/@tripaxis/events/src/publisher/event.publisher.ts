import * as amqp from 'amqplib';
import { trace, context, propagation } from '@opentelemetry/api';
import { BaseEvent, getRoutingKey } from '../schemas/event.schema';

export class EventPublisher {
  private channel: amqp.Channel;
  private readonly exchange = 'tripaxis.events.topic';

  constructor(private readonly connection: amqp.Connection) {}

  async init() {
    this.channel = await this.connection.createChannel();
    // Ensure the main topic exchange exists
    await this.channel.assertExchange(this.exchange, 'topic', { durable: true });
  }

  async publish<T extends BaseEvent>(event: T): Promise<boolean> {
    const routingKey = getRoutingKey(event);
    const payloadBuffer = Buffer.from(JSON.stringify(event));

    // 4. OpenTelemetry Tracing Propagation
    const headers: Record<string, unknown> = {};
    propagation.inject(context.active(), headers);

    const tracer = trace.getTracer('tripaxis-event-publisher');
    return tracer.startActiveSpan(`publish ${routingKey}`, (span) => {
      try {
        const published = this.channel.publish(this.exchange, routingKey, payloadBuffer, {
          persistent: true,
          messageId: event.event_id,
          timestamp: new Date(event.timestamp).getTime(),
          correlationId: event.correlation_id,
          appId: 'tripaxis-publisher',
          headers: {
            ...headers,
            'x-tenant-id': event.tenant_id,
          },
        });

        span.setAttribute('messaging.system', 'rabbitmq');
        span.setAttribute('messaging.destination', this.exchange);
        span.setAttribute('messaging.destination_kind', 'topic');
        span.setAttribute('messaging.rabbitmq.routing_key', routingKey);
        
        return published;
      } catch (error: any) {
        span.recordException(error);
        throw error;
      } finally {
        span.end();
      }
    });
  }
}
