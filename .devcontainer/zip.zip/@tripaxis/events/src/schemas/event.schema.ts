import { z } from 'zod';

// 1. Base Event Schema Definition
export const BaseEventSchema = z.object({
  event_id: z.string().uuid(),
  timestamp: z.string().datetime(),
  tenant_id: z.string().uuid(),
  actor_id: z.string(),
  correlation_id: z.string().uuid(),
  domain: z.string(),
  action: z.string(),
  version: z.string(),
  payload: z.record(z.any()),
});

export type BaseEvent = z.infer<typeof BaseEventSchema>;

// 2. Specific Domain Event: Travel Submitted v1
export const TravelSubmittedPayloadV1 = z.object({
  travel_request_id: z.string().uuid(),
  total_budget: z.number().positive(),
  currency: z.string().length(3),
  destination: z.string(),
});

export const TravelSubmittedEventV1 = BaseEventSchema.extend({
  domain: z.literal('travel'),
  action: z.literal('submitted'),
  version: z.literal('v1'),
  payload: TravelSubmittedPayloadV1,
});

export type ITravelSubmittedEventV1 = z.infer<typeof TravelSubmittedEventV1>;

// 3. Specific Domain Event: Workflow Escalated v1
export const WorkflowEscalatedPayloadV1 = z.object({
  task_id: z.string().uuid(),
  escalation_level: z.number().int().nonnegative(),
  new_assignee_id: z.string(),
});

export const WorkflowEscalatedEventV1 = BaseEventSchema.extend({
  domain: z.literal('workflow'),
  action: z.literal('escalated'),
  version: z.literal('v1'),
  payload: WorkflowEscalatedPayloadV1,
});

export type IWorkflowEscalatedEventV1 = z.infer<typeof WorkflowEscalatedEventV1>;

// 4. Helper to generate routing key
export const getRoutingKey = (event: BaseEvent): string => {
  return `tripaxis.${event.domain}.${event.action}.${event.version}`;
};
