import { Injectable } from '@nestjs/common';

export interface ResolutionContext {
  requesterId: string;
  departmentId?: string;
  amount?: number;
  tenantId: string;
}

@Injectable()
export class ApprovalResolutionEngine {
  /**
   * Dynamically resolves the user IDs of the approvers based on the template rules.
   * In a real system, this would call the User/Directory service via gRPC or internal API.
   */
  async resolveApprovers(rule: any, context: ResolutionContext): Promise<string[]> {
    const { type, role, levels } = rule;

    switch (type) {
      case 'MANAGER':
        // Mock: Fetch manager of requester up to `levels` deep
        return [`manager-of-${context.requesterId}`];
      
      case 'ROLE':
        // Mock: Fetch users with specific role in the tenant/department
        return [`user-with-role-${role}`];
      
      case 'SPECIFIC_USER':
        return [rule.userId];

      case 'DEPARTMENT_HEAD':
        return [`head-of-${context.departmentId}`];

      default:
        throw new Error(`Unknown approver resolution type: ${type}`);
    }
  }

  /**
   * Evaluates if a step should be executed based on its conditions.
   */
  evaluateConditions(conditions: any, context: ResolutionContext): boolean {
    if (!conditions) return true;

    if (conditions.minAmount && context.amount !== undefined) {
      if (context.amount < conditions.minAmount) return false;
    }

    if (conditions.departmentId && context.departmentId) {
      if (context.departmentId !== conditions.departmentId) return false;
    }

    return true;
  }
}
