import { ApprovalState } from '@prisma/client';
import { InvalidStateTransitionError } from '@tripaxis/core';

export class ApprovalStateMachine {
  private static readonly transitions: Record<ApprovalState, ApprovalState[]> = {
    [ApprovalState.PENDING]: [
      ApprovalState.APPROVED,
      ApprovalState.REJECTED,
      ApprovalState.ESCALATED,
      ApprovalState.CANCELLED,
    ],
    [ApprovalState.ESCALATED]: [
      ApprovalState.APPROVED,
      ApprovalState.REJECTED,
      ApprovalState.CANCELLED,
    ],
    [ApprovalState.APPROVED]: [],
    [ApprovalState.REJECTED]: [],
    [ApprovalState.CANCELLED]: [],
  };

  static validateTransition(current: ApprovalState, next: ApprovalState): void {
    const allowed = this.transitions[current];
    if (!allowed.includes(next)) {
      throw new InvalidStateTransitionError(current, next);
    }
  }

  static isTerminal(state: ApprovalState): boolean {
    return [ApprovalState.APPROVED, ApprovalState.REJECTED, ApprovalState.CANCELLED].includes(state);
  }
}
