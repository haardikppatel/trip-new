import { Injectable, Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { TenantContext } from '@tripaxis/core';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class EventPublisher {
  constructor(@Inject('RABBITMQ_SERVICE') private readonly client: ClientProxy) {}

  async publish(eventType: string, payload: any): Promise<void> {
    // Fallback for system-level events (like SLA processor) where context might not exist
    let tenantId = payload.tenantId;
    let correlationId = uuidv4();
    
    try {
      tenantId = tenantId || TenantContext.getTenantId();
      correlationId = TenantContext.getCorrelationId() || correlationId;
    } catch (e) {
      // Running outside request context (e.g., BullMQ worker)
    }

    const event = {
      eventId: uuidv4(),
      correlationId,
      tenantId,
      timestamp: new Date().toISOString(),
      eventType,
      payload,
    };

    // 8. Every decision generates a RabbitMQ event (which triggers Notification Service)
    this.client.emit(eventType, event);
  }
}
