import { Controller, Post, Body, Param, Headers, UseGuards } from '@nestjs/common';
import { ApprovalService } from './approval.service';
import { ApiResponse, TenantContext } from '@tripaxis/core';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { ApprovalState } from '@prisma/client';

@UseGuards(TenantGuard)
@Controller('v1/approvals')
export class ApprovalController {
  constructor(private readonly approvalService: ApprovalService) {}

  @Post('start')
  async startWorkflow(@Body() dto: { entityType: string; entityId: string; contextData: any }) {
    const result = await this.approvalService.startWorkflow(dto.entityType, dto.entityId, dto.contextData);
    return ApiResponse.success(result);
  }

  @Post('tasks/:id/approve')
  async approveTask(
    @Param('id') taskId: string, 
    @Body() dto: { comments?: string; attachments?: any },
    @Headers('x-idempotency-key') idempotencyKey?: string
  ) {
    const result = await this.approvalService.processTask(taskId, ApprovalState.APPROVED, dto.comments, dto.attachments, idempotencyKey);
    return ApiResponse.success(result);
  }

  @Post('tasks/:id/reject')
  async rejectTask(
    @Param('id') taskId: string, 
    @Body() dto: { comments: string; attachments?: any },
    @Headers('x-idempotency-key') idempotencyKey?: string
  ) {
    const result = await this.approvalService.processTask(taskId, ApprovalState.REJECTED, dto.comments, dto.attachments, idempotencyKey);
    return ApiResponse.success(result);
  }

  @Post('tasks/:id/delegate')
  async delegateTask(@Param('id') taskId: string, @Body('delegateToId') delegateToId: string) {
    const result = await this.approvalService.delegateTask(taskId, delegateToId);
    return ApiResponse.success(result);
  }
}
