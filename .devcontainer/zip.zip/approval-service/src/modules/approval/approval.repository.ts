import { Injectable, Inject } from '@nestjs/common';
import { PrismaClient, ApprovalState } from '@prisma/client';

@Injectable()
export class ApprovalRepository {
  constructor(@Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient) {}

  async findTemplate(tenantId: string, entityType: string) {
    return this.prisma.approvalTemplate.findFirst({
      where: { tenantId, entityType, isActive: true },
      include: { steps: { orderBy: { stepOrder: 'asc' } } },
    });
  }

  async createInstance(tx: any, data: any) {
    return tx.approvalInstance.create({
      data,
      include: { tasks: true },
    });
  }

  async findTaskById(tenantId: string, taskId: string) {
    return this.prisma.approvalTask.findUnique({
      where: { id: taskId, tenantId },
      include: { instance: true },
    });
  }

  async updateTaskStatus(tx: any, taskId: string, status: ApprovalState, comments?: string, attachments?: any) {
    return tx.approvalTask.update({
      where: { id: taskId },
      data: { status, comments, attachments, completedAt: new Date() },
    });
  }

  async updateInstanceStatus(tx: any, instanceId: string, status: ApprovalState) {
    return tx.approvalInstance.update({
      where: { id: instanceId },
      data: { status },
    });
  }

  async logAudit(tx: any, data: any) {
    return tx.approvalAuditLog.create({ data });
  }

  async getPendingTasksForInstanceStep(tx: any, instanceId: string, stepOrder: number) {
    return tx.approvalTask.findMany({
      where: { instanceId, stepOrder, status: ApprovalState.PENDING },
    });
  }
}
