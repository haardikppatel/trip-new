import { Injectable, NotFoundException, ConflictException, Inject } from '@nestjs/common';
import { ApprovalRepository } from './approval.repository';
import { ApprovalResolutionEngine } from '../../domain/approval-resolution.engine';
import { ApprovalStateMachine } from '../../domain/approval-state-machine';
import { EventPublisher } from '../../infrastructure/events/event.publisher';
import { TenantContext } from '@tripaxis/core';
import { ApprovalState } from '@prisma/client';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { Redis } from 'ioredis';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class ApprovalService {
  constructor(
    private readonly repository: ApprovalRepository,
    private readonly resolutionEngine: ApprovalResolutionEngine,
    private readonly eventPublisher: EventPublisher,
    @InjectQueue('approval-sla') private readonly slaQueue: Queue,
    @Inject('REDIS_CLIENT') private readonly redis: Redis,
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
  ) {}

  async startApprovalWorkflow(entityType: string, entityId: string, contextData: any) {
    const tenantId = TenantContext.getTenantId();
    const requesterId = TenantContext.getUserId();

    const template = await this.repository.findTemplate(tenantId, entityType);
    if (!template) throw new NotFoundException(`No active approval template for ${entityType}`);

    // Filter valid steps based on conditions (e.g., amount thresholds)
    const validSteps = template.steps.filter(step => 
      this.resolutionEngine.evaluateConditions(step.conditions, { ...contextData, requesterId, tenantId })
    );

    if (validSteps.length === 0) {
      // Auto-approve if no steps apply
      await this.eventPublisher.publish('ApprovalInstanceCompleted:v1', { entityId, entityType, status: ApprovalState.APPROVED });
      return { status: ApprovalState.APPROVED, autoApproved: true };
    }

    const instance = await this.prisma.$transaction(async (tx) => {
      const inst = await this.repository.createInstance(tx, {
        tenantId,
        templateId: template.id,
        entityId,
        entityType,
        requesterId,
        contextData,
        status: ApprovalState.PENDING,
      });

      // Initialize first step
      await this.initializeStep(tx, inst.id, validSteps[0], contextData);
      
      await this.repository.logAudit(tx, {
        tenantId,
        instanceId: inst.id,
        action: 'CREATED',
        actorId: requesterId,
      });

      return inst;
    });

    return instance;
  }

  private async initializeStep(tx: any, instanceId: string, stepTemplate: any, contextData: any) {
    const tenantId = TenantContext.getTenantId();
    
    await tx.approvalStepInstance.create({
      data: { instanceId, tenantId, stepOrder: stepTemplate.stepOrder, status: ApprovalState.PENDING }
    });

    const approvers = await this.resolutionEngine.resolveApprovers(stepTemplate.approverResolution, { ...contextData, tenantId });

    for (const approverId of approvers) {
      const dueDate = stepTemplate.slaMinutes ? new Date(Date.now() + stepTemplate.slaMinutes * 60000) : null;
      
      const task = await tx.approvalTask.create({
        data: {
          instanceId,
          tenantId,
          stepOrder: stepTemplate.stepOrder,
          assigneeId: approverId,
          dueDate,
        }
      });

      // 6. Auto-escalation via BullMQ scheduled jobs
      if (stepTemplate.slaMinutes) {
        await this.slaQueue.add('check-sla', { taskId: task.id, tenantId }, { delay: stepTemplate.slaMinutes * 60000 });
      }

      await this.eventPublisher.publish('ApprovalTaskCreated:v1', { taskId: task.id, assigneeId: approverId, entityId: contextData.entityId });
    }
  }

  async processTask(taskId: string, action: ApprovalState, comments?: string, attachments?: any, idempotencyKey?: string) {
    const tenantId = TenantContext.getTenantId();
    const actorId = TenantContext.getUserId();

    // 10. Idempotency enforcement
    if (idempotencyKey) {
      const lockKey = `approval:lock:${tenantId}:${idempotencyKey}`;
      const acquired = await this.redis.set(lockKey, 'LOCKED', 'NX', 'EX', 3600);
      if (!acquired) throw new ConflictException('Idempotent request already processed');
    }

    const task = await this.repository.findTaskById(tenantId, taskId);
    if (!task) throw new NotFoundException('Task not found');
    
    // Ensure actor is assignee or delegate
    if (task.assigneeId !== actorId && task.delegatedToId !== actorId) {
      throw new ConflictException('You are not authorized to process this task');
    }

    ApprovalStateMachine.validateTransition(task.status, action);

    await this.prisma.$transaction(async (tx) => {
      await this.repository.updateTaskStatus(tx, taskId, action, comments, attachments);
      
      await this.repository.logAudit(tx, {
        tenantId,
        instanceId: task.instanceId,
        taskId,
        action: action.toString(),
        actorId,
        details: { comments, attachments }
      });

      // Check step completion logic
      if (action === ApprovalState.REJECTED) {
        await this.repository.updateInstanceStatus(tx, task.instanceId, ApprovalState.REJECTED);
        await this.eventPublisher.publish('ApprovalInstanceRejected:v1', { entityId: task.instance.entityId, entityType: task.instance.entityType });
      } else if (action === ApprovalState.APPROVED) {
        const pendingTasks = await this.repository.getPendingTasksForInstanceStep(tx, task.instanceId, task.stepOrder);
        
        // If all required approvals for this step are met (simplified to all tasks completed for now)
        if (pendingTasks.length === 0) {
          // Move to next step or complete instance
          const template = await tx.approvalTemplate.findUnique({ where: { id: task.instance.templateId }, include: { steps: { orderBy: { stepOrder: 'asc' } } } });
          const nextStep = template.steps.find((s: any) => s.stepOrder > task.stepOrder);

          if (nextStep) {
            await this.initializeStep(tx, task.instanceId, nextStep, task.instance.contextData);
          } else {
            await this.repository.updateInstanceStatus(tx, task.instanceId, ApprovalState.APPROVED);
            await this.eventPublisher.publish('ApprovalInstanceCompleted:v1', { entityId: task.instance.entityId, entityType: task.instance.entityType, status: ApprovalState.APPROVED });
          }
        }
      }
    });

    return { success: true, taskId, action };
  }

  async delegateTask(taskId: string, delegateToId: string) {
    const tenantId = TenantContext.getTenantId();
    const actorId = TenantContext.getUserId();

    const task = await this.repository.findTaskById(tenantId, taskId);
    if (!task || task.assigneeId !== actorId) throw new ConflictException('Cannot delegate this task');

    await this.prisma.$transaction(async (tx) => {
      await tx.approvalTask.update({
        where: { id: taskId },
        data: { delegatedToId: delegateToId }
      });
      await this.repository.logAudit(tx, {
        tenantId,
        instanceId: task.instanceId,
        taskId,
        action: 'DELEGATED',
        actorId,
        details: { delegateToId }
      });
    });

    await this.eventPublisher.publish('ApprovalTaskDelegated:v1', { taskId, delegateToId });
    return { success: true };
  }
}
