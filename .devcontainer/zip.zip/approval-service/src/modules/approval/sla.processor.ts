import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { Injectable, Inject } from '@nestjs/common';
import { PrismaClient, ApprovalState } from '@prisma/client';
import { EventPublisher } from '../../infrastructure/events/event.publisher';

@Processor('approval-sla')
@Injectable()
export class SlaProcessor extends WorkerHost {
  constructor(
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
    private readonly eventPublisher: EventPublisher,
  ) {
    super();
  }

  async process(job: Job<{ taskId: string; tenantId: string }>): Promise<any> {
    const { taskId, tenantId } = job.data;

    await this.prisma.$transaction(async (tx) => {
      const task = await tx.approvalTask.findUnique({
        where: { id: taskId, tenantId },
        include: { instance: true }
      });

      if (!task || task.status !== ApprovalState.PENDING) {
        return; // Task already processed or cancelled
      }

      // 6. Auto-escalation logic
      // Mark current task as ESCALATED
      await tx.approvalTask.update({
        where: { id: taskId },
        data: { status: ApprovalState.ESCALATED }
      });

      // Log audit
      await tx.approvalAuditLog.create({
        data: {
          tenantId,
          instanceId: task.instanceId,
          taskId,
          action: 'ESCALATED',
          actorId: 'SYSTEM',
          details: { reason: 'SLA breached' }
        }
      });

      // Fetch step template to find escalation target
      const stepInstance = await tx.approvalStepInstance.findFirst({
        where: { instanceId: task.instanceId, stepOrder: task.stepOrder }
      });

      const stepTemplate = await tx.approvalStepTemplate.findFirst({
        where: { templateId: task.instance.templateId, stepOrder: task.stepOrder }
      });

      if (stepTemplate?.escalationTarget) {
        // Create new task for escalation target
        const targetId = stepTemplate.escalationTarget.userId || 'escalation-manager-id'; // Mock resolution
        
        const escalatedTask = await tx.approvalTask.create({
          data: {
            instanceId: task.instanceId,
            tenantId,
            stepOrder: task.stepOrder,
            assigneeId: targetId,
          }
        });

        await this.eventPublisher.publish('ApprovalTaskEscalated:v1', { 
          originalTaskId: taskId, 
          newTaskAssignee: targetId,
          entityId: task.instance.entityId 
        });
      }
    });
  }
}
