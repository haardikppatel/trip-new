import { Test, TestingModule } from '@nestjs/testing';
import { ApprovalService } from '../src/modules/approval/approval.service';
import { ApprovalRepository } from '../src/modules/approval/approval.repository';
import { ApprovalResolutionEngine } from '../src/domain/approval-resolution.engine';
import { EventPublisher } from '../src/infrastructure/events/event.publisher';
import { TenantContext } from '@tripaxis/core';
import { ApprovalState } from '@prisma/client';
import { ConflictException } from '@nestjs/common';

describe('ApprovalService', () => {
  let service: ApprovalService;
  let repository: ApprovalRepository;
  let eventPublisher: EventPublisher;
  let redisMock: any;

  beforeEach(async () => {
    redisMock = { set: jest.fn() };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ApprovalService,
        ApprovalResolutionEngine,
        {
          provide: ApprovalRepository,
          useValue: {
            findTaskById: jest.fn(),
            updateTaskStatus: jest.fn(),
            updateInstanceStatus: jest.fn(),
            logAudit: jest.fn(),
            getPendingTasksForInstanceStep: jest.fn().mockResolvedValue([]),
          },
        },
        { provide: EventPublisher, useValue: { publish: jest.fn() } },
        { provide: 'BullQueue_approval-sla', useValue: { add: jest.fn() } },
        { provide: 'REDIS_CLIENT', useValue: redisMock },
        { provide: 'PRISMA_CLIENT', useValue: { $transaction: jest.fn(cb => cb({ approvalTemplate: { findUnique: jest.fn().mockResolvedValue({ steps: [] }) } })) } },
      ],
    }).compile();

    service = module.get<ApprovalService>(ApprovalService);
    repository = module.get<ApprovalRepository>(ApprovalRepository);
    eventPublisher = module.get<EventPublisher>(EventPublisher);

    jest.spyOn(TenantContext, 'getTenantId').mockReturnValue('tenant-1');
    jest.spyOn(TenantContext, 'getUserId').mockReturnValue('user-1');
  });

  it('should enforce idempotency on processTask', async () => {
    redisMock.set.mockResolvedValue(null); // Lock not acquired

    await expect(service.processTask('task-1', ApprovalState.APPROVED, '', null, 'idemp-key-1'))
      .rejects.toThrow(ConflictException);
  });

  it('should process task and emit events', async () => {
    redisMock.set.mockResolvedValue('OK'); // Lock acquired
    
    const mockTask = {
      id: 'task-1',
      assigneeId: 'user-1',
      status: ApprovalState.PENDING,
      stepOrder: 1,
      instanceId: 'inst-1',
      instance: { entityId: 'ent-1', entityType: 'TRAVEL' }
    };

    jest.spyOn(repository, 'findTaskById').mockResolvedValue(mockTask as any);

    const result = await service.processTask('task-1', ApprovalState.APPROVED, 'Looks good', null, 'idemp-key-2');

    expect(result.success).toBe(true);
    expect(repository.updateTaskStatus).toHaveBeenCalledWith(expect.anything(), 'task-1', ApprovalState.APPROVED, 'Looks good', null);
    expect(repository.logAudit).toHaveBeenCalled();
    expect(eventPublisher.publish).toHaveBeenCalledWith('ApprovalInstanceCompleted:v1', expect.any(Object));
  });
});
