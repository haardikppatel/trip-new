import { Injectable, UnauthorizedException, ForbiddenException, Inject } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../prisma/prisma.service';
import { Redis } from 'ioredis';
import * as bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { LoginDto } from '../dto/auth.dto';

@Injectable()
export class AuthService {
  private readonly MAX_FAILED_ATTEMPTS = 5;
  private readonly LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 mins

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    @Inject('REDIS_CLIENT') private readonly redis: Redis,
  ) {}

  async login(dto: LoginDto, ipAddress: string, userAgent: string) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: {
        tenants: true,
        roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } }
      }
    });

    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (!user.isActive) {
      throw new ForbiddenException('Account is disabled');
    }

    if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
      throw new UnauthorizedException('Account is temporarily locked due to multiple failed login attempts');
    }

    const isPasswordValid = await bcrypt.compare(dto.password, user.passwordHash);

    if (!isPasswordValid) {
      await this.handleFailedAttempt(user.id, user.failedAttempts, dto.tenantId, ipAddress, userAgent);
      throw new UnauthorizedException('Invalid credentials');
    }

    // Verify tenant membership
    const isMember = user.tenants.some(t => t.tenantId === dto.tenantId);
    if (!isMember) {
      throw new ForbiddenException('User does not belong to the specified tenant');
    }

    // Reset failed attempts
    if (user.failedAttempts > 0 || user.lockedUntil) {
      await this.prisma.user.update({
        where: { id: user.id },
        data: { failedAttempts: 0, lockedUntil: null }
      });
    }

    await this.logAudit(dto.tenantId, user.id, 'LOGIN_SUCCESS', ipAddress, userAgent);

    return this.generateTokens(user, dto.tenantId);
  }

  private async handleFailedAttempt(userId: string, currentAttempts: number, tenantId: string, ipAddress: string, userAgent: string) {
    const newAttempts = currentAttempts + 1;
    const lockedUntil = newAttempts >= this.MAX_FAILED_ATTEMPTS ? new Date(Date.now() + this.LOCKOUT_DURATION_MS) : null;

    await this.prisma.user.update({
      where: { id: userId },
      data: { failedAttempts: newAttempts, lockedUntil }
    });

    await this.logAudit(tenantId, userId, 'LOGIN_FAILED', ipAddress, userAgent);
  }

  private async generateTokens(user: any, tenantId: string) {
    // Extract roles and permissions for the specific tenant
    const tenantRoles = user.roles.filter(ur => ur.role.tenantId === tenantId).map(ur => ur.role);
    const roleNames = tenantRoles.map(r => r.name);
    const permissions = [...new Set(tenantRoles.flatMap(r => r.permissions.map(p => p.permission.action)))];

    const payload = {
      sub: user.id,
      tenantId,
      roles: roleNames,
      permissions,
    };

    // RS256 signed access token (15 mins)
    const accessToken = this.jwtService.sign(payload, { expiresIn: '15m', algorithm: 'RS256' });
    
    // Refresh token (7 days)
    const refreshToken = uuidv4();
    const redisKey = `refresh_token:${tenantId}:${user.id}:${refreshToken}`;
    await this.redis.set(redisKey, 'valid', 'EX', 7 * 24 * 60 * 60);

    return { accessToken, refreshToken };
  }

  private async logAudit(tenantId: string, userId: string, action: string, ipAddress: string, userAgent: string) {
    await this.prisma.authAuditLog.create({
      data: { tenantId, userId, action, ipAddress, userAgent }
    });
  }
}
