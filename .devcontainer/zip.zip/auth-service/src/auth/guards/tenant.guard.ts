import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';

@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user; // Injected by JwtAuthGuard
    const headerTenantId = request.headers['x-tenant-id'];

    if (!user || !user.tenantId) {
      throw new ForbiddenException('Tenant context missing from token');
    }

    // Enforce that the requested tenant matches the token's tenant
    if (headerTenantId && headerTenantId !== user.tenantId) {
      throw new ForbiddenException('Cross-tenant access forbidden');
    }

    // Attach tenantId to request for downstream use
    request.tenantId = user.tenantId;

    return true;
  }
}
