import { PrismaClient } from '@prisma/client';
import { AsyncLocalStorage } from 'async_hooks';

export const tenantContext = new AsyncLocalStorage<{ tenantId: string }>();

export function getRlsPrismaClient(prisma: PrismaClient) {
  return prisma.$extends({
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          const context = tenantContext.getStore();
          if (!context?.tenantId) {
            return query(args);
          }

          // Execute within a transaction to set RLS context
          return prisma.$transaction(async (tx) => {
            await tx.$executeRawUnsafe(`SELECT set_config('app.current_tenant_id', '${context.tenantId}', true);`);
            return query(args);
          });
        },
      },
    },
  });
}
