import { Injectable, BadRequestException, InternalServerErrorException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { ProviderFactory } from '../providers/provider.factory';
import { PolicyValidatorService } from './policy-validator.service';
import { BookingEventPublisher } from '../infrastructure/booking-event.publisher';
import { BookingMetricsService } from '../observability/booking-metrics.service';
import { BookingStateMachine } from '../domain/booking-state-machine';
import { BookingStatus } from '@prisma/client';
import axios from 'axios';
import axiosRetry from 'axios-retry';

@Injectable()
export class BookingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly providerFactory: ProviderFactory,
    private readonly policyValidator: PolicyValidatorService,
    private readonly eventPublisher: BookingEventPublisher,
    private readonly metrics: BookingMetricsService,
  ) {
    // Configure global axios retry for external calls (3 times, exponential backoff)
    axiosRetry(axios, { 
      retries: 3, 
      retryDelay: axiosRetry.exponentialDelay,
      shouldResetTimeout: true
    });
  }

  private async executeWithTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
    let timeoutHandle: NodeJS.Timeout;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutHandle = setTimeout(() => reject(new Error('Provider timeout')), timeoutMs);
    });

    return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timeoutHandle));
  }

  async processApprovedRequest(tenantId: string, correlationId: string, payload: any) {
    const endOrchestrationTimer = this.metrics.bookingLatency.startTimer({ tenantId });

    // BR-062: Duplicate booking prevented via idempotency key (travelRequestId)
    const existing = await this.prisma.booking.findUnique({
      where: { travelRequestId: payload.travelRequestId }
    });

    if (existing) {
      return; // Idempotent ack
    }

    // BR-061: Policy Revalidation
    const policyCheck = await this.policyValidator.validatePolicySnapshot(tenantId, payload);
    if (!policyCheck.valid) {
      this.eventPublisher.publish('BookingFailed', tenantId, correlationId, {
        travelRequestId: payload.travelRequestId,
        reason: `Policy violation: ${policyCheck.reason}`
      });
      return;
    }

    // Create Booking in PENDING state
    const booking = await this.prisma.$transaction(async (tx) => {
      const b = await tx.booking.create({
        data: {
          tenantId,
          travelRequestId: payload.travelRequestId,
          status: BookingStatus.PENDING,
          policyVersionId: payload.policyVersionId,
        }
      });
      await this.auditTransition(tx, b.id, tenantId, null, BookingStatus.PENDING, 'Initial creation');
      return b;
    });

    const provider = this.providerFactory.getProvider(payload.tenantConfig, payload.region);

    try {
      // Transition to INITIATED
      await this.updateStatus(booking.id, tenantId, BookingStatus.INITIATED, 'Starting provider call');
      this.eventPublisher.publish('BookingInitiated', tenantId, correlationId, { bookingId: booking.id });

      // Call Provider (10s timeout, retries handled by axios wrapper in real implementation, simulated here)
      const endProviderTimer = this.metrics.providerLatency.startTimer({ provider_name: provider.getProviderName(), operation: 'createBooking' });
      
      const result = await this.executeWithTimeout(
        provider.createBooking(payload),
        10000 // 10 seconds timeout
      );
      
      endProviderTimer();

      if (result.status === 'CONFIRMED') {
        await this.prisma.$transaction(async (tx) => {
          await tx.booking.update({
            where: { id: booking.id },
            data: {
              status: BookingStatus.CONFIRMED,
              providerName: result.providerName,
              externalReference: result.externalReference,
              totalCost: result.totalCost,
              currency: result.currency,
            }
          });
          await this.auditTransition(tx, booking.id, tenantId, BookingStatus.INITIATED, BookingStatus.CONFIRMED, 'Provider confirmed');
        });

        this.metrics.bookingSuccess.inc({ tenantId, provider_name: result.providerName });
        this.eventPublisher.publish('BookingConfirmed', tenantId, correlationId, {
          travelRequestId: payload.travelRequestId,
          bookingReference: result.externalReference,
          totalCost: result.totalCost,
          currency: result.currency,
        });
      } else {
        throw new Error('Provider returned FAILED status');
      }

    } catch (error: any) {
      // Saga Compensation / Failure
      await this.updateStatus(booking.id, tenantId, BookingStatus.FAILED, error.message);
      this.metrics.bookingFailure.inc({ tenantId, provider_name: provider.getProviderName(), reason: error.message });
      
      this.eventPublisher.publish('BookingFailed', tenantId, correlationId, {
        travelRequestId: payload.travelRequestId,
        reason: error.message
      });
    } finally {
      endOrchestrationTimer({ status: 'COMPLETED' });
    }
  }

  async cancelBooking(tenantId: string, bookingId: string, userId: string, correlationId: string) {
    const booking = await this.prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking || booking.tenantId !== tenantId) throw new BadRequestException('Booking not found');

    // BR-063: Cancellation allowed only in Confirmed state
    BookingStateMachine.validateTransition(booking.status, BookingStatus.CANCELLED);

    const provider = this.providerFactory.getProvider({}, 'DEFAULT');
    
    try {
      await this.executeWithTimeout(provider.cancelBooking(booking.externalReference!), 10000);
      
      await this.updateStatus(booking.id, tenantId, BookingStatus.CANCELLED, 'User requested cancellation', userId);
      
      this.eventPublisher.publish('BookingCancelled', tenantId, correlationId, {
        travelRequestId: booking.travelRequestId,
        bookingReference: booking.externalReference
      });

      return { success: true };
    } catch (error: any) {
      throw new InternalServerErrorException(`Failed to cancel with provider: ${error.message}`);
    }
  }

  async modifyBooking(tenantId: string, bookingId: string, changes: any, userId: string, correlationId: string) {
    const booking = await this.prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking || booking.tenantId !== tenantId) throw new BadRequestException('Booking not found');

    BookingStateMachine.validateTransition(booking.status, BookingStatus.MODIFIED);

    const provider = this.providerFactory.getProvider({}, 'DEFAULT');
    
    // BR-064: Modification only allowed if provider supports
    if (!provider.supportsModification()) {
      throw new BadRequestException('BR-064: Provider does not support direct modification. Please cancel and rebook.');
    }

    try {
      const result = await this.executeWithTimeout(provider.modifyBooking(booking.externalReference!, changes), 10000);
      
      await this.prisma.$transaction(async (tx) => {
        await tx.booking.update({
          where: { id: booking.id },
          data: {
            status: BookingStatus.MODIFIED,
            totalCost: result.totalCost,
            currency: result.currency,
          }
        });
        await this.auditTransition(tx, booking.id, tenantId, booking.status, BookingStatus.MODIFIED, 'User modified booking', userId);
      });

      this.eventPublisher.publish('BookingModified', tenantId, correlationId, {
        travelRequestId: booking.travelRequestId,
        bookingReference: result.externalReference,
        newCost: result.totalCost
      });

      return { success: true, newCost: result.totalCost };
    } catch (error: any) {
      throw new InternalServerErrorException(`Failed to modify with provider: ${error.message}`);
    }
  }

  private async updateStatus(bookingId: string, tenantId: string, newStatus: BookingStatus, reason: string, userId?: string) {
    await this.prisma.$transaction(async (tx) => {
      const current = await tx.booking.findUnique({ where: { id: bookingId } });
      BookingStateMachine.validateTransition(current!.status, newStatus);

      await tx.booking.update({
        where: { id: bookingId },
        data: { status: newStatus }
      });
      await this.auditTransition(tx, bookingId, tenantId, current!.status, newStatus, reason, userId);
    });
  }

  private async auditTransition(tx: any, bookingId: string, tenantId: string, prev: BookingStatus | null, next: BookingStatus, reason: string, userId?: string) {
    // BR-065: All transitions audited (Append-only)
    await tx.bookingAudit.create({
      data: {
        bookingId,
        tenantId,
        previousStatus: prev,
        newStatus: next,
        reason,
        userId,
      }
    });
  }
}
