import { Controller, Inject } from '@nestjs/common';
import { EventPattern, Payload, Ctx, RmqContext } from '@nestjs/microservices';
import { PrismaService } from '../../prisma/prisma.service';
import { IBookingProvider } from '../providers/booking-provider.interface';
import { TravelRequestApprovedV1Schema } from '@tripaxis/event-contracts';
import { ClientProxy } from '@nestjs/microservices';

@Controller()
export class BookingConsumer {
  constructor(
    private readonly prisma: PrismaService,
    @Inject('BOOKING_PROVIDER') private readonly provider: IBookingProvider,
    @Inject('RABBITMQ_SERVICE') private readonly eventPublisher: ClientProxy,
  ) {}

  @EventPattern('TravelRequestApproved:v1')
  async handleTravelRequestApproved(@Payload() data: any, @Ctx() context: RmqContext) {
    const channel = context.getChannelRef();
    const originalMsg = context.getMessage();

    try {
      // 1. Validate Event Contract
      const event = TravelRequestApprovedV1Schema.parse(data);
      const { travelRequestId, tenantId, correlationId } = event.payload;

      // 2. Idempotency Check
      const existing = await this.prisma.booking.findUnique({
        where: { travelRequestId }
      });
      if (existing) {
        channel.ack(originalMsg);
        return;
      }

      // 3. Call External Provider (Dummy for now)
      const result = await this.provider.createFlightBooking('auto-select', { employeeId: event.payload.employeeId });

      // 4. Persist Booking
      await this.prisma.booking.create({
        data: {
          tenantId,
          travelRequestId,
          bookingReference: result.bookingReference,
          provider: result.providerName,
          totalCost: result.totalCost,
          currency: result.currency,
          status: result.status,
        }
      });

      // 5. Publish Success Event
      this.eventPublisher.emit('BookingConfirmed:v1', {
        eventId: crypto.randomUUID(),
        correlationId,
        tenantId,
        timestamp: new Date().toISOString(),
        version: '1',
        eventType: 'BookingConfirmed:v1',
        payload: {
          travelRequestId,
          bookingReference: result.bookingReference,
          provider: result.providerName,
          totalCost: result.totalCost,
          currency: result.currency,
        }
      });

      channel.ack(originalMsg);
    } catch (error) {
      console.error('Booking failed, initiating compensation / retry', error);
      // Implement exponential backoff / DLQ logic here
      channel.nack(originalMsg, false, false); // Send to DLQ
    }
  }
}
