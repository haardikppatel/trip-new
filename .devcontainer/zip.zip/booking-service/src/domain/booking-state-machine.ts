import { BookingStatus } from '@prisma/client';
import { BadRequestException } from '@nestjs/common';

export class BookingStateMachine {
  private static readonly transitions: Record<BookingStatus, BookingStatus[]> = {
    [BookingStatus.PENDING]: [BookingStatus.INITIATED, BookingStatus.FAILED],
    [BookingStatus.INITIATED]: [BookingStatus.CONFIRMED, BookingStatus.FAILED],
    [BookingStatus.CONFIRMED]: [BookingStatus.CANCELLED, BookingStatus.MODIFIED],
    [BookingStatus.FAILED]: [],
    [BookingStatus.CANCELLED]: [],
    [BookingStatus.MODIFIED]: [BookingStatus.CANCELLED, BookingStatus.MODIFIED],
  };

  static validateTransition(current: BookingStatus, next: BookingStatus): void {
    const allowed = this.transitions[current];
    if (!allowed.includes(next)) {
      throw new BadRequestException(`Invalid state transition from ${current} to ${next}`);
    }
  }
}
