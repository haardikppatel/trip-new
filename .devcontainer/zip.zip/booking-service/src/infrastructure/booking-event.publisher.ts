import { Injectable, Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class BookingEventPublisher {
  constructor(@Inject('RABBITMQ_SERVICE') private readonly client: ClientProxy) {}

  publish(eventType: string, tenantId: string, correlationId: string, payload: any): void {
    this.client.emit(eventType, {
      eventId: crypto.randomUUID(),
      correlationId,
      tenantId,
      timestamp: new Date().toISOString(),
      eventType,
      payload,
    });
  }
}
