import { Injectable } from '@nestjs/common';
import { Counter, Histogram } from 'prom-client';

@Injectable()
export class BookingMetricsService {
  public readonly bookingLatency = new Histogram({
    name: 'booking_orchestration_latency_seconds',
    help: 'Latency of booking orchestration excluding provider call',
    labelNames: ['tenant_id', 'status'],
    buckets: [0.1, 0.2, 0.5, 1, 2, 5],
  });

  public readonly providerLatency = new Histogram({
    name: 'booking_provider_latency_seconds',
    help: 'Latency of external provider calls',
    labelNames: ['provider_name', 'operation'],
    buckets: [0.5, 1, 2, 5, 10, 15],
  });

  public readonly bookingSuccess = new Counter({
    name: 'booking_success_total',
    help: 'Total successful bookings',
    labelNames: ['tenant_id', 'provider_name'],
  });

  public readonly bookingFailure = new Counter({
    name: 'booking_failure_total',
    help: 'Total failed bookings',
    labelNames: ['tenant_id', 'provider_name', 'reason'],
  });
}
