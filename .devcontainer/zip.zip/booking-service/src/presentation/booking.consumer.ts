import { Controller } from '@nestjs/common';
import { EventPattern, Payload, Ctx, RmqContext } from '@nestjs/microservices';
import { BookingService } from '../application/booking.service';

@Controller()
export class BookingConsumer {
  constructor(private readonly bookingService: BookingService) {}

  // BR-060: Booking only after TravelRequestApproved
  @EventPattern('TravelRequestApproved:v1')
  async handleTravelRequestApproved(@Payload() data: any, @Ctx() context: RmqContext) {
    const channel = context.getChannelRef();
    const originalMsg = context.getMessage();

    try {
      await this.bookingService.processApprovedRequest(
        data.tenantId,
        data.correlationId,
        data.payload
      );
      channel.ack(originalMsg);
    } catch (error) {
      console.error('Booking processing failed', error);
      // Nack and requeue or send to DLQ based on retry count
      channel.nack(originalMsg, false, false);
    }
  }
}
