import { Controller, Post, Get, Param, Body, Headers, UseGuards } from '@nestjs/common';
import { BookingService } from '../application/booking.service';
import { PrismaService } from '../../prisma/prisma.service';

@Controller('v1/bookings')
export class BookingController {
  constructor(
    private readonly bookingService: BookingService,
    private readonly prisma: PrismaService,
  ) {}

  @Post('manual-booking')
  async manualBooking(@Headers('x-tenant-id') tenantId: string, @Headers('x-correlation-id') correlationId: string, @Body() payload: any) {
    return this.bookingService.processApprovedRequest(tenantId, correlationId, payload);
  }

  @Post('cancel/:bookingId')
  async cancelBooking(
    @Headers('x-tenant-id') tenantId: string,
    @Headers('x-user-id') userId: string,
    @Headers('x-correlation-id') correlationId: string,
    @Param('bookingId') bookingId: string
  ) {
    return this.bookingService.cancelBooking(tenantId, bookingId, userId, correlationId);
  }

  @Post('modify/:bookingId')
  async modifyBooking(
    @Headers('x-tenant-id') tenantId: string,
    @Headers('x-user-id') userId: string,
    @Headers('x-correlation-id') correlationId: string,
    @Param('bookingId') bookingId: string,
    @Body() changes: any
  ) {
    return this.bookingService.modifyBooking(tenantId, bookingId, changes, userId, correlationId);
  }

  @Get(':bookingId')
  async getBooking(@Headers('x-tenant-id') tenantId: string, @Param('bookingId') bookingId: string) {
    return this.prisma.booking.findUnique({
      where: { id: bookingId, tenantId },
      include: { items: true, audits: true }
    });
  }

  @Get('status/:travelRequestId')
  async getStatus(@Headers('x-tenant-id') tenantId: string, @Param('travelRequestId') travelRequestId: string) {
    return this.prisma.booking.findUnique({
      where: { travelRequestId, tenantId },
      select: { status: true, externalReference: true }
    });
  }
}
