export interface FlightSearchCriteria {
  origin: string;
  destination: string;
  departureDate: string;
  returnDate?: string;
  passengers: number;
}

export interface HotelSearchCriteria {
  location: string;
  checkIn: string;
  checkOut: string;
  guests: number;
}

export interface BookingResult {
  bookingReference: string;
  totalCost: number;
  currency: string;
  status: 'CONFIRMED' | 'FAILED';
  providerName: string;
}

export interface IBookingProvider {
  getProviderName(): string;
  searchFlights(criteria: FlightSearchCriteria): Promise<any[]>;
  searchHotels(criteria: HotelSearchCriteria): Promise<any[]>;
  createFlightBooking(flightId: string, passengerDetails: any): Promise<BookingResult>;
  createHotelBooking(hotelId: string, guestDetails: any): Promise<BookingResult>;
  cancelBooking(bookingReference: string): Promise<boolean>;
}
