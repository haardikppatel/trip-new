import { Injectable } from '@nestjs/common';
import { TravelProvider, SearchCriteria, BookingPayload, BookingResult } from './travel-provider.interface';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class DummyProvider implements TravelProvider {
  getProviderName(): string {
    return 'DUMMY_PROVIDER';
  }

  supportsModification(): boolean {
    return true;
  }

  async searchFlights(criteria: SearchCriteria): Promise<any[]> {
    return [{ id: 'fl-1', airline: 'MockAir', price: 450, currency: 'USD' }];
  }

  async searchHotels(criteria: SearchCriteria): Promise<any[]> {
    return [{ id: 'ht-1', name: 'Mock Hotel', price: 150, currency: 'USD' }];
  }

  async createBooking(payload: BookingPayload): Promise<BookingResult> {
    return {
      externalReference: `DUMMY-${uuidv4().substring(0, 8).toUpperCase()}`,
      totalCost: 600,
      currency: 'USD',
      status: 'CONFIRMED',
      providerName: this.getProviderName(),
    };
  }

  async cancelBooking(reference: string): Promise<boolean> {
    return true;
  }

  async modifyBooking(reference: string, changes: any): Promise<BookingResult> {
    return {
      externalReference: reference,
      totalCost: 650,
      currency: 'USD',
      status: 'CONFIRMED',
      providerName: this.getProviderName(),
    };
  }
}
