import { Injectable } from '@nestjs/common';
import { TravelProvider } from './travel-provider.interface';
import { DummyProvider } from './dummy.provider';
import { AmadeusAdapter } from './amadeus.adapter';

@Injectable()
export class ProviderFactory {
  constructor(
    private readonly dummyProvider: DummyProvider,
    private readonly amadeusAdapter: AmadeusAdapter,
  ) {}

  getProvider(tenantConfig: any, region: string): TravelProvider {
    // Provider selection rules based on tenant config, region, or cost priority
    if (tenantConfig?.preferredProvider === 'AMADEUS' && region === 'EU') {
      return this.amadeusAdapter;
    }
    
    // Default fallback
    return this.dummyProvider;
  }
}
