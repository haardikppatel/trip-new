export interface SearchCriteria {
  origin?: string;
  destination?: string;
  departureDate?: string;
  returnDate?: string;
  location?: string;
  checkIn?: string;
  checkOut?: string;
  passengers?: number;
  guests?: number;
}

export interface BookingPayload {
  travelRequestId: string;
  items: any[];
  passengers: any[];
}

export interface BookingResult {
  externalReference: string;
  totalCost: number;
  currency: string;
  status: 'CONFIRMED' | 'FAILED';
  providerName: string;
  metadata?: any;
}

export interface TravelProvider {
  getProviderName(): string;
  searchFlights(criteria: SearchCriteria): Promise<any[]>;
  searchHotels(criteria: SearchCriteria): Promise<any[]>;
  createBooking(payload: BookingPayload): Promise<BookingResult>;
  cancelBooking(reference: string): Promise<boolean>;
  modifyBooking(reference: string, changes: any): Promise<BookingResult>;
  supportsModification(): boolean;
}
