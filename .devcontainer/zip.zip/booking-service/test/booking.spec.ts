import { Test, TestingModule } from '@nestjs/testing';
import { BookingService } from '../src/application/booking.service';
import { BookingStateMachine } from '../src/domain/booking-state-machine';
import { ProviderFactory } from '../src/providers/provider.factory';
import { PolicyValidatorService } from '../src/application/policy-validator.service';
import { BookingStatus } from '@prisma/client';
import { BadRequestException } from '@nestjs/common';

describe('Travel Booking Engine', () => {
  let bookingService: BookingService;

  const mockPrisma = {
    booking: { findUnique: jest.fn(), create: jest.fn(), update: jest.fn() },
    bookingAudit: { create: jest.fn() },
    $transaction: jest.fn((cb) => cb(mockPrisma)),
  };

  const mockProvider = {
    getProviderName: () => 'DUMMY',
    createBooking: jest.fn().mockResolvedValue({ status: 'CONFIRMED', externalReference: 'EXT123', totalCost: 100, currency: 'USD' }),
    cancelBooking: jest.fn().mockResolvedValue(true),
    modifyBooking: jest.fn(),
    supportsModification: jest.fn().mockReturnValue(false),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        BookingService,
        { provide: 'PrismaService', useValue: mockPrisma },
        { provide: ProviderFactory, useValue: { getProvider: () => mockProvider } },
        { provide: PolicyValidatorService, useValue: { validatePolicySnapshot: jest.fn().mockResolvedValue({ valid: true }) } },
        { provide: 'BookingEventPublisher', useValue: { publish: jest.fn() } },
        { provide: 'BookingMetricsService', useValue: { bookingLatency: { startTimer: jest.fn().mockReturnValue(jest.fn()) }, providerLatency: { startTimer: jest.fn().mockReturnValue(jest.fn()) }, bookingSuccess: { inc: jest.fn() }, bookingFailure: { inc: jest.fn() } } },
      ],
    }).compile();

    bookingService = module.get<BookingService>(BookingService);
  });

  it('should enforce valid state transitions (BR-063)', () => {
    expect(() => BookingStateMachine.validateTransition(BookingStatus.PENDING, BookingStatus.INITIATED)).not.toThrow();
    expect(() => BookingStateMachine.validateTransition(BookingStatus.CONFIRMED, BookingStatus.CANCELLED)).not.toThrow();
    
    // Invalid transition
    expect(() => BookingStateMachine.validateTransition(BookingStatus.PENDING, BookingStatus.CANCELLED)).toThrow(BadRequestException);
  });

  it('should block modification if provider does not support it (BR-064)', async () => {
    mockPrisma.booking.findUnique.mockResolvedValueOnce({ id: 'b1', tenantId: 't1', status: BookingStatus.CONFIRMED });
    
    await expect(bookingService.modifyBooking('t1', 'b1', {}, 'u1', 'c1')).rejects.toThrow(/BR-064/);
  });

  it('should abort booking if policy revalidation fails (BR-061)', async () => {
    const policyValidator = module.get<PolicyValidatorService>(PolicyValidatorService);
    jest.spyOn(policyValidator, 'validatePolicySnapshot').mockResolvedValueOnce({ valid: false, reason: 'Budget exceeded' });
    
    const eventPublisher = module.get('BookingEventPublisher');
    
    await bookingService.processApprovedRequest('t1', 'c1', { travelRequestId: 'tr1' });
    
    expect(eventPublisher.publish).toHaveBeenCalledWith('BookingFailed', 't1', 'c1', expect.objectContaining({ reason: 'Policy violation: Budget exceeded' }));
  });
});
