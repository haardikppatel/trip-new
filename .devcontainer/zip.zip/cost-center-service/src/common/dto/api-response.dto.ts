import { ApiProperty } from '@nestjs/swagger';

export class ApiError {
  @ApiProperty()
  code: string;

  @ApiProperty()
  message: string;
}

export class ApiResponseDto<T> {
  @ApiProperty()
  success: boolean;

  @ApiProperty({ required: false })
  data?: T;

  @ApiProperty({ type: ApiError, required: false })
  error?: ApiError;

  static success<T>(data: T): ApiResponseDto<T> {
    return { success: true, data };
  }

  static failure(code: string, message: string): ApiResponseDto<any> {
    return { success: false, error: { code, message } };
  }
}

export class PaginatedData<T> {
  @ApiProperty()
  items: T[];

  @ApiProperty()
  total: number;

  @ApiProperty()
  page: number;

  @ApiProperty()
  limit: number;
}
