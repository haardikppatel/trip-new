import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { TenantContext } from '@tripaxis/core';

@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const headerTenantId = request.headers['x-tenant-id'];
    const userTenantId = request.user?.tenantId; // Set by JWT middleware

    if (!headerTenantId || !userTenantId) {
      throw new UnauthorizedException('Tenant context missing');
    }

    if (headerTenantId !== userTenantId) {
      throw new UnauthorizedException('Cross-tenant access forbidden');
    }

    // Initialize the TenantContext for the current request lifecycle
    TenantContext.setTenantId(userTenantId);
    TenantContext.setUserId(request.user?.sub);

    return true;
  }
}
