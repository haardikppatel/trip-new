import { Injectable, Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { TenantContext } from '@tripaxis/core';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class EventPublisher {
  constructor(@Inject('RABBITMQ_SERVICE') private readonly client: ClientProxy) {}

  async publish(eventType: string, payload: any): Promise<void> {
    const tenantId = TenantContext.getTenantId();
    const correlationId = TenantContext.getCorrelationId() || uuidv4();

    const event = {
      eventId: uuidv4(),
      correlationId,
      tenantId,
      timestamp: new Date().toISOString(),
      eventType,
      payload,
    };

    // 7. Async events published to RabbitMQ
    this.client.emit(eventType, event);
  }
}
