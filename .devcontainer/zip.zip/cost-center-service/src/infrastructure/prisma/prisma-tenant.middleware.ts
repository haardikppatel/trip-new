import { PrismaClient } from '@prisma/client';
import { TenantContext } from '@tripaxis/core';

export function getRlsPrismaClient(prisma: PrismaClient) {
  return prisma.$extends({
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          const tenantId = TenantContext.getTenantId();
          
          if (!tenantId) {
            return query(args);
          }

          // 1. Multi-tenant isolation: Enforce RLS via PostgreSQL session variables
          return prisma.$transaction(async (tx) => {
            await tx.$executeRawUnsafe(`SELECT set_config('app.current_tenant_id', '${tenantId}', true);`);
            
            // Auto-filter soft deleted records
            if (args.where) {
              args.where = { ...args.where, deletedAt: null };
            } else {
              args.where = { deletedAt: null };
            }

            return query(args);
          });
        },
      },
    },
  });
}
