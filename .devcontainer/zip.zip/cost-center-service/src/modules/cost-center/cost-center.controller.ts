import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiHeader } from '@nestjs/swagger';
import { CostCenterService } from './cost-center.service';
import { CreateCostCenterDto, UpdateCostCenterDto, CostCenterResponseDto } from './dto/cost-center.dto';
import { ApiResponseDto, PaginatedData } from '../../common/dto/api-response.dto';
import { PaginationQueryDto } from '../../common/dto/pagination.dto';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RbacGuard } from '../../common/guards/rbac.guard';
import { Roles } from '@tripaxis/core';

@ApiTags('Cost Centers')
@ApiBearerAuth()
@ApiHeader({ name: 'x-tenant-id', required: true, description: 'Tenant ID' })
@UseGuards(TenantGuard, RbacGuard)
@Controller('v1/cost-centers')
export class CostCenterController {
  constructor(private readonly costCenterService: CostCenterService) {}

  @Post()
  @Roles('FinanceAdmin', 'AppAdmin')
  @ApiOperation({ summary: 'Create a new cost center' })
  @ApiResponse({ status: 201, type: ApiResponseDto<CostCenterResponseDto> })
  async create(@Body() dto: CreateCostCenterDto): Promise<ApiResponseDto<CostCenterResponseDto>> {
    const result = await this.costCenterService.createCostCenter(dto);
    return ApiResponseDto.success(result as any);
  }

  @Get()
  @Roles('FinanceAdmin', 'AppAdmin', 'Employee')
  @ApiOperation({ summary: 'List cost centers with pagination' })
  @ApiResponse({ status: 200, type: ApiResponseDto<PaginatedData<CostCenterResponseDto>> })
  async findAll(@Query() query: PaginationQueryDto): Promise<ApiResponseDto<PaginatedData<CostCenterResponseDto>>> {
    const { items, total } = await this.costCenterService.getCostCenters(query.page!, query.limit!);
    return ApiResponseDto.success({ items: items as any, total, page: query.page!, limit: query.limit! });
  }

  @Get(':id')
  @Roles('FinanceAdmin', 'AppAdmin', 'Employee')
  @ApiOperation({ summary: 'Get cost center by ID' })
  @ApiResponse({ status: 200, type: ApiResponseDto<CostCenterResponseDto> })
  async findOne(@Param('id') id: string): Promise<ApiResponseDto<CostCenterResponseDto>> {
    const result = await this.costCenterService.getCostCenterById(id);
    return ApiResponseDto.success(result as any);
  }

  @Put(':id')
  @Roles('FinanceAdmin', 'AppAdmin')
  @ApiOperation({ summary: 'Update a cost center' })
  @ApiResponse({ status: 200, type: ApiResponseDto<CostCenterResponseDto> })
  async update(@Param('id') id: string, @Body() dto: UpdateCostCenterDto): Promise<ApiResponseDto<CostCenterResponseDto>> {
    const result = await this.costCenterService.updateCostCenter(id, dto);
    return ApiResponseDto.success(result as any);
  }

  @Delete(':id')
  @Roles('FinanceAdmin', 'AppAdmin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Soft delete a cost center' })
  @ApiResponse({ status: 200, type: ApiResponseDto<{ deleted: boolean }> })
  async remove(@Param('id') id: string): Promise<ApiResponseDto<{ deleted: boolean }>> {
    const result = await this.costCenterService.deleteCostCenter(id);
    return ApiResponseDto.success(result);
  }
}
