import { Injectable, Inject } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { CreateCostCenterDto, UpdateCostCenterDto } from './dto/cost-center.dto';

@Injectable()
export class CostCenterRepository {
  constructor(@Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient) {}

  async create(tenantId: string, data: CreateCostCenterDto) {
    return this.prisma.costCenter.create({
      data: {
        tenantId,
        code: data.code,
        name: data.name,
        description: data.description,
        budget: data.budget,
      },
    });
  }

  async findById(id: string) {
    return this.prisma.costCenter.findUnique({
      where: { id },
    });
  }

  async findByCode(tenantId: string, code: string) {
    return this.prisma.costCenter.findUnique({
      where: { tenantId_code: { tenantId, code } },
    });
  }

  async findAllPaginated(skip: number, take: number) {
    const [items, total] = await Promise.all([
      this.prisma.costCenter.findMany({
        skip,
        take,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.costCenter.count(),
    ]);
    return { items, total };
  }

  async update(id: string, data: UpdateCostCenterDto) {
    return this.prisma.costCenter.update({
      where: { id },
      data,
    });
  }

  async softDelete(id: string) {
    return this.prisma.costCenter.update({
      where: { id },
      data: { deletedAt: new Date(), isActive: false },
    });
  }
}
