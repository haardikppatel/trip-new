import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { CostCenterRepository } from './cost-center.repository';
import { CreateCostCenterDto, UpdateCostCenterDto } from './dto/cost-center.dto';
import { EventPublisher } from '../../infrastructure/events/event.publisher';
import { AuditLogger, TenantContext } from '@tripaxis/core';

@Injectable()
export class CostCenterService {
  constructor(
    private readonly repository: CostCenterRepository,
    private readonly eventPublisher: EventPublisher,
    private readonly auditLogger: AuditLogger,
  ) {}

  async createCostCenter(dto: CreateCostCenterDto) {
    const tenantId = TenantContext.getTenantId();
    
    const existing = await this.repository.findByCode(tenantId, dto.code);
    if (existing) {
      throw new ConflictException(`Cost center with code ${dto.code} already exists`);
    }

    const costCenter = await this.repository.create(tenantId, dto);

    // 6. Audit Logging
    await this.auditLogger.log({
      action: 'COST_CENTER_CREATED',
      entityId: costCenter.id,
      entityType: 'CostCenter',
      newData: costCenter,
    });

    // 7. Async Event Publishing
    await this.eventPublisher.publish('CostCenterCreated:v1', {
      costCenterId: costCenter.id,
      code: costCenter.code,
    });

    return costCenter;
  }

  async getCostCenters(page: number, limit: number) {
    const skip = (page - 1) * limit;
    return this.repository.findAllPaginated(skip, limit);
  }

  async getCostCenterById(id: string) {
    const costCenter = await this.repository.findById(id);
    if (!costCenter) {
      throw new NotFoundException('Cost center not found');
    }
    return costCenter;
  }

  async updateCostCenter(id: string, dto: UpdateCostCenterDto) {
    const costCenter = await this.getCostCenterById(id);

    const updated = await this.repository.update(id, dto);

    await this.auditLogger.log({
      action: 'COST_CENTER_UPDATED',
      entityId: id,
      entityType: 'CostCenter',
      oldData: costCenter,
      newData: updated,
    });

    await this.eventPublisher.publish('CostCenterUpdated:v1', {
      costCenterId: id,
      changes: dto,
    });

    return updated;
  }

  async deleteCostCenter(id: string) {
    const costCenter = await this.getCostCenterById(id);

    await this.repository.softDelete(id);

    await this.auditLogger.log({
      action: 'COST_CENTER_DELETED',
      entityId: id,
      entityType: 'CostCenter',
      oldData: costCenter,
    });

    await this.eventPublisher.publish('CostCenterDeleted:v1', {
      costCenterId: id,
    });

    return { deleted: true };
  }
}
