import { Test, TestingModule } from '@nestjs/testing';
import { CostCenterService } from '../src/modules/cost-center/cost-center.service';
import { CostCenterRepository } from '../src/modules/cost-center/cost-center.repository';
import { EventPublisher } from '../src/infrastructure/events/event.publisher';
import { AuditLogger, TenantContext } from '@tripaxis/core';
import { ConflictException } from '@nestjs/common';

describe('CostCenterService', () => {
  let service: CostCenterService;
  let repository: CostCenterRepository;
  let auditLogger: AuditLogger;
  let eventPublisher: EventPublisher;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CostCenterService,
        {
          provide: CostCenterRepository,
          useValue: {
            findByCode: jest.fn(),
            create: jest.fn(),
            findById: jest.fn(),
            softDelete: jest.fn(),
          },
        },
        {
          provide: EventPublisher,
          useValue: { publish: jest.fn() },
        },
        {
          provide: AuditLogger,
          useValue: { log: jest.fn() },
        },
      ],
    }).compile();

    service = module.get<CostCenterService>(CostCenterService);
    repository = module.get<CostCenterRepository>(CostCenterRepository);
    auditLogger = module.get<AuditLogger>(AuditLogger);
    eventPublisher = module.get<EventPublisher>(EventPublisher);

    // Mock TenantContext
    jest.spyOn(TenantContext, 'getTenantId').mockReturnValue('tenant-123');
  });

  it('should create a cost center and emit audit/events', async () => {
    const dto = { code: 'ENG-01', name: 'Engineering', budget: 10000 };
    const createdEntity = { id: 'cc-1', ...dto, tenantId: 'tenant-123' };

    jest.spyOn(repository, 'findByCode').mockResolvedValue(null);
    jest.spyOn(repository, 'create').mockResolvedValue(createdEntity as any);

    const result = await service.createCostCenter(dto);

    expect(result).toEqual(createdEntity);
    expect(auditLogger.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'COST_CENTER_CREATED' }));
    expect(eventPublisher.publish).toHaveBeenCalledWith('CostCenterCreated:v1', expect.any(Object));
  });

  it('should throw ConflictException if code exists', async () => {
    jest.spyOn(repository, 'findByCode').mockResolvedValue({ id: 'cc-1' } as any);

    await expect(service.createCostCenter({ code: 'ENG-01', name: 'Eng', budget: 100 })).rejects.toThrow(ConflictException);
  });
});
