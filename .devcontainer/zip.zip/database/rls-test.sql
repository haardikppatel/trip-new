-- ==========================================
-- RLS Isolation Validation Tests
-- ==========================================

-- Setup: Insert mock data for two different tenants
INSERT INTO policies (tenant_id, name, rules) VALUES 
('11111111-1111-1111-1111-111111111111', 'Acme Corp Travel Policy', '{"max_flight": 1000}'),
('22222222-2222-2222-2222-222222222222', 'Globex Inc Travel Policy', '{"max_flight": 500}');

-- TEST 1: Query without setting tenant_id
-- Expectation: Returns 0 rows (or throws an error if 'true' wasn't passed to current_setting)
RESET app.tenant_id;
SELECT * FROM policies; 
-- Result: 0 rows

-- TEST 2: Query as Tenant 1
-- Expectation: Returns only Acme Corp's policy
SET app.tenant_id = '11111111-1111-1111-1111-111111111111';
SELECT * FROM policies;
-- Result: 1 row (Acme Corp)

-- TEST 3: Query as Tenant 2
-- Expectation: Returns only Globex Inc's policy
SET app.tenant_id = '22222222-2222-2222-2222-222222222222';
SELECT * FROM policies;
-- Result: 1 row (Globex Inc)

-- TEST 4: Attempt to insert data for another tenant
-- Expectation: Throws "new row violates row-level security policy" error
SET app.tenant_id = '11111111-1111-1111-1111-111111111111';
INSERT INTO policies (tenant_id, name, rules) 
VALUES ('22222222-2222-2222-2222-222222222222', 'Malicious Insert', '{}');
-- Result: ERROR: new row violates row-level security policy for table "policies"
