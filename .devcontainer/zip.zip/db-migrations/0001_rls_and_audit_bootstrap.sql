-- Up Migration

-- 1. Enable RLS on core tables
ALTER TABLE "users" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "expense_claims" ENABLE ROW LEVEL SECURITY;

-- 2. Create Tenant Isolation Policies
CREATE POLICY tenant_isolation_users ON "users"
  FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM "user_tenants" ut 
      WHERE ut.user_id = "users".id 
      AND ut.tenant_id = current_setting('app.current_tenant_id')::uuid
    )
  );

CREATE POLICY tenant_isolation_claims ON "expense_claims"
  FOR ALL
  USING (tenant_id = current_setting('app.current_tenant_id')::uuid);

-- 3. Create Immutable Audit Log Table
CREATE TABLE "system_audit_logs" (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  table_name VARCHAR(255) NOT NULL,
  record_id UUID NOT NULL,
  action VARCHAR(50) NOT NULL,
  old_data JSONB,
  new_data JSONB,
  actor_id UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. Prevent UPDATE/DELETE on Audit Table
CREATE OR REPLACE FUNCTION prevent_audit_modification()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Updates and deletes are strictly forbidden on audit logs.';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_prevent_audit_update
BEFORE UPDATE OR DELETE ON "system_audit_logs"
FOR EACH ROW EXECUTE FUNCTION prevent_audit_modification();

-- Down Migration
-- DROP TRIGGER trg_prevent_audit_update ON "system_audit_logs";
-- DROP FUNCTION prevent_audit_modification;
-- DROP TABLE "system_audit_logs";
-- DROP POLICY tenant_isolation_claims ON "expense_claims";
-- DROP POLICY tenant_isolation_users ON "users";
-- ALTER TABLE "expense_claims" DISABLE ROW LEVEL SECURITY;
-- ALTER TABLE "users" DISABLE ROW LEVEL SECURITY;
