-- Outbox Table Migration
CREATE TABLE "event_outbox" (
  "id" UUID PRIMARY KEY,
  "tenant_id" UUID NOT NULL,
  "correlation_id" UUID NOT NULL,
  "event_type" VARCHAR(255) NOT NULL,
  "payload" JSONB NOT NULL,
  "status" VARCHAR(50) NOT NULL DEFAULT 'PENDING',
  "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  "published_at" TIMESTAMP WITH TIME ZONE
);

CREATE INDEX "idx_event_outbox_status" ON "event_outbox"("status", "created_at");
