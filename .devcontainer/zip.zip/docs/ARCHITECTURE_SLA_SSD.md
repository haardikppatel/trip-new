# System Solution Document (SSD)
## Master Orchestration, SLAs, and Resilience (Module 1)

### 1. Event-Driven Architecture Flow
This system operates on an event-driven choreography model. State transitions are communicated via asynchronous events, ensuring loose coupling and high availability.

#### Travel Request Lifecycle
1. **Employee** submits request via API Gateway.
2. **Travel Service**:
   - Sync call to **Policy Service** (protected by Circuit Breaker).
   - Persists request via Transactional Outbox.
   - Emits `TravelRequestSubmitted`.
3. **Approval Engine**:
   - Consumes `TravelRequestSubmitted` (Idempotent).
   - Evaluates chain, emits `ApprovalRequested`.
   - On Manager approval, emits `TravelRequestApproved`.
4. **Booking Integration**:
   - Consumes `TravelRequestApproved`.
   - Calls external provider (with exponential backoff).
   - Emits `BookingConfirmed` or `BookingFailed`.
5. **Notification Service**:
   - Listens to all domain events.
   - Dispatches Email/Slack notifications.

#### Expense Lifecycle
1. **Employee** submits expense.
2. **Expense Service**:
   - Validates policy & receipts.
   - Emits `ExpenseSubmitted`.
3. **Approval Engine**:
   - Processes approval chain.
   - Emits `ExpenseApproved`.
4. **Expense Service**:
   - Consumes `ExpenseApproved`.
   - Marks reimbursable, triggers Payment Run.

---

### 2. SLA Contracts (Non-Functional Requirements)

| Service | Metric | SLA Target | Enforcement Mechanism |
| :--- | :--- | :--- | :--- |
| **Travel Service** | P95 Request Creation | < 300ms | Redis caching, async event publishing |
| **Travel Service** | Policy Validation | < 200ms | gRPC / internal fast-path, Circuit Breaker |
| **Travel Service** | Availability | 99.9% | Kubernetes HPA, Multi-AZ deployment |
| **Approval Engine** | Event Processing | < 2s | RabbitMQ prefetch tuning, BullMQ workers |
| **Approval Engine** | Event Retry Tolerance | 3 attempts | Dead Letter Queue (DLQ) routing |
| **Booking Integration**| Vendor Call Timeout | 10s | Axios timeout configuration |
| **Booking Integration**| Booking Success | 98% | Exponential backoff, fallback providers |
| **Expense Service** | Receipt Processing | < 1.5s | Async worker offloading |
| **Expense Service** | Reimbursement Marking| < 500ms | Optimistic locking, indexed DB updates |
| **Notification** | Email Dispatch | < 30s | BullMQ priority queues |
| **Notification** | DLQ Alerting | > 50 msgs | Prometheus AlertManager rules |
| **Auth Service** | Token Validation | < 100ms | Local JWT verification (RS256 public key) |
| **Auth Service** | Token Issuance | < 200ms | Redis-backed refresh token store |

---

### 3. Failure Simulation & Enterprise Resilience (Chaos Engineering)

#### Scenario 1: Policy Service Down
* **Expected Behavior**: Travel Service fails fast.
* **Mechanism**: `CircuitBreakerInterceptor` trips after consecutive failures. Returns `503 Service Unavailable` immediately without waiting for timeouts. Alerts trigger in Prometheus. No silent approvals are allowed.

#### Scenario 2: Booking Provider API Timeout
* **Expected Behavior**: Retry 3 times, then emit failure, trigger compensation.
* **Mechanism**: Axios interceptor with `axios-retry` (exponential backoff). If all retries fail, emits `BookingFailed`. Saga orchestrator catches `BookingFailed`, reverts approval state, and notifies the user.

#### Scenario 3: Duplicate Event Delivered
* **Expected Behavior**: Safely ignored. No duplicate bookings or payouts.
* **Mechanism**: `IdempotencyInterceptor` uses Redis `SETNX` with the event's `correlationId` or `eventId`. If the key exists, the event is acknowledged without processing.

#### Scenario 4: Cross-Tenant Data Access Attempt
* **Expected Behavior**: Blocked at DB level, logged as security event.
* **Mechanism**: PostgreSQL Row-Level Security (RLS) policies enforce `tenant_id` matching `current_setting('app.current_tenant_id')`. Violations throw DB errors, caught by global exception filters, and logged to `system_audit_logs`.
