# TripAxis Expense Fraud Detection Architecture

## 1. Service Breakdown

### A. Fraud Detection Service (NestJS / TypeScript)
*   **Role:** The orchestrator and deterministic rule evaluator.
*   **Responsibilities:**
    *   Consumes `tripaxis.expense.submitted.v1` from RabbitMQ.
    *   Fetches tenant-specific rules from Redis (dynamically reloaded from PostgreSQL).
    *   Gathers context (e.g., duplicate receipt hashes, department averages).
    *   Executes the **Deterministic Rule Engine**.
    *   Calls the Python ML Service via gRPC or internal HTTP for the AI score.
    *   Aggregates the Rule Score and ML Score into a final `risk_score` (0-100).
    *   Publishes `tripaxis.fraud.scored.v1`.

### B. ML Inference Service (Python / FastAPI)
*   **Role:** Statistical anomaly detection and machine learning inference.
*   **Responsibilities:**
    *   Exposes a high-performance `/v1/predict` endpoint.
    *   Pulls historical user/tenant behavioral profiles from OpenSearch.
    *   Runs an **Isolation Forest** model (for unsupervised anomaly detection, e.g., unusual spending patterns for this specific user).
    *   Runs an **XGBoost** classifier (supervised learning based on historically rejected/fraudulent claims).
    *   Returns an `ml_score` and `confidence_score`.

---

## 2. Event Schema

### Input: `tripaxis.expense.submitted.v1`
```json
{
  "event_id": "uuid",
  "tenant_id": "uuid",
  "payload": {
    "expense_id": "uuid",
    "user_id": "uuid",
    "amount": 500.00,
    "currency": "USD",
    "category": "MEALS",
    "merchant": "Steakhouse Inc",
    "receipt_hash": "sha256_hash_of_image",
    "expense_date": "2026-02-25T20:00:00Z",
    "image_tampering_flag": false
  }
}
```

### Output: `tripaxis.fraud.scored.v1`
```json
{
  "event_id": "uuid",
  "tenant_id": "uuid",
  "payload": {
    "expense_id": "uuid",
    "risk_score": 85,
    "risk_level": "HIGH",
    "confidence_score": 0.92,
    "risk_factors": [
      "EXCESSIVE_ROUND_NUMBER",
      "WEEKEND_EXPENSE",
      "ML_ANOMALY_DETECTED"
    ],
    "recommended_action": "FREEZE_FOR_AUDIT"
  }
}
```

---

## 3. ML Inference Flow & SLA Management
To meet the **< 2 seconds SLA**:
1.  **Feature Store:** OpenSearch acts as a low-latency feature store. Aggregations (e.g., `user_avg_meal_cost_30d`) are pre-calculated by a background Spark/Flink job, not calculated at inference time.
2.  **Model Format:** Python models are exported to ONNX format for ultra-fast CPU inference using ONNX Runtime.
3.  **Async Non-Blocking:** The Expense API returns `201 Created` immediately. The expense enters a `PENDING_ANALYSIS` state. The Fraud Service processes it asynchronously.

## 4. Deployment Model
*   **Kubernetes (EKS):** Both NestJS and FastAPI services are deployed as separate Deployments.
*   **HPA:** 
    *   NestJS scales based on RabbitMQ queue depth.
    *   FastAPI scales based on CPU utilization (target 60%).
*   **Hardware:** FastAPI pods are scheduled on compute-optimized nodes (e.g., AWS C6i instances) for fast mathematical operations.
