# TripAxis Data Pipeline & Model Registry Architecture

## 1. Scale Requirements
* **Users:** 50,000
* **Historical Records:** 10,000,000+
* **Inference SLA:** < 2 seconds

## 2. Data Pipeline Architecture (Batch & Streaming)

To support real-time anomaly detection without querying a massive relational database during inference, we use a Lambda Architecture:

### A. Batch Pipeline (Weekly Retraining & Profiling)
1. **Data Lake (AWS S3):** All expense records, audit logs, and fraud results are synced to S3 via AWS DMS (Database Migration Service) or Debezium CDC.
2. **Apache Spark (EMR / Databricks):** 
   * Runs nightly to calculate complex aggregations (Z-scores, IQRs, department means, typical vendors).
   * Generates the `UserBehaviorProfile` and `DepartmentBehaviorProfile`.
3. **Redis / OpenSearch Sync:** Spark writes the calculated profiles directly into Redis (for ultra-low latency O(1) lookups during inference) and OpenSearch (for complex dashboard querying).

### B. Streaming Pipeline (Real-Time Updates)
1. **Kafka / RabbitMQ:** As new expenses are approved, events flow through the message broker.
2. **Flink / Spark Structured Streaming:** Updates the Redis profiles incrementally (e.g., updating the 30-day moving average) so the anomaly detection is always using fresh data.

## 3. Model Registry & Versioning Strategy

We utilize **MLflow** as the central Model Registry.

### Lifecycle:
1. **Training (`train.py`):** Runs weekly via Apache Airflow. Pulls the latest 6 months of data from Snowflake/S3. Applies SMOTE for class imbalance.
2. **Evaluation:** If the new model's PR-AUC (Precision-Recall Area Under Curve) is > 2% better than the current production model, it is tagged as `Staging`.
3. **Shadow Deployment:** The `Staging` model is deployed alongside `Production` in Kubernetes. The NestJS orchestrator sends traffic to both, but only uses the `Production` score for routing. Metrics are compared in Grafana.
4. **Promotion:** If shadow metrics look good, the model is promoted to `Production` in MLflow. The FastAPI pods periodically poll MLflow and hot-reload the new model weights without dropping requests.
