# TripAxis SOC 2 Type II Readiness Framework

This framework outlines the technical and procedural controls required for TripAxis (a multi-tenant Travel & Expense SaaS) to achieve and maintain SOC 2 Type II compliance (Security, Availability, and Confidentiality trust service criteria).

---

## 1. Control Mapping to System Architecture

### 1. Access Control (CC6.1, CC6.2, CC6.3)
*   **Architecture Mapping:**
    *   **Application Level:** JWT Bearer tokens (Auth0/Keycloak) with strict RBAC.
    *   **Data Level:** PostgreSQL Row-Level Security (RLS) strictly isolates tenant data (`app.tenant_id`).
    *   **Infrastructure Level:** HashiCorp Vault manages dynamic, short-lived (24h) credentials for DB and Message Brokers. Kubernetes RBAC restricts developer access to production namespaces.
    *   **Network Level:** Cloudflare WAF, AWS Security Groups, and private VPC subnets.

### 2. Audit Logging (CC7.2)
*   **Architecture Mapping:**
    *   **Business Logic:** Immutable audit tables (`TravelAuditLog`, `ExpenseAuditLog`, `ApprovalAuditLog`) capture every state change, actor ID, and timestamp.
    *   **System Level:** Vault audit logs track all secret access. Kubernetes API server audit logs track infrastructure changes.
    *   **Centralization:** Logs are aggregated via FluentBit/OpenTelemetry and shipped to OpenSearch.

### 3. Incident Response (CC7.3, CC7.4)
*   **Architecture Mapping:**
    *   **Alerting:** Prometheus Alertmanager triggers PagerDuty/Opsgenie based on SLA breaches, high error rates, or infrastructure failures.
    *   **Mitigation:** Cloudflare DDoS protection and WAF rules automatically mitigate L7 attacks. Emergency Vault sealing and credential revocation runbooks are in place.

### 4. Change Management (CC8.1)
*   **Architecture Mapping:**
    *   **Infrastructure:** 100% Infrastructure as Code (Terraform).
    *   **Deployments:** GitOps via ArgoCD. No manual `kubectl apply` allowed in production.
    *   **Code:** Branch protection rules require at least 1 approving review and passing CI checks before merging to `main`.

### 5. Data Encryption (CC6.1, CC6.7)
*   **Architecture Mapping:**
    *   **In Transit:** Cloudflare enforces TLS 1.2/1.3 externally. Vault PKI issues short-lived certificates for internal mTLS between microservices.
    *   **At Rest:** AWS EBS volume encryption (KMS) for PostgreSQL and OpenSearch. S3/MinIO buckets use AES-256 server-side encryption.

### 6. Backup & Recovery (A1.2, A1.3)
*   **Architecture Mapping:**
    *   **Database:** Automated daily RDS Aurora snapshots with 30-day retention. Point-in-Time Recovery (PITR) enabled.
    *   **High Availability:** Active-Passive multi-region setup (US-East-1 to US-West-2) with a documented DR Runbook (RPO < 5 mins, RTO < 15 mins).

### 7. Vendor Management (CC3.2, CC9.2)
*   **Architecture Mapping:**
    *   **Critical Subservice Organizations:** AWS (Hosting), Cloudflare (DNS/WAF), SendGrid (Email), Auth0 (Identity).
    *   **Process:** Annual review of vendor SOC 2 reports and SLA adherence.

### 8. Secure SDLC (CC8.1)
*   **Architecture Mapping:**
    *   **CI Pipeline:** Automated SAST (e.g., SonarQube) and SCA (e.g., Snyk/Dependabot) scans on every PR.
    *   **Container Security:** Image scanning in the container registry (e.g., AWS ECR) before deployment.

### 9. Logging & Monitoring (CC7.1, CC7.2)
*   **Architecture Mapping:**
    *   **Metrics:** Prometheus scrapes metrics from NestJS, RabbitMQ, Redis, and PostgreSQL.
    *   **Dashboards:** Grafana visualizes system health, HPA scaling events, and error rates.
    *   **Tracing:** OpenTelemetry propagates `traceId` across RabbitMQ and HTTP boundaries for distributed request tracing.

### 10. Data Retention Policy (C1.1, C1.2)
*   **Architecture Mapping:**
    *   **Application Level:** Prisma schema implements soft deletes (`deletedAt`).
    *   **Cleanup:** Scheduled BullMQ jobs (e.g., `data-retention-sweep`) permanently delete or anonymize tenant data 90 days after contract termination or soft deletion.

---

## 2. Required Documentation List

To pass a SOC 2 Type II audit, TripAxis must formally document and enforce the following policies:

1.  **Information Security Policy (ISP):** The master document governing security practices.
2.  **Access Control Policy:** Rules for provisioning, reviewing, and de-provisioning user and employee access.
3.  **Incident Response Plan (IRP):** Step-by-step guide for classifying and handling security incidents.
4.  **Disaster Recovery & Business Continuity Plan (DR/BCP):** Includes the Active-Passive failover runbook.
5.  **Change Management Policy:** Defines the SDLC, PR requirements, and GitOps deployment process.
6.  **Data Classification & Handling Policy:** Defines Public, Internal, Confidential, and Restricted data (e.g., PII, financial data).
7.  **Data Retention & Disposal Policy:** Specifies the 90-day hard delete rule and backup lifecycle.
8.  **Vendor Risk Management Policy:** Procedure for onboarding and reviewing third-party vendors.
9.  **Acceptable Use Policy (AUP):** Signed by all employees during onboarding.
10. **System Architecture & Data Flow Diagrams:** Visual representation of the TripAxis infrastructure.

---

## 3. Gaps to Close (Pre-Audit Checklist)

While the TripAxis architecture is highly secure, the following gaps typically exist before a formal audit and must be closed:

### Technical Gaps
*   **Data Archival/Hard Deletion:** The current Prisma schema supports soft deletes, but a background cron job must be implemented to permanently purge data older than the retention period (e.g., 90 days).
*   **Vulnerability Scanning:** Ensure automated container image scanning (e.g., Trivy or ECR scanning) is blocking deployments if Critical/High CVEs are found.
*   **Access Reviews:** Implement an automated script to export AWS/GitHub/Keycloak users quarterly for management review.
*   **Endpoint Management (MDM):** Ensure all developer laptops have MDM installed (e.g., Jamf, Kandji) enforcing disk encryption, screen locks, and antivirus.

### Process Gaps
*   **Evidence Collection:** SOC 2 Type II requires evidence over a period of time (usually 3-12 months). We need to start capturing screenshots/logs of PR approvals, access grants, and incident post-mortems *now*.
*   **Security Awareness Training:** All employees must complete annual security training, with completion certificates stored for the auditor.
*   **Penetration Testing:** An independent third-party penetration test must be conducted on the API Gateway and Web App annually.
*   **Tabletop Exercises:** The DR Runbook and Incident Response Plan must be tested annually via a tabletop exercise, with documented results.

---

## 4. Estimated Implementation Effort

**Total Estimated Time to Readiness: 8 - 12 Weeks**

| Phase | Focus Area | Estimated Effort | Key Deliverables |
| :--- | :--- | :--- | :--- |
| **Phase 1 (Weeks 1-3)** | **Policy Creation & Approval** | High (Process) | Draft and approve the 10 core policies. Distribute AUP to employees. |
| **Phase 2 (Weeks 4-6)** | **Technical Gap Remediation** | Medium (Engineering) | Implement hard-delete cron jobs, enforce PR rules, setup Trivy/Snyk in CI/CD. |
| **Phase 3 (Weeks 7-8)** | **Monitoring & Alerting Tuning** | Low (DevOps) | Ensure OpenSearch logs are retained for 1 year. Tune PagerDuty alerts. |
| **Phase 4 (Weeks 9-10)** | **Third-Party Assessments** | Medium (External) | Execute external Penetration Test. Collect vendor SOC 2 reports. |
| **Phase 5 (Weeks 11-12)** | **Dry Run & Evidence Gathering** | Medium (Compliance) | Conduct DR tabletop exercise. Perform Q1 access review. Setup evidence repository (e.g., Vanta/Secureframe). |

*Recommendation:* Utilize a compliance automation platform like **Vanta** or **Secureframe**. These tools integrate directly with AWS, GitHub, and Google Workspace to continuously monitor controls and automatically collect >70% of the required evidence, significantly reducing engineering overhead.
