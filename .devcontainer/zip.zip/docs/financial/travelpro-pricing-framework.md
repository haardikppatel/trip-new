# TravelPro Enterprise SaaS: Financial Modeling & Pricing Framework

## 1. Executive Summary
This document outlines the financial modeling, pricing architecture, and commercial governance framework for **TravelPro**. Designed for enterprise procurement, this model prioritizes predictability, transparency, and scalable global expansion. By decoupling infrastructure, entity governance, and user access, TravelPro establishes a premium market position while maintaining highly competitive blended per-user economics.

---

## 2. Pricing Architecture (The 4 Pillars)

The TravelPro pricing model is structured to capture value across four distinct dimensions of enterprise complexity:

### Pillar 1: Enterprise Platform Activation Fee
*   **Price:** $90,000 / year
*   **Includes:** Core platform, global policy engine, multi-currency/entity architecture, standard ERP/HRIS integrations, SLA-backed support, and **3 Admin/General User licenses**.
*   **FinOps Rationale:** Covers fixed infrastructure costs (Kubernetes, Database clusters, Security appliances) and establishes a premium anchor price just below the psychological $100K procurement threshold.

### Pillar 2: Entity Governance & Compliance License
*   **Price:** $4,000 / subsidiary / year
*   **Includes:** Local compliance configuration, tax/regulatory logic, ledger mapping, and entity-level policy controls.
*   **FinOps Rationale:** Global expansion introduces non-linear complexity. This linear pricing model ensures fair scaling aligned to operational expansion without arbitrary bundling or entity caps.

### Pillar 3: Employee License (Per Active Employee)
*   **Price:** $12 / employee / month (Billed Annually = $144/year)
*   **Includes:** Expense submission, travel booking, approvals, mobile app, and standard reporting.
*   **Volume Discount Structure:**
    | Employee Count | Discount | Effective Monthly Rate | Annual Rate per Employee |
    | :--- | :--- | :--- | :--- |
    | 1 – 5,000 | 0% | $12.00 | $144.00 |
    | 5,001 – 10,000 | 10% | $10.80 | $129.60 |
    | 10,001 – 20,000 | 18% | $9.84 | $118.08 |
    | 20,000+ | 25% (Cap) | $9.00 | $108.00 |
*   **FinOps Rationale:** Covers variable compute, storage, and standard support costs. The transparent volume tiers provide built-in negotiation flexibility while protecting gross margins.

### Pillar 4: Admin / General User License
*   **Price:** $2,200 / admin / year (Prepaid) OR $200 / admin / month
*   **Includes:** System administrators, travel managers, finance controllers, compliance officers. (First 3 included in Platform Fee).
*   **FinOps Rationale:** Prevents excessive admin allocation, protects the governance model, and provides a high-margin revenue lever for complex organizations requiring heavy oversight.

---

## 3. Revenue Calculation Engine (CPQ Logic)

To operationalize this in Salesforce CPQ or Excel, the Annual Contract Value (ACV) formula is:

**Total ACV = Platform Fee + (Subsidiaries × $4k) + (Employees × Effective Annual Rate) + (Max(0, Admins - 3) × $2.2k)**

### Scenario Modeling (ACV Projections)

| Metric | Mid-Market | Enterprise (Base) | Large Enterprise |
| :--- | :--- | :--- | :--- |
| **Employees** | 1,500 | 3,000 | 15,000 |
| **Subsidiaries** | 5 | 15 | 40 |
| **Admins** | 5 | 8 | 20 |
| **Platform Fee** | $90,000 | $90,000 | $90,000 |
| **Subsidiary Revenue** | $20,000 | $60,000 | $160,000 |
| **Employee Revenue** | $216,000 | $432,000 | $1,771,200 *(18% discount)* |
| **Admin Revenue** | $4,400 *(2 paid)* | $11,000 *(5 paid)* | $37,400 *(17 paid)* |
| **Total ACV** | **$330,400** | **$593,000** | **$2,058,600** |
| **Blended Cost / Emp / Yr** | $220.26 | $197.66 | $137.24 |
| **Blended Cost / Emp / Mo** | **$18.35** | **$16.47** | **$11.43** |

*Notice how the blended cost per employee naturally compresses as the organization scales, demonstrating economies of scale to the procurement buyer while driving massive ACV expansion for TravelPro.*

---

## 4. Discount Governance & Margin Protection

To prevent margin erosion and maintain premium brand positioning, all discounting must adhere to the following strict governance matrix.

### Discount Authority Matrix
| Role | Max Discount Authority | Conditions / Triggers |
| :--- | :--- | :--- |
| **Sales Representative** | Up to 10% | Standard competitive pressure. |
| **Sales Director** | Up to 20% | Multi-year prepay, end-of-quarter leverage. |
| **CRO** | Up to 35% | Strategic logo acquisition, displacement of Concur/Coupa. |
| **CEO** | Up to 50% | Strategic Accounts Only. Requires board-level visibility. |

### Commercial Rules of Engagement
1. **No Open-Ended Discounts:** All discounts are locked for the initial contract duration only.
2. **Renewal Reviews:** Discounts are reviewed at renewal. "Founder" or "Early Adopter" discounts must include time-bound step-up clauses (e.g., Year 1: 30% off, Year 2: 15% off, Year 3: List Price).
3. **Written Justification:** Any discount above 20% requires a written business case in the CRM detailing the strategic value of the logo or the competitive threat.
4. **No Modular Waiving:** The Platform Fee ($90k) and Subsidiary Fees ($4k) are **hard costs** and should be the *last* levers pulled in negotiations. Discounts should primarily be applied to the Employee License tier.

---

## 5. Competitive Positioning & Market Strategy

When facing procurement teams, TravelPro's pricing model is a strategic weapon against legacy incumbents.

*   **vs. SAP Concur:** Concur relies on complex, opaque bundling and transaction-based metering (charging per expense report). **TravelPro Counter:** We offer a predictable, flat per-employee rate. No penalizing companies for high travel volume.
*   **vs. Navan:** Navan uses a hybrid commission + SaaS model, often hiding costs in travel booking kickbacks. **TravelPro Counter:** 100% transparent SaaS structure. No hidden API fees, no infrastructure metering, and a cleaner governance model.
*   **vs. Coupa:** Coupa uses enterprise-heavy, rigid pricing that makes global expansion cost-prohibitive. **TravelPro Counter:** Our linear $4k/subsidiary model makes global M&A and expansion predictable and fair.

## 6. FinOps & Unit Economics Alignment

This pricing model perfectly aligns revenue with cloud infrastructure costs:
*   **Platform Fee ($90k):** Subsidizes the baseline High-Availability Kubernetes clusters, multi-region database replication, and base compliance overhead.
*   **Subsidiary Fee ($4k):** Covers the database sharding/RLS overhead, localized data residency requirements, and dedicated audit log storage.
*   **Employee Fee ($12/mo):** Covers variable compute (CPU/RAM scaling via HPA), S3 storage for receipt uploads, and RabbitMQ message throughput.
*   **Admin Fee ($2.2k):** Covers the heavy read-query load generated by complex financial reporting and analytics dashboards.
