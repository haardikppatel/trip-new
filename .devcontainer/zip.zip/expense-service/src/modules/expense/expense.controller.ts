import { Controller, Post, Body, Param, UseGuards, Get, Query } from '@nestjs/common';
import { ExpenseService } from './expense.service';
import { ApiResponse, TenantContext } from '@tripaxis/core';
import { TenantGuard } from '../../common/guards/tenant.guard';

@UseGuards(TenantGuard)
@Controller('v1/expenses')
export class ExpenseController {
  constructor(private readonly expenseService: ExpenseService) {}

  @Post('submit')
  async submit(@Body() dto: any) {
    const result = await this.expenseService.submitClaim(dto);
    return ApiResponse.success(result);
  }

  @Get('receipt-upload-url')
  async getUploadUrl(@Query('fileName') fileName: string, @Query('mimeType') mimeType: string) {
    const result = await this.expenseService.generateReceiptUploadUrl(fileName, mimeType);
    return ApiResponse.success(result);
  }

  @Post(':id/approve')
  async approve(@Param('id') id: string, @Body('reason') reason?: string) {
    const result = await this.expenseService.approveClaim(id, reason);
    return ApiResponse.success(result);
  }
}
