import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaClient, ExpenseStatus } from '@prisma/client';
import { TenantContext, InvalidStateTransitionError } from '@tripaxis/core';
import { EventPublisher } from '../../infrastructure/events/event.publisher';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class ExpenseService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly eventPublisher: EventPublisher,
  ) {}

  async submitClaim(dto: any) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();

    // 1. Calculate totals and handle currency conversion (mocked)
    let totalAmount = 0;
    const lineItems = dto.lineItems.map((item: any) => {
      const exchangeRate = item.currency === 'USD' ? 1.0 : 1.2; // Mock FX
      const convertedAmount = item.amount * exchangeRate;
      totalAmount += convertedAmount;

      return {
        tenantId,
        categoryId: item.categoryId,
        date: new Date(item.date),
        amount: item.amount,
        currency: item.currency,
        exchangeRate,
        convertedAmount,
        description: item.description,
        receiptUrl: item.receiptUrl,
      };
    });

    // 2. Policy Validation (Mocked)
    // if (totalAmount > policyLimit) throw PolicyViolationError;

    // 3. Persist Claim
    const claim = await this.prisma.$transaction(async (tx) => {
      const c = await tx.expenseClaim.create({
        data: {
          tenantId,
          userId,
          travelRequestId: dto.travelRequestId,
          title: dto.title,
          status: ExpenseStatus.SUBMITTED,
          totalAmount,
          currency: 'USD', // Base currency
          submittedAt: new Date(),
          lineItems: { create: lineItems },
        },
        include: { lineItems: true },
      });

      await tx.expenseAuditLog.create({
        data: {
          tenantId,
          expenseClaimId: c.id,
          action: 'SUBMITTED',
          changedBy: userId,
          previousStatus: ExpenseStatus.DRAFT,
          newStatus: ExpenseStatus.SUBMITTED,
          reason: 'Initial submission',
        },
      });

      return c;
    });

    // 4. Emit Event
    await this.eventPublisher.publish('ExpenseSubmitted:v1', {
      expenseClaimId: claim.id,
      userId,
      totalAmount,
    });

    return claim;
  }

  async generateReceiptUploadUrl(fileName: string, mimeType: string) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    const fileKey = `${tenantId}/${userId}/${uuidv4()}-${fileName}`;

    // Mock S3 Presigned URL generation
    // const command = new PutObjectCommand({ Bucket: 'tripaxis-receipts', Key: fileKey, ContentType: mimeType });
    // const uploadUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });

    return {
      uploadUrl: `https://s3.amazonaws.com/tripaxis-receipts/${fileKey}?signature=mock`,
      fileKey,
    };
  }

  async approveClaim(id: string, reason?: string) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();

    const claim = await this.prisma.expenseClaim.findUnique({ where: { id } });
    if (!claim) throw new NotFoundException('Expense claim not found');
    if (claim.status !== ExpenseStatus.SUBMITTED && claim.status !== ExpenseStatus.PENDING_APPROVAL) {
      throw new InvalidStateTransitionError(claim.status, ExpenseStatus.APPROVED);
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      const c = await tx.expenseClaim.update({
        where: { id },
        data: { status: ExpenseStatus.APPROVED },
      });

      await tx.expenseAuditLog.create({
        data: {
          tenantId,
          expenseClaimId: c.id,
          action: 'APPROVED',
          changedBy: userId,
          previousStatus: claim.status,
          newStatus: ExpenseStatus.APPROVED,
          reason,
        },
      });

      return c;
    });

    await this.eventPublisher.publish('ExpenseApproved:v1', {
      expenseClaimId: updated.id,
      userId: updated.userId,
      totalAmount: updated.totalAmount,
    });

    return updated;
  }
}
