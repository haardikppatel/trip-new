import { Injectable } from '@nestjs/common';
import { Histogram, Counter } from 'prom-client';

@Injectable()
export class FraudMetricsService {
  public readonly processingTime = new Histogram({
    name: 'tripaxis_fraud_processing_duration_seconds',
    help: 'Time taken to orchestrate rules and ML inference',
    buckets: [0.1, 0.5, 1, 2, 5], // SLA is < 2 seconds
  });

  public readonly fraudScores = new Histogram({
    name: 'tripaxis_fraud_score_distribution',
    help: 'Distribution of final risk scores',
    labelNames: ['tenant_id', 'risk_level'],
    buckets: [10, 30, 50, 70, 90, 100],
  });

  public readonly processingErrors = new Counter({
    name: 'tripaxis_fraud_processing_errors_total',
    help: 'Total number of errors during fraud orchestration',
  });
}
