import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventPublisher } from '../../infrastructure/events/event.publisher';
import { FraudMetricsService } from './fraud.metrics';
import { FraudRuleEngine, RuleContext } from './rule.engine';
import { FraudRuleService } from './rule.service';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

export enum RiskLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL'
}

export enum RecommendedAction {
  AUTO_APPROVE = 'AUTO_APPROVE',
  ROUTE_TO_MANAGER = 'ROUTE_TO_MANAGER',
  ROUTE_TO_FINANCE = 'ROUTE_TO_FINANCE',
  FREEZE_FOR_AUDIT = 'FREEZE_FOR_AUDIT'
}

@Injectable()
export class FraudOrchestratorService {
  private readonly logger = new Logger(FraudOrchestratorService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly ruleEngine: FraudRuleEngine,
    private readonly ruleService: FraudRuleService,
    private readonly httpService: HttpService,
    private readonly eventPublisher: EventPublisher,
    private readonly metrics: FraudMetricsService,
  ) {}

  async processExpense(expense: any, tenantId: string): Promise<void> {
    const endTimer = this.metrics.processingTime.startTimer();
    
    try {
      // 1. Evaluate Deterministic Rules
      const rules = await this.ruleService.getTenantRules(tenantId);
      const context = await this.gatherContext(expense, tenantId); // DB lookups
      const ruleResult = this.ruleEngine.evaluate(expense, rules, context);

      // 2. Call ML Inference API (Python FastAPI)
      const mlResponse = await this.callMlInference(expense, tenantId, ruleResult.ruleScore);

      // 3. Fetch Tenant Configurable Ensemble Weights (Fallback to defaults)
      const weights = await this.getTenantWeights(tenantId);

      // 4. Calculate Final Risk Score (Weighted Ensemble Strategy)
      // rule_score (0-100), anomaly_score (0-100), ml_probability (0.0-1.0 -> 0-100)
      const mlScoreInt = Math.round(mlResponse.ml_probability * 100);
      
      const finalRiskScore = Math.round(
        (ruleResult.ruleScore * weights.ruleWeight) +
        (mlResponse.anomaly_score * weights.anomalyWeight) +
        (mlScoreInt * weights.mlWeight)
      );

      // 5. Apply Routing Logic
      const { riskLevel, action } = this.determineRouting(finalRiskScore);

      // 6. Save Result & Audit Log
      await this.prisma.$transaction(async (tx) => {
        await tx.fraudResult.create({
          data: {
            tenantId,
            expenseId: expense.id,
            riskScore: finalRiskScore,
            riskLevel,
            confidenceScore: 0.95, // Mocked confidence
            riskFactors: ruleResult.triggeredRules,
            ruleScore: ruleResult.ruleScore,
            mlScore: mlScoreInt,
            recommendedAction: action,
          }
        });

        await tx.fraudAuditLog.create({
          data: {
            tenantId,
            expenseId: expense.id,
            action: 'SCORED',
            details: { finalRiskScore, riskLevel, action, shap: mlResponse.shap_explanations }
          }
        });
      });

      // 7. Publish Event for Workflow Engine
      await this.eventPublisher.publish('tripaxis.fraud.scored.v1', {
        tenantId,
        expenseId: expense.id,
        riskScore: finalRiskScore,
        riskLevel,
        recommendedAction: action,
        riskFactors: ruleResult.triggeredRules
      });

      // 8. Record Metrics
      this.metrics.fraudScores.observe({ tenant_id: tenantId, risk_level: riskLevel }, finalRiskScore);
      this.logger.log(`Expense ${expense.id} scored: ${finalRiskScore} (${riskLevel}) -> ${action}`);

    } catch (error) {
      this.logger.error(`Failed to process fraud for expense ${expense.id}`, error);
      this.metrics.processingErrors.inc();
      throw error;
    } finally {
      endTimer();
    }
  }

  private determineRouting(score: number): { riskLevel: RiskLevel, action: RecommendedAction } {
    if (score < 30) return { riskLevel: RiskLevel.LOW, action: RecommendedAction.AUTO_APPROVE };
    if (score <= 60) return { riskLevel: RiskLevel.MEDIUM, action: RecommendedAction.ROUTE_TO_MANAGER };
    if (score <= 80) return { riskLevel: RiskLevel.HIGH, action: RecommendedAction.ROUTE_TO_FINANCE };
    return { riskLevel: RiskLevel.CRITICAL, action: RecommendedAction.FREEZE_FOR_AUDIT };
  }

  private async callMlInference(expense: any, tenantId: string, ruleScore: number): Promise<any> {
    const payload = {
      tenant_id: tenantId,
      user_id: expense.userId,
      department_id: expense.departmentId,
      expense_id: expense.id,
      amount: expense.amount,
      category: expense.category,
      merchant: expense.merchant,
      time_of_submission: new Date().toISOString(),
      rule_score: ruleScore,
      user_tenure_days: 365, // Mock
      historical_rejection_rate: 0.05 // Mock
    };

    const mlApiUrl = process.env.ML_SERVICE_URL || 'http://ml-service:8000/v1/infer';
    const response = await firstValueFrom(this.httpService.post(mlApiUrl, payload));
    return response.data;
  }

  private async getTenantWeights(tenantId: string) {
    // In production, fetch from DB. Using defaults here.
    return {
      ruleWeight: 0.40,
      anomalyWeight: 0.30,
      mlWeight: 0.30
    };
  }

  private async gatherContext(expense: any, tenantId: string): Promise<RuleContext> {
    // Mocked DB lookups for context
    return {
      isDuplicateHash: false,
      isCrossTenantHash: false,
      departmentMeanAmount: 150,
      submissionsPast24h: 1,
      suspiciousVendors: ['FakeCorp']
    };
  }
}
