import { Injectable } from '@nestjs/common';

export interface ExpenseData {
  amount: number;
  currency: string;
  category: string;
  merchant: string;
  expenseDate: Date;
  receiptHash: string;
  imageTamperingFlag: boolean;
}

export interface RuleContext {
  isDuplicateHash: boolean;
  isCrossTenantHash: boolean;
  departmentMeanAmount: number;
  travelStartDate?: Date;
  travelEndDate?: Date;
  submissionsPast24h: number;
  suspiciousVendors: string[];
}

export interface RuleConfig {
  ruleCode: string;
  isActive: boolean;
  weight: number;
  parameters?: any;
}

export interface RuleEvaluationResult {
  ruleScore: number;
  triggeredRules: string[];
}

@Injectable()
export class FraudRuleEngine {
  
  public evaluate(expense: ExpenseData, rules: RuleConfig[], context: RuleContext): RuleEvaluationResult {
    let totalScore = 0;
    const triggeredRules: string[] = [];

    // Create a map for fast lookup
    const activeRules = new Map(rules.filter(r => r.isActive).map(r => [r.ruleCode, r]));

    // 1. Duplicate receipt detection (hash match)
    if (activeRules.has('DUPLICATE_RECEIPT') && context.isDuplicateHash) {
      this.triggerRule('DUPLICATE_RECEIPT', activeRules, triggeredRules, (weight) => totalScore += weight);
    }

    // 2. Same receipt used across tenants
    if (activeRules.has('CROSS_TENANT_RECEIPT') && context.isCrossTenantHash) {
      this.triggerRule('CROSS_TENANT_RECEIPT', activeRules, triggeredRules, (weight) => totalScore += weight);
    }

    // 3. Weekend expense outside policy
    if (activeRules.has('WEEKEND_EXPENSE')) {
      const day = expense.expenseDate.getUTCDay();
      if (day === 0 || day === 6) { // 0 = Sunday, 6 = Saturday
        this.triggerRule('WEEKEND_EXPENSE', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 4. Excessive round-number claims
    if (activeRules.has('ROUND_NUMBER_CLAIM')) {
      if (expense.amount > 0 && expense.amount % 10 === 0) {
        this.triggerRule('ROUND_NUMBER_CLAIM', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 5. Rapid submission frequency anomaly
    if (activeRules.has('RAPID_SUBMISSION')) {
      const threshold = activeRules.get('RAPID_SUBMISSION')?.parameters?.maxPer24h || 10;
      if (context.submissionsPast24h > threshold) {
        this.triggerRule('RAPID_SUBMISSION', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 6. Expense exceeds department mean by 3x
    if (activeRules.has('EXCEEDS_DEPT_MEAN')) {
      const multiplier = activeRules.get('EXCEEDS_DEPT_MEAN')?.parameters?.multiplier || 3;
      if (context.departmentMeanAmount > 0 && expense.amount > (context.departmentMeanAmount * multiplier)) {
        this.triggerRule('EXCEEDS_DEPT_MEAN', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 7. Suspicious vendor blacklist
    if (activeRules.has('SUSPICIOUS_VENDOR')) {
      const isSuspicious = context.suspiciousVendors.some(v => 
        expense.merchant.toLowerCase().includes(v.toLowerCase())
      );
      if (isSuspicious) {
        this.triggerRule('SUSPICIOUS_VENDOR', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 8. Receipt date mismatch with travel dates
    if (activeRules.has('DATE_MISMATCH') && context.travelStartDate && context.travelEndDate) {
      if (expense.expenseDate < context.travelStartDate || expense.expenseDate > context.travelEndDate) {
        this.triggerRule('DATE_MISMATCH', activeRules, triggeredRules, (weight) => totalScore += weight);
      }
    }

    // 9. Image tampering detection flag input
    if (activeRules.has('IMAGE_TAMPERED') && expense.imageTamperingFlag) {
      this.triggerRule('IMAGE_TAMPERED', activeRules, triggeredRules, (weight) => totalScore += weight);
    }

    // Cap score at 100
    return {
      ruleScore: Math.min(totalScore, 100),
      triggeredRules,
    };
  }

  private triggerRule(
    ruleCode: string, 
    activeRules: Map<string, RuleConfig>, 
    triggeredRules: string[], 
    addScore: (weight: number) => void
  ) {
    const rule = activeRules.get(ruleCode);
    if (rule) {
      triggeredRules.push(ruleCode);
      addScore(rule.weight);
    }
  }
}
