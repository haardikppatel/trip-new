import { Injectable, Inject, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { Redis } from 'ioredis';
import { RuleConfig } from './rule.engine';

@Injectable()
export class FraudRuleService {
  private readonly logger = new Logger(FraudRuleService.name);
  private readonly CACHE_TTL = 3600; // 1 hour

  constructor(
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
    @Inject('REDIS_CLIENT') private readonly redis: Redis,
  ) {}

  /**
   * Fetches rules for a tenant. Uses Redis cache for ultra-fast evaluation.
   */
  async getTenantRules(tenantId: string): Promise<RuleConfig[]> {
    const cacheKey = `fraud:rules:${tenantId}`;
    
    // 1. Try Cache
    const cached = await this.redis.get(cacheKey);
    if (cached) {
      return JSON.parse(cached);
    }

    // 2. Fallback to DB
    const rules = await this.prisma.fraudRule.findMany({
      where: { tenantId, isActive: true },
      select: { ruleCode: true, isActive: true, weight: true, parameters: true }
    });

    // 3. Update Cache
    await this.redis.set(cacheKey, JSON.stringify(rules), 'EX', this.CACHE_TTL);
    
    return rules as RuleConfig[];
  }

  /**
   * Dynamically reloads rules by invalidating the cache.
   * Called when a tenant admin updates their fraud settings.
   */
  async invalidateTenantRules(tenantId: string): Promise<void> {
    const cacheKey = `fraud:rules:${tenantId}`;
    await this.redis.del(cacheKey);
    this.logger.log(`Invalidated fraud rule cache for tenant ${tenantId}`);
  }
}
