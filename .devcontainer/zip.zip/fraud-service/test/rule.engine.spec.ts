import { FraudRuleEngine, ExpenseData, RuleContext, RuleConfig } from '../src/modules/fraud/rule.engine';

describe('FraudRuleEngine', () => {
  let engine: FraudRuleEngine;

  const defaultRules: RuleConfig[] = [
    { ruleCode: 'DUPLICATE_RECEIPT', isActive: true, weight: 100 },
    { ruleCode: 'WEEKEND_EXPENSE', isActive: true, weight: 20 },
    { ruleCode: 'ROUND_NUMBER_CLAIM', isActive: true, weight: 10 },
    { ruleCode: 'EXCEEDS_DEPT_MEAN', isActive: true, weight: 40, parameters: { multiplier: 3 } },
    { ruleCode: 'IMAGE_TAMPERED', isActive: true, weight: 100 },
  ];

  const defaultContext: RuleContext = {
    isDuplicateHash: false,
    isCrossTenantHash: false,
    departmentMeanAmount: 50,
    submissionsPast24h: 2,
    suspiciousVendors: ['FakeCorp'],
  };

  beforeEach(() => {
    engine = new FraudRuleEngine();
  });

  it('should return 0 score for a clean expense', () => {
    const expense: ExpenseData = {
      amount: 45.50,
      currency: 'USD',
      category: 'MEALS',
      merchant: 'Good Restaurant',
      expenseDate: new Date('2026-02-25T12:00:00Z'), // Wednesday
      receiptHash: 'hash123',
      imageTamperingFlag: false,
    };

    const result = engine.evaluate(expense, defaultRules, defaultContext);

    expect(result.ruleScore).toBe(0);
    expect(result.triggeredRules.length).toBe(0);
  });

  it('should trigger weekend and round number rules', () => {
    const expense: ExpenseData = {
      amount: 100.00, // Round number
      currency: 'USD',
      category: 'MEALS',
      merchant: 'Good Restaurant',
      expenseDate: new Date('2026-02-28T12:00:00Z'), // Saturday
      receiptHash: 'hash123',
      imageTamperingFlag: false,
    };

    const result = engine.evaluate(expense, defaultRules, defaultContext);

    expect(result.ruleScore).toBe(30); // 20 (weekend) + 10 (round number)
    expect(result.triggeredRules).toContain('WEEKEND_EXPENSE');
    expect(result.triggeredRules).toContain('ROUND_NUMBER_CLAIM');
  });

  it('should cap score at 100 for severe violations', () => {
    const expense: ExpenseData = {
      amount: 500.00, // Exceeds dept mean (50 * 3 = 150)
      currency: 'USD',
      category: 'MEALS',
      merchant: 'Good Restaurant',
      expenseDate: new Date('2026-02-25T12:00:00Z'),
      receiptHash: 'hash123',
      imageTamperingFlag: true, // Tampered!
    };

    const context = { ...defaultContext, isDuplicateHash: true }; // Duplicate!

    const result = engine.evaluate(expense, defaultRules, context);

    // 100 (duplicate) + 100 (tampered) + 40 (exceeds mean) = 240 -> capped at 100
    expect(result.ruleScore).toBe(100);
    expect(result.triggeredRules).toContain('DUPLICATE_RECEIPT');
    expect(result.triggeredRules).toContain('IMAGE_TAMPERED');
    expect(result.triggeredRules).toContain('EXCEEDS_DEPT_MEAN');
  });
});
