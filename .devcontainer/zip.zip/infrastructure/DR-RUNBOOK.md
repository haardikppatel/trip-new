# TripAxis Disaster Recovery Runbook

## Architecture Overview
TripAxis operates in an **Active-Passive** multi-region architecture.
* **Region A (Active):** Handles 100% of production traffic.
* **Region B (Passive):** Maintains streaming replicas of all stateful data. Compute (EKS) is scaled down to minimize costs but is ready to scale up.
* **Target RPO (Recovery Point Objective):** < 5 minutes.
* **Target RTO (Recovery Time Objective):** < 15 minutes.

---

## Failover Sequence Steps (Region A -> Region B)

### Phase 1: Detection & Traffic Routing (Minutes 0-2)
1. **Cloudflare Health Checks Fail:** Cloudflare detects 5 consecutive failures from Region A's ingress.
2. **Automated DNS Failover:** Cloudflare automatically updates the origin pool to route traffic to Region B's load balancer.
   * *Note:* At this point, Region B's API gateways will return `503 Service Unavailable` or `Read-Only` errors until stateful services are promoted.

### Phase 2: Stateful Service Promotion (Minutes 2-7)
1. **PostgreSQL Failover:**
   * Trigger RDS Aurora Global Database failover (or promote the streaming replica to a standalone primary).
   * *Command:* `aws rds promote-read-replica --db-instance-identifier tripaxis-pg-replica-b`
2. **Redis Failover:**
   * Promote ElastiCache Global Datastore replica in Region B to primary.
3. **RabbitMQ Federation:**
   * Region B's RabbitMQ cluster is already receiving federated messages. Update upstream links if necessary.
4. **MinIO / S3:**
   * S3 Cross-Region Replication is active-active. No promotion needed.

### Phase 3: Compute Scale-Up (Minutes 7-12)
1. **ArgoCD / HPA Trigger:**
   * Region B's EKS cluster has Horizontal Pod Autoscalers (HPA) configured with a minimum replica count of 1 (for cost savings).
   * Update the `values-prod-us-west-2.yaml` in the GitOps repository to set `minReplicas: 10` (matching Region A).
   * ArgoCD automatically syncs and scales the deployments.
2. **Cluster Autoscaler:**
   * EKS Cluster Autoscaler provisions new EC2 nodes across the Multi-AZ node groups in Region B to accommodate the pod scale-up.

### Phase 4: Verification (Minutes 12-15)
1. Run automated smoke tests against Region B endpoints.
2. Verify Database write capabilities.
3. Verify RabbitMQ consumer processing.
4. Declare Failover Complete.

---

## Risk Analysis & Mitigation

| Risk | Impact | Mitigation Strategy |
| :--- | :--- | :--- |
| **Split-Brain Syndrome** | High (Data Corruption) | Ensure Region A is completely fenced off (network isolated or DB demoted) before promoting Region B. Cloudflare must strictly route to only one region. |
| **Replication Lag (RPO Breach)** | Medium (Data Loss) | PostgreSQL streaming replication is typically sub-second. Monitor `replica_lag` metrics in Prometheus. If lag > 1 minute, alert engineering immediately. |
| **Cold Cache in Region B** | Low (Performance Degradation) | Redis replication ensures cache is warm. However, application-level in-memory caches will be cold. Expect a temporary spike in DB read IOPS post-failover. |
| **EKS Scale-Up Delays** | Medium (RTO Breach) | EC2 node provisioning can take 2-4 minutes. Keep a small pool of over-provisioned nodes (pause pods) in Region B to ensure instant pod scheduling during the critical first 5 minutes. |
| **Message Duplication** | Low (Data Inconsistency) | RabbitMQ federation guarantees at-least-once delivery. All consumers in TripAxis are designed to be **idempotent** (e.g., Approval Engine uses Redis locks). |

## Upgrade Path to Active-Active
To transition from Active-Passive to Active-Active:
1. **Database:** Migrate from Aurora PostgreSQL to a distributed SQL database (e.g., CockroachDB or YugabyteDB) to support multi-region synchronous writes.
2. **Routing:** Configure Cloudflare for Geo-Routing (latency-based routing) to send users to their closest region.
3. **Compute:** Keep EKS clusters in both regions fully scaled.
