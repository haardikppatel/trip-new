import { Injectable, OnModuleDestroy, Logger } from '@nestjs/common';
import { Server } from 'http';
import { PrismaClient } from '@prisma/client';
import { Connection } from 'amqplib';

@Injectable()
export class GracefulShutdownService implements OnModuleDestroy {
  private readonly logger = new Logger(GracefulShutdownService.name);

  constructor(
    private readonly httpServer: Server,
    private readonly prisma: PrismaClient,
    private readonly rabbitmq: Connection,
  ) {}

  /**
   * Triggered by Kubernetes sending SIGTERM to the pod.
   * Note: The pod's preStop hook (`sleep 15`) runs BEFORE this is triggered,
   * ensuring Cilium/kube-proxy has already removed the pod from the service endpoints.
   */
  async onModuleDestroy() {
    this.logger.warn('SIGTERM received. Initiating graceful shutdown...');

    // 1. Stop accepting new HTTP requests immediately
    await new Promise<void>((resolve, reject) => {
      this.httpServer.close((err) => {
        if (err) {
          this.logger.error('Error closing HTTP server', err);
          return reject(err);
        }
        this.logger.log('HTTP server closed. No longer accepting new connections.');
        resolve();
      });
    });

    // 2. Wait for active requests/jobs to finish (Drain phase)
    // In a real app, you might track active requests with a counter.
    this.logger.log('Draining active requests for 5 seconds...');
    await new Promise((resolve) => setTimeout(resolve, 5000));

    // 3. Close external connections gracefully
    try {
      await this.rabbitmq.close();
      this.logger.log('RabbitMQ connection closed.');
      
      await this.prisma.$disconnect();
      this.logger.log('PostgreSQL connections closed.');
    } catch (err) {
      this.logger.error('Error closing external connections', err);
    }

    this.logger.log('Graceful shutdown complete. Exiting process.');
    process.exit(0);
  }
}
