# TripAxis Scaling Math & Cost Optimization Strategy

## 1. Scaling Math & Algorithms

Kubernetes HPA calculates desired replicas using the following formula:
`desiredReplicas = ceil[currentReplicas * ( currentMetricValue / desiredMetricValue )]`

### API Services (Travel & Expense)
**Metrics:** CPU (Target: 70%) & Memory (Target: 80%)
*   **Why 70% CPU?** Node.js is single-threaded for the event loop. Pushing CPU beyond 70-80% causes event loop lag, drastically increasing P99 latency.
*   **Math Example:** 
    *   Current Replicas: 3
    *   Current CPU Average: 95%
    *   Target CPU: 70%
    *   `ceil[3 * (95 / 70)] = ceil[4.07] = 5 replicas`

### Worker Services (Notification & Workflow Engine)
**Metrics:** Queue Depth (RabbitMQ) & Job Backlog (BullMQ)
*   **Target:** 50 messages per pod.
*   **Why Queue Depth?** Workers might be waiting on external I/O (e.g., SendGrid API) and consuming very little CPU, yet the queue is backing up. CPU is a poor scaling metric for I/O-bound workers.
*   **Math Example:**
    *   Current Replicas: 2
    *   Current Queue Depth: 1,200 messages
    *   Target: 50 messages/pod
    *   `ceil[1200 / 50] = 24 replicas`

---

## 2. Resource Requests & Limits Best Practices

For production Node.js/NestJS applications on Kubernetes:
*   **Memory:** `requests` MUST equal `limits` (Guaranteed QoS). If limits > requests, the node can overcommit memory, leading to sudden OOMKilled pods during traffic spikes.
*   **CPU:** `requests` should be realistic (e.g., 500m), `limits` should be higher (e.g., 1000m) to allow burstable startup times. CPU throttling is better than OOM kills.
*   **Node.js Flags:** Always set `--max-old-space-size` to ~75% of the container memory limit to leave room for off-heap memory (C++ addons, buffers).

---

## 3. Cost Optimization Guidance

1.  **Spot Instances for Workers:**
    *   Notification Service and Workflow Engine process asynchronous, idempotent jobs. They are perfect candidates for AWS Spot Instances (or GCP Preemptible VMs), saving up to 70% on compute.
    *   Use Node Affinity/Taints to schedule workers on Spot nodes, and API services on On-Demand nodes.
2.  **Scale to Zero (or One):**
    *   During off-peak hours (e.g., weekends for B2B SaaS), scale API services down to 2 replicas and Workers down to 1 (or 0 using KEDA).
3.  **Right-Sizing with VPA:**
    *   Run Vertical Pod Autoscaler (VPA) in `Recommendation` mode to analyze actual usage over 30 days and adjust Helm chart requests/limits accordingly.
4.  **Karpenter / Cluster Autoscaler:**
    *   Use Karpenter for faster, cost-optimized node provisioning. It automatically selects the cheapest EC2 instance type that fits the pending pods' resource requests.
