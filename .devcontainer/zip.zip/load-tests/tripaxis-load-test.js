import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Rate, Trend, Gauge } from 'k6/metrics';

// Custom Metrics
const travelSubmissions = new Counter('tripaxis_travel_submissions');
const approvalDecisions = new Counter('tripaxis_approval_decisions');
const slaEscalations = new Counter('tripaxis_sla_escalations');
const expenseUploads = new Counter('tripaxis_expense_uploads');
const rateLimitHits = new Counter('tripaxis_rate_limit_hits');

const errorRate = new Rate('tripaxis_error_rate');
const cpuEstimation = new Gauge('tripaxis_cpu_estimation_cores');
const memEstimation = new Gauge('tripaxis_memory_estimation_mb');

// Configuration
const BASE_URL = __ENV.API_URL || 'http://localhost:3000';
const TENANT_ID = 'tenant-uuid-123';
const JWT_TOKEN = 'mock-jwt-token-for-load-test';

const HEADERS = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${JWT_TOKEN}`,
  'x-tenant-id': TENANT_ID,
};

export const options = {
  scenarios: {
    // 1. 10,000 concurrent travel submissions
    travel_submissions: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 2000 },
        { duration: '2m', target: 10000 }, // Peak concurrency
        { duration: '1m', target: 0 },
      ],
      exec: 'submitTravel',
    },
    // 2. 5,000 concurrent approval decisions
    approval_decisions: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 1000 },
        { duration: '2m', target: 5000 },
        { duration: '1m', target: 0 },
      ],
      exec: 'approveTask',
    },
    // 3. SLA escalation burst (1,000 breaches)
    sla_burst: {
      executor: 'ramping-arrival-rate',
      startRate: 50,
      timeUnit: '1s',
      preAllocatedVUs: 100,
      maxVUs: 1000,
      stages: [
        { duration: '30s', target: 200 },
        { duration: '1m', target: 1000 }, // 1000 breaches/sec burst
        { duration: '30s', target: 0 },
      ],
      exec: 'triggerSla',
    },
    // 4. Expense upload with file metadata
    expense_upload: {
      executor: 'constant-vus',
      vus: 500,
      duration: '3m',
      exec: 'uploadExpense',
    },
    // 5. API Gateway rate limit validation
    rate_limit_check: {
      executor: 'constant-arrival-rate',
      rate: 5000, // 5000 req/s to trip the rate limiter
      timeUnit: '1s',
      duration: '1m',
      preAllocatedVUs: 500,
      maxVUs: 2000,
      exec: 'checkRateLimit',
    },
  },
  thresholds: {
    'http_req_duration': ['p(95)<500'], // P95 Response time < 500ms
    'tripaxis_error_rate': ['rate<0.05'], // Error rate < 5%
  },
};

// Helper to estimate infrastructure load based on active VUs
function updateResourceEstimations() {
  // Rough estimation: 1 VU = 0.01 CPU cores, 5MB RAM (Node.js/NestJS baseline)
  const activeVUs = __VU;
  cpuEstimation.add(activeVUs * 0.01);
  memEstimation.add(activeVUs * 5);
}

// Scenario 1: Travel Submission
export function submitTravel() {
  updateResourceEstimations();
  
  const payload = JSON.stringify({
    purpose: `Load Test Trip ${__VU}-${__ITER}`,
    totalBudget: 1500.00,
    currency: 'USD',
    legs: [
      { origin: 'SFO', destination: 'JFK', departureDate: '2026-03-01T10:00:00Z', transportMode: 'FLIGHT', estimatedCost: 500 }
    ]
  });

  const res = http.post(`${BASE_URL}/v1/travel/submit`, payload, { headers: HEADERS });
  
  const success = check(res, { 'status is 201': (r) => r.status === 201 });
  errorRate.add(!success);
  if (success) travelSubmissions.add(1);
  
  sleep(1); // Think time
}

// Scenario 2: Approval Decision
export function approveTask() {
  updateResourceEstimations();
  
  const taskId = `mock-task-${__VU}-${__ITER}`;
  const idempotencyKey = `idemp-${__VU}-${__ITER}`;
  
  const payload = JSON.stringify({ comments: 'Approved via load test' });
  const headers = { ...HEADERS, 'x-idempotency-key': idempotencyKey };

  const res = http.post(`${BASE_URL}/v1/approvals/tasks/${taskId}/approve`, payload, { headers });
  
  const success = check(res, { 'status is 200 or 409': (r) => r.status === 200 || r.status === 409 });
  errorRate.add(!success);
  if (success) approvalDecisions.add(1);
  
  sleep(1);
}

// Scenario 3: SLA Burst
export function triggerSla() {
  updateResourceEstimations();
  
  const payload = JSON.stringify({ tenantId: TENANT_ID, slaHours: 24, escalationRole: 'Admin' });
  const res = http.post(`${BASE_URL}/v1/test/seed-breached-task`, payload, { headers: HEADERS });
  
  const success = check(res, { 'status is 201': (r) => r.status === 201 });
  errorRate.add(!success);
  if (success) slaEscalations.add(1);
}

// Scenario 4: Expense Upload
export function uploadExpense() {
  updateResourceEstimations();
  
  // 1. Get Presigned URL
  const urlRes = http.get(`${BASE_URL}/v1/expenses/receipt-upload-url?fileName=receipt.pdf&mimeType=application/pdf`, { headers: HEADERS });
  check(urlRes, { 'got upload url': (r) => r.status === 200 });
  
  // 2. Submit Expense
  const payload = JSON.stringify({
    title: 'Load Test Expense',
    lineItems: [{ categoryId: 'cat-1', amount: 100, currency: 'USD', date: '2026-02-25T00:00:00Z', receiptUrl: 's3://mock' }]
  });

  const res = http.post(`${BASE_URL}/v1/expenses/submit`, payload, { headers: HEADERS });
  
  const success = check(res, { 'status is 201': (r) => r.status === 201 });
  errorRate.add(!success);
  if (success) expenseUploads.add(1);
  
  sleep(2);
}

// Scenario 5: Rate Limit Check
export function checkRateLimit() {
  const res = http.get(`${BASE_URL}/v1/policies?page=1&limit=10`, { headers: HEADERS });
  
  // We expect a 429 Too Many Requests due to the high arrival rate
  const isRateLimited = check(res, { 'status is 429': (r) => r.status === 429 });
  if (isRateLimited) rateLimitHits.add(1);
}
