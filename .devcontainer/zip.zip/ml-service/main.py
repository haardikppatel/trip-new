import os
import json
import numpy as np
import xgboost as xgb
import shap
import redis
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List

app = FastAPI(title="TripAxis ML Fraud Inference API")

# Initialize Redis for low-latency profile fetching
redis_client = redis.Redis(
    host=os.getenv("REDIS_HOST", "localhost"),
    port=int(os.getenv("REDIS_PORT", 6379)),
    decode_responses=True
)

# Load pre-trained XGBoost model and SHAP explainer (in production, load from MLflow/S3)
# model = xgb.Booster()
# model.load_model("models/fraud_xgb_v1.json")
# explainer = shap.TreeExplainer(model)

class InferenceRequest(BaseModel):
    tenant_id: str
    user_id: str
    department_id: str
    expense_id: str
    amount: float
    category: str
    merchant: str
    time_of_submission: str # ISO8601
    rule_score: int
    user_tenure_days: int
    historical_rejection_rate: float

class InferenceResponse(BaseModel):
    anomaly_score: int
    ml_probability: float
    shap_explanations: Dict[str, float]

def calculate_anomaly_score(req: InferenceRequest, user_profile: dict, dept_profile: dict) -> int:
    """
    Calculates a statistical anomaly score (0-100) using Z-score, IQR, and peer comparison.
    """
    score = 0
    
    # 1. Personal Baseline (Z-Score & IQR)
    avg_amount = user_profile.get("avg_amount", req.amount)
    std_dev = user_profile.get("std_dev", 1.0)
    q3 = user_profile.get("q3", req.amount)
    iqr = user_profile.get("iqr", 1.0)

    z_score = abs(req.amount - avg_amount) / (std_dev + 1e-5)
    if z_score > 3:
        score += 30
    elif z_score > 2:
        score += 15

    # IQR Outlier Detection
    if req.amount > (q3 + 1.5 * iqr):
        score += 20

    # 2. Department Baseline (Peer-group comparison)
    dept_avg = dept_profile.get("avg_amount", req.amount)
    if req.amount > dept_avg * 3:
        score += 25
    elif req.amount > dept_avg * 2:
        score += 10

    # 3. Time-series / Frequency anomaly
    weekly_freq = user_profile.get("weekly_freq", 0)
    if weekly_freq > user_profile.get("avg_weekly_freq", 5) * 2:
        score += 15

    # 4. Vendor anomaly
    typical_vendors = user_profile.get("typical_vendors", [])
    if req.merchant not in typical_vendors and len(typical_vendors) > 5:
        score += 10

    return min(int(score), 100)

@app.post("/v1/infer", response_model=InferenceResponse)
async def infer_fraud(req: InferenceRequest):
    try:
        # 1. Fetch Behavioral Profiles from Redis (O(1) latency)
        user_prof_raw = redis_client.get(f"profile:user:{req.tenant_id}:{req.user_id}")
        dept_prof_raw = redis_client.get(f"profile:dept:{req.tenant_id}:{req.department_id}")
        
        user_profile = json.loads(user_prof_raw) if user_prof_raw else {}
        dept_profile = json.loads(dept_prof_raw) if dept_prof_raw else {}

        # 2. Calculate Statistical Anomaly Score
        anomaly_score = calculate_anomaly_score(req, user_profile, dept_profile)

        # 3. Prepare Feature Vector for XGBoost
        # Features: [rule_score, anomaly_score, amount, user_tenure, rejection_rate, dept_variance]
        dept_variance = req.amount / (dept_profile.get("avg_amount", req.amount) + 1e-5)
        
        features = np.array([[
            req.rule_score,
            anomaly_score,
            req.amount,
            req.user_tenure_days,
            req.historical_rejection_rate,
            dept_variance
        ]])

        # 4. ML Inference (Mocked for demonstration, replace with actual model.predict)
        # dmatrix = xgb.DMatrix(features)
        # ml_probability = float(model.predict(dmatrix)[0])
        ml_probability = min(0.99, (req.rule_score * 0.4 + anomaly_score * 0.6) / 100.0) # Mock probability

        # 5. Explainability (SHAP)
        # shap_vals = explainer.shap_values(features)[0]
        feature_names = ["rule_score", "anomaly_score", "amount", "user_tenure", "rejection_rate", "dept_variance"]
        # shap_explanations = {name: float(val) for name, val in zip(feature_names, shap_vals)}
        
        # Mock SHAP output
        shap_explanations = {
            "rule_score": 0.15,
            "anomaly_score": 0.35,
            "amount": 0.20,
            "dept_variance": 0.10
        }

        return InferenceResponse(
            anomaly_score=anomaly_score,
            ml_probability=ml_probability,
            shap_explanations=shap_explanations
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Health check for Kubernetes
@app.get("/health")
def health():
    return {"status": "ok"}
