import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc, classification_report
from imblearn.over_sampling import SMOTE
import mlflow
import mlflow.xgboost

# 1. Load Data (Simulated extraction from Data Warehouse / S3)
# In production, this pulls from a Snowflake/Redshift table containing 10M historical records
def load_data():
    print("Loading historical expense data...")
    # Mock dataframe
    np.random.seed(42)
    n = 100000
    df = pd.DataFrame({
        'rule_score': np.random.randint(0, 100, n),
        'anomaly_score': np.random.randint(0, 100, n),
        'amount': np.random.exponential(100, n),
        'user_tenure_days': np.random.randint(1, 3650, n),
        'historical_rejection_rate': np.random.uniform(0, 0.5, n),
        'dept_variance': np.random.uniform(0.1, 5.0, n),
        'is_fraud': np.random.choice([0, 1], n, p=[0.98, 0.02]) # 2% fraud rate (highly imbalanced)
    })
    return df

def train_model():
    df = load_data()
    
    X = df.drop('is_fraud', axis=1)
    y = df['is_fraud']

    # 2. Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    # 3. Handle Imbalanced Dataset using SMOTE (Synthetic Minority Over-sampling Technique)
    print("Applying SMOTE to balance training data...")
    smote = SMOTE(random_state=42)
    X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

    # 4. MLflow Tracking Setup
    mlflow.set_experiment("tripaxis_expense_fraud")
    
    with mlflow.start_run():
        params = {
            "objective": "binary:logistic",
            "eval_metric": "auc",
            "max_depth": 6,
            "learning_rate": 0.1,
            "n_estimators": 200,
            "scale_pos_weight": 1 # SMOTE already balanced it, otherwise use len(neg)/len(pos)
        }
        mlflow.log_params(params)

        # 5. Train XGBoost Model
        print("Training XGBoost Classifier...")
        model = xgb.XGBClassifier(**params, use_label_encoder=False)
        model.fit(X_train_resampled, y_train_resampled, eval_set=[(X_test, y_test)], verbose=False)

        # 6. Evaluation Metrics
        y_pred_prob = model.predict_proba(X_test)[:, 1]
        y_pred = model.predict(X_test)

        roc_auc = roc_auc_score(y_test, y_pred_prob)
        precision, recall, _ = precision_recall_curve(y_test, y_pred_prob)
        pr_auc = auc(recall, precision)

        print(f"ROC AUC: {roc_auc:.4f}")
        print(f"PR AUC: {pr_auc:.4f}")
        print(classification_report(y_test, y_pred))

        mlflow.log_metric("roc_auc", roc_auc)
        mlflow.log_metric("pr_auc", pr_auc)

        # 7. Model Registry & Versioning
        # Log model to MLflow Model Registry
        mlflow.xgboost.log_model(
            xgb_model=model,
            artifact_path="fraud_xgb_model",
            registered_model_name="TripAxis_Expense_Fraud_XGB"
        )
        print("Model successfully trained and registered to MLflow.")

if __name__ == "__main__":
    train_model()
