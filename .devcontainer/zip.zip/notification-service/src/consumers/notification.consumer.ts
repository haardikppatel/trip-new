import { Controller } from '@nestjs/common';
import { EventPattern, Payload, Ctx, RmqContext } from '@nestjs/microservices';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from '../../prisma/prisma.service';

@Controller()
export class NotificationConsumer {
  constructor(
    @InjectQueue('notification-delivery') private readonly deliveryQueue: Queue,
    private readonly prisma: PrismaService,
  ) {}

  // Listen to multiple domain events
  @EventPattern('TravelRequestSubmitted:v1')
  @EventPattern('TravelRequestApproved:v1')
  @EventPattern('TravelRequestRejected:v1')
  @EventPattern('BookingConfirmed:v1')
  @EventPattern('ExpenseSubmitted:v1')
  @EventPattern('ExpenseApproved:v1')
  async handleDomainEvent(@Payload() data: any, @Ctx() context: RmqContext) {
    const channel = context.getChannelRef();
    const originalMsg = context.getMessage();
    const routingKey = originalMsg.fields.routingKey;

    try {
      const { eventId, correlationId, tenantId, payload } = data;

      // Idempotency check
      const existing = await this.prisma.deliveryAudit.findFirst({
        where: { eventId, tenantId }
      });

      if (existing) {
        channel.ack(originalMsg);
        return;
      }

      // Enqueue for processing (Email & Slack)
      await this.deliveryQueue.add('process-notification', {
        eventName: routingKey,
        eventId,
        correlationId,
        tenantId,
        payload
      }, {
        jobId: `notify-${eventId}`,
        attempts: 5,
        backoff: { type: 'exponential', delay: 2000 }
      });

      channel.ack(originalMsg);
    } catch (error) {
      console.error(`Failed to queue notification for ${routingKey}`, error);
      channel.nack(originalMsg, false, false); // Send to DLQ
    }
  }
}
