import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import * as Handlebars from 'handlebars';

@Processor('notification-delivery')
@Injectable()
export class DeliveryProcessor extends WorkerHost {
  constructor(private readonly prisma: PrismaService) {}

  async process(job: Job<any, any, string>): Promise<any> {
    const { eventName, eventId, correlationId, tenantId, payload } = job.data;

    // 1. Fetch active templates for this tenant and event
    const templates = await this.prisma.notificationTemplate.findMany({
      where: { tenantId, eventName, isActive: true }
    });

    if (templates.length === 0) {
      console.log(`No active templates found for ${eventName} in tenant ${tenantId}`);
      return;
    }

    // 2. Process each channel
    for (const template of templates) {
      try {
        // Compile Handlebars template
        const bodyCompiler = Handlebars.compile(template.bodyTemplate);
        const compiledBody = bodyCompiler(payload);
        
        let compiledSubject = '';
        if (template.subjectTemplate) {
          const subjectCompiler = Handlebars.compile(template.subjectTemplate);
          compiledSubject = subjectCompiler(payload);
        }

        // 3. Dispatch based on channel
        if (template.channel === 'EMAIL') {
          await this.sendEmail(payload.recipientEmail, compiledSubject, compiledBody);
        } else if (template.channel === 'SLACK') {
          await this.sendSlack(payload.slackChannelId, compiledBody);
        }

        // 4. Audit Success
        await this.prisma.deliveryAudit.create({
          data: {
            tenantId, correlationId, eventId, eventName,
            channel: template.channel,
            recipient: template.channel === 'EMAIL' ? payload.recipientEmail : payload.slackChannelId,
            status: 'SUCCESS'
          }
        });

      } catch (error: any) {
        // Audit Failure
        await this.prisma.deliveryAudit.create({
          data: {
            tenantId, correlationId, eventId, eventName,
            channel: template.channel,
            recipient: 'UNKNOWN',
            status: 'FAILED',
            errorDetails: error.message
          }
        });
        throw error; // Trigger BullMQ retry
      }
    }
  }

  private async sendEmail(to: string, subject: string, body: string) {
    // Integration with SendGrid / AWS SES goes here
    console.log(`Sending EMAIL to ${to}: [${subject}]`);
  }

  private async sendSlack(channelId: string, message: string) {
    // Integration with Slack Webhooks goes here
    console.log(`Sending SLACK to ${channelId}`);
  }
}
