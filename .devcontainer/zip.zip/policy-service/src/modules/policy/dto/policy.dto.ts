import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional, IsEnum, IsArray, ValidateNested, IsUUID, IsObject } from 'class-validator';
import { Type } from 'class-transformer';
import { PolicyStatus, RuleType, RuleAction, AssigneeType } from '@prisma/client';

export class PolicyRuleDto {
  @ApiProperty({ enum: RuleType })
  @IsEnum(RuleType)
  ruleType: RuleType;

  @ApiProperty({ example: { maxAmount: 1000, currency: 'USD' } })
  @IsObject()
  conditions: Record<string, any>;

  @ApiProperty({ enum: RuleAction, default: RuleAction.BLOCK })
  @IsEnum(RuleAction)
  @IsOptional()
  action?: RuleAction;
}

export class CreatePolicyDto {
  @ApiProperty({ example: 'Standard Travel Policy' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ example: 'Default policy for all employees' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ type: [PolicyRuleDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PolicyRuleDto)
  rules: PolicyRuleDto[];
}

export class UpdatePolicyDto {
  @ApiPropertyOptional({ example: 'Updated Travel Policy' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ example: 'Updated description' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ type: [PolicyRuleDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PolicyRuleDto)
  @IsOptional()
  rules?: PolicyRuleDto[];
}

export class AssignPolicyDto {
  @ApiProperty({ enum: AssigneeType })
  @IsEnum(AssigneeType)
  assigneeType: AssigneeType;

  @ApiPropertyOptional({ example: 'uuid-of-department-or-role' })
  @IsUUID()
  @IsOptional()
  assigneeId?: string;
}

export class ValidateRequestDto {
  @ApiProperty({ example: 'uuid-of-user' })
  @IsUUID()
  userId: string;

  @ApiProperty({ example: 'uuid-of-department' })
  @IsUUID()
  departmentId: string;

  @ApiProperty({ example: ['uuid-of-role'] })
  @IsArray()
  @IsUUID('all', { each: true })
  roleIds: string[];

  @ApiProperty({ example: { type: 'FLIGHT', amount: 1200, currency: 'USD', bookingClass: 'BUSINESS' } })
  @IsObject()
  travelDetails: Record<string, any>;
}

export class ValidationResultDto {
  @ApiProperty()
  valid: boolean;

  @ApiProperty({ type: [String] })
  violations: string[];
}
