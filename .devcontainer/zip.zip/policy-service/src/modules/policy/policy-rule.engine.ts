import { Injectable } from '@nestjs/common';
import { RuleType, RuleAction } from '@prisma/client';

@Injectable()
export class PolicyRuleEngine {
  
  evaluate(policies: any[], travelDetails: Record<string, any>): { valid: boolean; violations: string[] } {
    const violations: string[] = [];
    let isBlocked = false;

    for (const policy of policies) {
      for (const rule of policy.rules) {
        const result = this.evaluateRule(rule, travelDetails);
        
        if (!result.passed) {
          const violationMsg = `[${policy.name}] ${result.reason}`;
          violations.push(violationMsg);
          
          if (rule.action === RuleAction.BLOCK) {
            isBlocked = true;
          }
        }
      }
    }

    return {
      valid: !isBlocked,
      violations,
    };
  }

  private evaluateRule(rule: any, details: Record<string, any>): { passed: boolean; reason?: string } {
    const conditions = rule.conditions as any;

    switch (rule.ruleType) {
      case RuleType.BUDGET_LIMIT:
        if (details.amount && conditions.maxAmount && details.amount > conditions.maxAmount) {
          // Note: In a real system, FX conversion would happen here if details.currency != conditions.currency
          return { passed: false, reason: `Amount ${details.amount} exceeds budget limit of ${conditions.maxAmount}` };
        }
        break;

      case RuleType.BOOKING_CLASS:
        if (details.bookingClass && conditions.allowedClasses && !conditions.allowedClasses.includes(details.bookingClass)) {
          return { passed: false, reason: `Booking class ${details.bookingClass} is not allowed. Allowed: ${conditions.allowedClasses.join(', ')}` };
        }
        break;

      case RuleType.LOCATION_RESTRICTION:
        if (details.destination && conditions.blockedCountries && conditions.blockedCountries.includes(details.destination)) {
          return { passed: false, reason: `Travel to ${details.destination} is restricted by policy.` };
        }
        break;

      case RuleType.ADVANCE_BOOKING_DAYS:
        if (details.daysInAdvance !== undefined && conditions.minDays && details.daysInAdvance < conditions.minDays) {
          return { passed: false, reason: `Booking must be made at least ${conditions.minDays} days in advance.` };
        }
        break;
    }

    return { passed: true };
  }
}
