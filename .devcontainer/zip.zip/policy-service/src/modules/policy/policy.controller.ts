import { Controller, Get, Post, Put, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiHeader } from '@nestjs/swagger';
import { PolicyService } from './policy.service';
import { CreatePolicyDto, UpdatePolicyDto, AssignPolicyDto, ValidateRequestDto, ValidationResultDto } from './dto/policy.dto';
import { ApiResponseDto, PaginatedData } from '../../common/dto/api-response.dto';
import { PaginationQueryDto } from '../../common/dto/pagination.dto';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RbacGuard } from '../../common/guards/rbac.guard';
import { Roles } from '@tripaxis/core';

@ApiTags('Policies')
@ApiBearerAuth()
@ApiHeader({ name: 'x-tenant-id', required: true, description: 'Tenant ID' })
@UseGuards(TenantGuard, RbacGuard)
@Controller('v1/policies')
export class PolicyController {
  constructor(private readonly policyService: PolicyService) {}

  @Post()
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin')
  @ApiOperation({ summary: 'Create a new policy' })
  @ApiResponse({ status: 201, type: ApiResponseDto<any> })
  async create(@Body() dto: CreatePolicyDto) {
    const result = await this.policyService.createPolicy(dto);
    return ApiResponseDto.success(result);
  }

  @Get()
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin', 'Employee')
  @ApiOperation({ summary: 'List policies with pagination' })
  @ApiResponse({ status: 200, type: ApiResponseDto<PaginatedData<any>> })
  async findAll(@Query() query: PaginationQueryDto) {
    const { items, total } = await this.policyService.getPolicies(query.page!, query.limit!);
    return ApiResponseDto.success({ items, total, page: query.page!, limit: query.limit! });
  }

  @Get(':id')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin', 'Employee')
  @ApiOperation({ summary: 'Get policy by ID' })
  @ApiResponse({ status: 200, type: ApiResponseDto<any> })
  async findOne(@Param('id') id: string) {
    const result = await this.policyService.getPolicyById(id);
    return ApiResponseDto.success(result);
  }

  @Put(':id')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin')
  @ApiOperation({ summary: 'Update a policy (creates new version if active)' })
  @ApiResponse({ status: 200, type: ApiResponseDto<any> })
  async update(@Param('id') id: string, @Body() dto: UpdatePolicyDto) {
    const result = await this.policyService.updatePolicy(id, dto);
    return ApiResponseDto.success(result);
  }

  @Post(':id/activate')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Activate a policy' })
  @ApiResponse({ status: 200, type: ApiResponseDto<any> })
  async activate(@Param('id') id: string) {
    const result = await this.policyService.activatePolicy(id);
    return ApiResponseDto.success(result);
  }

  @Post(':id/deactivate')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Deactivate a policy' })
  @ApiResponse({ status: 200, type: ApiResponseDto<any> })
  async deactivate(@Param('id') id: string) {
    const result = await this.policyService.deactivatePolicy(id);
    return ApiResponseDto.success(result);
  }

  @Post(':id/assignments')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Assign policy to a department or role' })
  @ApiResponse({ status: 200, type: ApiResponseDto<any> })
  async assign(@Param('id') id: string, @Body() dto: AssignPolicyDto) {
    const result = await this.policyService.assignPolicy(id, dto);
    return ApiResponseDto.success(result);
  }

  @Post('validate')
  @Roles('SaaSAdmin', 'AppAdmin', 'FinanceAdmin', 'Employee', 'System')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Validate a travel request against active policies' })
  @ApiResponse({ status: 200, type: ApiResponseDto<ValidationResultDto> })
  async validate(@Body() dto: ValidateRequestDto) {
    const result = await this.policyService.validateRequest(dto);
    return ApiResponseDto.success(result);
  }
}
