import { Injectable, Inject } from '@nestjs/common';
import { PrismaClient, PolicyStatus, AssigneeType } from '@prisma/client';
import { CreatePolicyDto, UpdatePolicyDto, AssignPolicyDto } from './dto/policy.dto';

@Injectable()
export class PolicyRepository {
  constructor(@Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient) {}

  async create(tenantId: string, data: CreatePolicyDto) {
    return this.prisma.policy.create({
      data: {
        tenantId,
        name: data.name,
        description: data.description,
        status: PolicyStatus.DRAFT,
        version: 1,
        rules: {
          create: data.rules.map(r => ({
            tenantId,
            ruleType: r.ruleType,
            conditions: r.conditions,
            action: r.action || 'BLOCK',
          })),
        },
      },
      include: { rules: true },
    });
  }

  async findById(id: string) {
    return this.prisma.policy.findUnique({
      where: { id },
      include: { rules: true, assignments: true },
    });
  }

  async findAllPaginated(skip: number, take: number) {
    const [items, total] = await Promise.all([
      this.prisma.policy.findMany({
        skip,
        take,
        orderBy: { createdAt: 'desc' },
        include: { rules: true },
      }),
      this.prisma.policy.count(),
    ]);
    return { items, total };
  }

  async update(id: string, data: UpdatePolicyDto) {
    // Note: If updating rules, we replace them entirely for simplicity in this version
    return this.prisma.policy.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        ...(data.rules && {
          rules: {
            deleteMany: {},
            create: data.rules.map(r => ({
              tenantId: (this.prisma as any)._tenantId, // Handled by RLS but needed for explicit creation if not injected
              ruleType: r.ruleType,
              conditions: r.conditions,
              action: r.action || 'BLOCK',
            })),
          }
        })
      },
      include: { rules: true },
    });
  }

  async createNewVersion(tenantId: string, oldPolicy: any, data: UpdatePolicyDto) {
    return this.prisma.policy.create({
      data: {
        tenantId,
        name: data.name || oldPolicy.name,
        description: data.description || oldPolicy.description,
        status: PolicyStatus.DRAFT,
        version: oldPolicy.version + 1,
        parentPolicyId: oldPolicy.id,
        rules: {
          create: (data.rules || oldPolicy.rules).map((r: any) => ({
            tenantId,
            ruleType: r.ruleType,
            conditions: r.conditions,
            action: r.action,
          })),
        },
      },
      include: { rules: true },
    });
  }

  async setStatus(id: string, status: PolicyStatus) {
    return this.prisma.policy.update({
      where: { id },
      data: { status },
    });
  }

  async assign(tenantId: string, policyId: string, data: AssignPolicyDto) {
    return this.prisma.policyAssignment.create({
      data: {
        tenantId,
        policyId,
        assigneeType: data.assigneeType,
        assigneeId: data.assigneeId,
      },
    });
  }

  async findActivePoliciesForUser(departmentId: string, roleIds: string[]) {
    // Find policies assigned to GLOBAL, the specific DEPARTMENT, or any of the ROLES
    return this.prisma.policy.findMany({
      where: {
        status: PolicyStatus.ACTIVE,
        assignments: {
          some: {
            OR: [
              { assigneeType: AssigneeType.GLOBAL },
              { assigneeType: AssigneeType.DEPARTMENT, assigneeId: departmentId },
              { assigneeType: AssigneeType.ROLE, assigneeId: { in: roleIds } },
            ],
          },
        },
      },
      include: { rules: true },
    });
  }

  async logAudit(tenantId: string, policyId: string, action: string, changedBy: string, oldData: any, newData: any) {
    return this.prisma.policyAuditLog.create({
      data: {
        tenantId,
        policyId,
        action,
        changedBy,
        oldData: oldData ? JSON.parse(JSON.stringify(oldData)) : null,
        newData: newData ? JSON.parse(JSON.stringify(newData)) : null,
      },
    });
  }
}
