import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PolicyRepository } from './policy.repository';
import { PolicyRuleEngine } from './policy-rule.engine';
import { CreatePolicyDto, UpdatePolicyDto, AssignPolicyDto, ValidateRequestDto } from './dto/policy.dto';
import { EventPublisher } from '../../infrastructure/events/event.publisher';
import { TenantContext } from '@tripaxis/core';
import { PolicyStatus } from '@prisma/client';

@Injectable()
export class PolicyService {
  constructor(
    private readonly repository: PolicyRepository,
    private readonly ruleEngine: PolicyRuleEngine,
    private readonly eventPublisher: EventPublisher,
  ) {}

  async createPolicy(dto: CreatePolicyDto) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    
    const policy = await this.repository.create(tenantId, dto);

    await this.repository.logAudit(tenantId, policy.id, 'POLICY_CREATED', userId, null, policy);

    await this.eventPublisher.publish('PolicyCreated:v1', { policyId: policy.id });

    return policy;
  }

  async getPolicies(page: number, limit: number) {
    const skip = (page - 1) * limit;
    return this.repository.findAllPaginated(skip, limit);
  }

  async getPolicyById(id: string) {
    const policy = await this.repository.findById(id);
    if (!policy) throw new NotFoundException('Policy not found');
    return policy;
  }

  async updatePolicy(id: string, dto: UpdatePolicyDto) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    const existing = await this.getPolicyById(id);

    let updatedPolicy;

    // Versioning logic: If Active, create a new Draft version instead of mutating
    if (existing.status === PolicyStatus.ACTIVE) {
      updatedPolicy = await this.repository.createNewVersion(tenantId, existing, dto);
      await this.repository.logAudit(tenantId, updatedPolicy.id, 'POLICY_VERSION_CREATED', userId, existing, updatedPolicy);
    } else {
      // If Draft or Inactive, mutate directly
      updatedPolicy = await this.repository.update(id, dto);
      await this.repository.logAudit(tenantId, id, 'POLICY_UPDATED', userId, existing, updatedPolicy);
    }

    await this.eventPublisher.publish('PolicyUpdated:v1', { policyId: updatedPolicy.id });

    return updatedPolicy;
  }

  async activatePolicy(id: string) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    const policy = await this.getPolicyById(id);

    if (policy.status === PolicyStatus.ACTIVE) {
      throw new BadRequestException('Policy is already active');
    }

    const activated = await this.repository.setStatus(id, PolicyStatus.ACTIVE);

    // If this was a new version, archive the parent
    if (policy.parentPolicyId) {
      await this.repository.setStatus(policy.parentPolicyId, PolicyStatus.ARCHIVED);
    }

    await this.repository.logAudit(tenantId, id, 'POLICY_ACTIVATED', userId, policy, activated);
    await this.eventPublisher.publish('PolicyActivated:v1', { policyId: id });

    return activated;
  }

  async deactivatePolicy(id: string) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    const policy = await this.getPolicyById(id);

    const deactivated = await this.repository.setStatus(id, PolicyStatus.INACTIVE);

    await this.repository.logAudit(tenantId, id, 'POLICY_DEACTIVATED', userId, policy, deactivated);
    await this.eventPublisher.publish('PolicyDeactivated:v1', { policyId: id });

    return deactivated;
  }

  async assignPolicy(id: string, dto: AssignPolicyDto) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();
    
    const policy = await this.getPolicyById(id);
    const assignment = await this.repository.assign(tenantId, id, dto);

    await this.repository.logAudit(tenantId, id, 'POLICY_ASSIGNED', userId, null, assignment);
    await this.eventPublisher.publish('PolicyAssigned:v1', { policyId: id, assignment });

    return assignment;
  }

  async validateRequest(dto: ValidateRequestDto) {
    // 1. Fetch active policies assigned to this user's context
    const policies = await this.repository.findActivePoliciesForUser(dto.departmentId, dto.roleIds);

    // 2. Run through Rule Engine
    const result = this.ruleEngine.evaluate(policies, dto.travelDetails);

    return result;
  }
}
