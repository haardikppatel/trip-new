import { Test, TestingModule } from '@nestjs/testing';
import { PolicyService } from '../src/modules/policy/policy.service';
import { PolicyRepository } from '../src/modules/policy/policy.repository';
import { PolicyRuleEngine } from '../src/modules/policy/policy-rule.engine';
import { EventPublisher } from '../src/infrastructure/events/event.publisher';
import { TenantContext } from '@tripaxis/core';
import { PolicyStatus, RuleType, RuleAction } from '@prisma/client';

describe('PolicyService', () => {
  let service: PolicyService;
  let repository: PolicyRepository;
  let ruleEngine: PolicyRuleEngine;
  let eventPublisher: EventPublisher;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        PolicyService,
        PolicyRuleEngine,
        {
          provide: PolicyRepository,
          useValue: {
            create: jest.fn(),
            findById: jest.fn(),
            update: jest.fn(),
            createNewVersion: jest.fn(),
            setStatus: jest.fn(),
            logAudit: jest.fn(),
            findActivePoliciesForUser: jest.fn(),
          },
        },
        {
          provide: EventPublisher,
          useValue: { publish: jest.fn() },
        },
      ],
    }).compile();

    service = module.get<PolicyService>(PolicyService);
    repository = module.get<PolicyRepository>(PolicyRepository);
    ruleEngine = module.get<PolicyRuleEngine>(PolicyRuleEngine);
    eventPublisher = module.get<EventPublisher>(EventPublisher);

    jest.spyOn(TenantContext, 'getTenantId').mockReturnValue('tenant-123');
    jest.spyOn(TenantContext, 'getUserId').mockReturnValue('user-123');
  });

  it('should create a new version when updating an ACTIVE policy', async () => {
    const activePolicy = { id: 'pol-1', status: PolicyStatus.ACTIVE, version: 1 };
    const newDraftPolicy = { id: 'pol-2', status: PolicyStatus.DRAFT, version: 2, parentPolicyId: 'pol-1' };

    jest.spyOn(repository, 'findById').mockResolvedValue(activePolicy as any);
    jest.spyOn(repository, 'createNewVersion').mockResolvedValue(newDraftPolicy as any);

    const result = await service.updatePolicy('pol-1', { name: 'Updated Policy' });

    expect(repository.createNewVersion).toHaveBeenCalled();
    expect(repository.logAudit).toHaveBeenCalledWith(
      'tenant-123', 'pol-2', 'POLICY_VERSION_CREATED', 'user-123', activePolicy, newDraftPolicy
    );
    expect(result).toEqual(newDraftPolicy);
  });

  it('should validate travel request against rules and block if budget exceeded', async () => {
    const mockPolicies = [
      {
        name: 'Standard Policy',
        rules: [
          { ruleType: RuleType.BUDGET_LIMIT, conditions: { maxAmount: 1000 }, action: RuleAction.BLOCK }
        ]
      }
    ];

    jest.spyOn(repository, 'findActivePoliciesForUser').mockResolvedValue(mockPolicies as any);

    const result = await service.validateRequest({
      userId: 'user-1',
      departmentId: 'dept-1',
      roleIds: ['role-1'],
      travelDetails: { amount: 1500 }
    });

    expect(result.valid).toBe(false);
    expect(result.violations[0]).toContain('exceeds budget limit');
  });
});
