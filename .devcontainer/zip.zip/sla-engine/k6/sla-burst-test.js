import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Rate } from 'k6/metrics';

// Custom metrics
const escalationSuccessRate = new Rate('escalation_success_rate');
const processedTasks = new Counter('processed_tasks');

export const options = {
  scenarios: {
    sla_burst: {
      executor: 'ramping-arrival-rate',
      startRate: 50,
      timeUnit: '1s',
      preAllocatedVUs: 100,
      maxVUs: 500,
      stages: [
        { target: 200, duration: '30s' }, // Ramp up to 200 escalations/sec
        { target: 500, duration: '1m' },  // Burst to 500 escalations/sec
        { target: 0, duration: '30s' },   // Cool down
      ],
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% of requests must complete below 500ms
    escalation_success_rate: ['rate>0.99'], // 99% success rate required
  },
};

// Mock API endpoint that simulates the internal trigger or seeds the DB
// In a real scenario, this would hit a test endpoint that seeds breached tasks,
// and we monitor the BullMQ processing rate via Prometheus.
const BASE_URL = __ENV.API_URL || 'http://localhost:3000/v1/test/seed-breached-task';

export default function () {
  const payload = JSON.stringify({
    tenantId: 'tenant-uuid-123',
    slaHours: 24,
    escalationRole: 'FinanceAdmin'
  });

  const params = {
    headers: {
      'Content-Type': 'application/json',
      'x-tenant-id': 'tenant-uuid-123',
    },
  };

  const res = http.post(BASE_URL, payload, params);

  const success = check(res, {
    'status is 201': (r) => r.status === 201,
  });

  escalationSuccessRate.add(success);
  if (success) processedTasks.add(1);
}
