import { Injectable, Inject } from '@nestjs/common';
import { ClientProxy } from '@nestjs/microservices';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class EventPublisher {
  constructor(@Inject('RABBITMQ_SERVICE') private readonly client: ClientProxy) {}

  async publish(eventType: string, payload: any): Promise<void> {
    const event = {
      eventId: uuidv4(),
      correlationId: uuidv4(), // System generated for background jobs
      tenantId: payload.tenantId,
      timestamp: new Date().toISOString(),
      eventType,
      payload,
    };

    this.client.emit(eventType, event);
  }
}
