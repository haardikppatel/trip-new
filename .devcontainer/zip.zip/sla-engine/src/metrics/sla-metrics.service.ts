import { Injectable } from '@nestjs/common';
import { Counter, Histogram, Gauge } from 'prom-client';

@Injectable()
export class SlaMetricsService {
  public readonly slaSweeps = new Counter({
    name: 'sla_sweeps_total',
    help: 'Total number of SLA sweep executions',
  });

  public readonly slaBreachesDetected = new Counter({
    name: 'sla_breaches_detected_total',
    help: 'Total number of SLA breached tasks detected',
  });

  public readonly escalationSuccess = new Counter({
    name: 'sla_escalation_success_total',
    help: 'Total successful escalations processed',
    labelNames: ['tenant_id', 'escalation_level'],
  });

  public readonly escalationFailures = new Counter({
    name: 'sla_escalation_failures_total',
    help: 'Total failed escalations (moved to DLQ)',
    labelNames: ['reason'],
  });

  public readonly escalationProcessingTime = new Histogram({
    name: 'sla_escalation_processing_duration_seconds',
    help: 'Time taken to process an individual escalation',
    buckets: [0.05, 0.1, 0.25, 0.5, 1, 2],
  });

  public readonly dlqSize = new Gauge({
    name: 'sla_dlq_size',
    help: 'Current number of jobs in the Dead Letter Queue (failed state)',
  });
}
