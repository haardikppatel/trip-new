import { Processor, WorkerHost, OnWorkerEvent } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { Injectable, Logger, Inject } from '@nestjs/common';
import { PrismaClient, ApprovalState } from '@prisma/client';
import { EventPublisher } from '../infrastructure/events/event.publisher';
import { SlaMetricsService } from '../metrics/sla-metrics.service';

@Processor('sla-escalation', {
  concurrency: 50, // High concurrency for horizontal scaling
})
@Injectable()
export class SlaEscalationProcessor extends WorkerHost {
  private readonly logger = new Logger(SlaEscalationProcessor.name);

  constructor(
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
    private readonly eventPublisher: EventPublisher,
    private readonly metrics: SlaMetricsService,
  ) {}

  async process(job: Job<{ taskId: string; tenantId: string }>): Promise<any> {
    const { taskId, tenantId } = job.data;
    const endTimer = this.metrics.escalationProcessingTime.startTimer();

    try {
      await this.prisma.$transaction(async (tx) => {
        // 4. Idempotency: Atomic update with condition
        // If the task was already approved/escalated by a user or another worker, this returns 0
        const updatedCount = await tx.approvalTask.updateMany({
          where: { 
            id: taskId, 
            status: ApprovalState.PENDING,
            dueDate: { lt: new Date() } // Double check it's actually breached
          },
          data: { status: ApprovalState.ESCALATED }
        });

        if (updatedCount.count === 0) {
          this.logger.debug(`Task ${taskId} already processed or no longer pending. Skipping.`);
          return; // Idempotent exit
        }

        // Fetch the task details to build the escalation chain
        const task = await tx.approvalTask.findUnique({ where: { id: taskId } });
        if (!task) throw new Error(`Task ${taskId} not found after update`);

        // Resolve next escalation target (Mocked resolution logic)
        const nextAssigneeId = `escalated-user-for-${task.escalationRole || 'admin'}`;
        const nextLevel = task.escalationLevel + 1;
        const newDueDate = new Date(Date.now() + (task.slaHours * 3600000)); // Reset SLA for next approver

        // Create the new escalated task
        const newTask = await tx.approvalTask.create({
          data: {
            tenantId,
            instanceId: task.instanceId,
            assigneeId: nextAssigneeId,
            status: ApprovalState.PENDING,
            slaHours: task.slaHours,
            dueDate: newDueDate,
            escalationRole: task.escalationRole,
            escalationLevel: nextLevel,
          }
        });

        // Write immutable audit entry
        await tx.approvalAuditLog.create({
          data: {
            tenantId,
            taskId,
            action: 'ESCALATED',
            actorId: 'SYSTEM_SLA_ENGINE',
            details: { 
              reason: 'SLA Breached', 
              previousAssignee: task.assigneeId, 
              newAssignee: nextAssigneeId,
              escalationLevel: nextLevel
            }
          }
        });

        // Publish Event
        await this.eventPublisher.publish('ApprovalTaskEscalated:v1', {
          tenantId,
          originalTaskId: taskId,
          newTaskId: newTask.id,
          newAssigneeId: nextAssigneeId,
          escalationLevel: nextLevel,
        });

        this.metrics.escalationSuccess.inc({ tenantId, escalation_level: nextLevel });
        this.logger.log(`Successfully escalated task ${taskId} to ${nextAssigneeId}`);
      });
    } catch (error: any) {
      this.logger.error(`Failed to escalate task ${taskId}: ${error.message}`, error.stack);
      throw error; // Triggers BullMQ retry strategy
    } finally {
      endTimer();
    }
  }

  // Dead-Letter Queue (DLQ) Handling
  @OnWorkerEvent('failed')
  onFailed(job: Job, error: Error) {
    this.logger.error(`Job ${job.id} failed after all retries. Moved to DLQ. Error: ${error.message}`);
    this.metrics.escalationFailures.inc({ reason: error.name });
    this.metrics.dlqSize.inc();
    
    // In a real system, we might also publish a 'SlaEscalationFailed' event to alert engineering
  }
}
