import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';

@Injectable()
export class SlaCronService implements OnModuleInit {
  private readonly logger = new Logger(SlaCronService.name);

  constructor(
    @InjectQueue('sla-sweep') private readonly sweepQueue: Queue,
  ) {}

  async onModuleInit() {
    this.logger.log('Initializing SLA Sweep Cron Job...');
    
    // Ensure the repeatable job is registered. 
    // BullMQ handles distributed locks so this only runs once per cluster every 5 mins.
    await this.sweepQueue.add(
      'sweep-breached-slas',
      {},
      {
        repeat: {
          pattern: '*/5 * * * *', // Every 5 minutes
        },
        jobId: 'system-sla-sweep-job', // Idempotent job ID
        removeOnComplete: true,
        removeOnFail: false,
      },
    );
    
    this.logger.log('SLA Sweep Cron Job registered successfully.');
  }
}
