import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job, Queue } from 'bullmq';
import { Injectable, Logger, Inject } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { InjectQueue } from '@nestjs/bullmq';
import { SlaMetricsService } from '../metrics/sla-metrics.service';

@Processor('sla-sweep', {
  concurrency: 1, // Only one sweep at a time per worker
})
@Injectable()
export class SlaSweepProcessor extends WorkerHost {
  private readonly logger = new Logger(SlaSweepProcessor.name);

  constructor(
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
    @InjectQueue('sla-escalation') private readonly escalationQueue: Queue,
    private readonly metrics: SlaMetricsService,
  ) {}

  async process(job: Job): Promise<any> {
    this.logger.log(`Starting SLA sweep... Job ID: ${job.id}`);
    this.metrics.slaSweeps.inc();

    // Find all PENDING tasks where dueDate is in the past
    // Limit to 1000 per sweep to prevent memory bloat and ensure fast processing
    const breachedTasks = await this.prisma.approvalTask.findMany({
      where: {
        status: 'PENDING',
        dueDate: { lt: new Date() },
      },
      select: { id: true, tenantId: true },
      take: 1000,
    });

    if (breachedTasks.length === 0) {
      this.logger.log('No SLA breaches detected.');
      return { breachedCount: 0 };
    }

    this.logger.warn(`Detected ${breachedTasks.length} SLA breaches. Queuing for escalation...`);
    this.metrics.slaBreachesDetected.inc(breachedTasks.length);

    // Fan-out: Push individual tasks to the escalation queue for horizontal scaling
    const jobs = breachedTasks.map((task) => ({
      name: 'escalate-task',
      data: { taskId: task.id, tenantId: task.tenantId },
      opts: {
        jobId: `escalate-${task.id}`, // Idempotent: prevents duplicate escalation jobs for the same task
        attempts: 3,
        backoff: { type: 'exponential', delay: 5000 }, // Retry strategy
        removeOnComplete: true,
      },
    }));

    await this.escalationQueue.addBulk(jobs);

    return { breachedCount: breachedTasks.length };
  }
}
