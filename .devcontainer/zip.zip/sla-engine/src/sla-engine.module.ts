import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { SlaCronService } from './scheduler/sla-cron.service';
import { SlaSweepProcessor } from './scheduler/sla-sweep.processor';
import { SlaEscalationProcessor } from './processor/sla-escalation.processor';
import { SlaMetricsService } from './metrics/sla-metrics.service';
import { EventPublisher } from './infrastructure/events/event.publisher';
import { PrismaClient } from '@prisma/client';

@Module({
  imports: [
    // 5. Must handle delayed Redis availability and service restarts
    BullModule.forRoot({
      connection: {
        host: process.env.REDIS_HOST || 'localhost',
        port: parseInt(process.env.REDIS_PORT || '6379', 10),
        password: process.env.REDIS_PASSWORD,
        maxRetriesPerRequest: null, // Required by BullMQ
        enableReadyCheck: false,
        retryStrategy: (times: number) => {
          // Exponential backoff for Redis connection
          return Math.min(times * 1000, 20000);
        },
      },
    }),
    BullModule.registerQueue({
      name: 'sla-sweep',
    }),
    BullModule.registerQueue({
      name: 'sla-escalation',
    }),
  ],
  providers: [
    SlaCronService,
    SlaSweepProcessor,
    SlaEscalationProcessor,
    SlaMetricsService,
    EventPublisher,
    {
      provide: 'PRISMA_CLIENT',
      useValue: new PrismaClient(),
    },
  ],
})
export class SlaEngineModule {}
