export interface CursorData {
  id: string;
  created_at: string;
}

export class CursorPaginationHelper {
  static encodeCursor(data: CursorData): string {
    const jsonString = JSON.stringify(data);
    return Buffer.from(jsonString, 'utf-8').toString('base64');
  }

  static decodeCursor(cursor: string): CursorData | null {
    try {
      const jsonString = Buffer.from(cursor, 'base64').toString('utf-8');
      const parsed = JSON.parse(jsonString);
      
      if (!parsed.id || !parsed.created_at) {
        return null;
      }
      
      return {
        id: parsed.id,
        created_at: parsed.created_at,
      };
    } catch (error) {
      return null;
    }
  }
}
