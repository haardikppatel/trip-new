import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { ExpenseListService } from '../services/expense-list.service';
import { ListExpenseQueryDto, ListExpenseQuerySchema } from '../dto/list-expense.dto';
import { ZodValidationPipe } from '../dto/create-expense.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';

@ApiTags('Expenses')
@ApiBearerAuth('JWT-auth')
@Controller('api/expenses')
@UseGuards(RolesGuard)
export class ExpenseListController {
  constructor(private readonly expenseListService: ExpenseListService) {}

  @Get()
  @Roles('Employee', 'Manager', 'ExpenseManager', 'Finance', 'ExpenseAdmin')
  @ApiOperation({ summary: 'List Expense Claims with pagination and filtering' })
  @ApiResponse({ status: 200, description: 'Paginated list of expense claims' })
  @ApiResponse({ status: 400, description: 'Invalid query parameters' })
  @ApiResponse({ status: 403, description: 'Unauthorized role' })
  @ApiQuery({ name: 'status', required: false, enum: ['DRAFT', 'SUBMITTED', 'PENDING_APPROVAL', 'APPROVED', 'PARTIALLY_APPROVED', 'REJECTED', 'PROCESSING_PAYMENT', 'PAID', 'FROZEN'] })
  @ApiQuery({ name: 'claimType', required: false, enum: ['STANDALONE', 'TRAVEL_LINKED'] })
  @ApiQuery({ name: 'fromDate', required: false, type: String, format: 'date-time' })
  @ApiQuery({ name: 'toDate', required: false, type: String, format: 'date-time' })
  @ApiQuery({ name: 'minAmount', required: false, type: Number })
  @ApiQuery({ name: 'maxAmount', required: false, type: Number })
  @ApiQuery({ name: 'pageSize', required: false, type: Number, default: 20 })
  @ApiQuery({ name: 'cursor', required: false, type: String })
  async listExpenses(
    @Req() req: Request,
    @Query(new ZodValidationPipe(ListExpenseQuerySchema)) query: ListExpenseQueryDto,
  ) {
    const tenantId = req['tenantId'];
    const userId = req['user'].sub;
    const roles = req['user'].roles || [];

    const result = await this.expenseListService.listExpenses(tenantId, userId, roles, query);

    return result; // GlobalResponseInterceptor will map { items, meta } to { success: true, data: items, meta }
  }
}
