import { Controller, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { ExpenseService } from '../services/expense.service';
import { RejectExpenseDto, RejectExpenseSchema } from '../dto/reject-expense.dto';
import { ZodValidationPipe } from '../dto/create-expense.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam } from '@nestjs/swagger';

@ApiTags('Expenses')
@ApiBearerAuth('JWT-auth')
@Controller('api/expenses')
@UseGuards(RolesGuard)
export class ExpenseController {
  constructor(private readonly expenseService: ExpenseService) {}

  @Post(':id/reject')
  @Roles('Manager', 'ExpenseManager', 'Finance')
  @ApiOperation({ summary: 'Reject or Send Back an expense claim' })
  @ApiParam({ name: 'id', description: 'The UUID of the expense claim' })
  @ApiResponse({ status: 200, description: 'Claim rejected or sent back successfully' })
  @ApiResponse({ status: 400, description: 'Invalid status or action' })
  @ApiResponse({ status: 403, description: 'Self-action forbidden or not current approver' })
  @ApiResponse({ status: 404, description: 'Claim not found' })
  @ApiResponse({ status: 409, description: 'Already terminated' })
  async rejectExpense(
    @Req() req: Request,
    @Param('id') claimId: string,
    @Body(new ZodValidationPipe(RejectExpenseSchema)) dto: RejectExpenseDto,
  ) {
    const tenantId = req['tenantId'];
    const actorId = req['user'].sub;
    const roles = req['user'].roles || [];

    const result = await this.expenseService.rejectExpense(tenantId, actorId, roles, claimId, dto);
    return result;
  }
}
