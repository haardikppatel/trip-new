import { Controller, Post, Param, Body, Req, UseGuards, BadRequestException } from '@nestjs/common';
import { Request } from 'express';
import { PaymentService } from '../services/payment.service';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam, ApiBody } from '@nestjs/swagger';

@ApiTags('Payments')
@ApiBearerAuth('JWT-auth')
@Controller('api')
@UseGuards(RolesGuard)
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('expenses/:id/pay')
  @Roles('Finance')
  @ApiOperation({ summary: 'Initiate payment for an approved expense claim' })
  @ApiParam({ name: 'id', description: 'The UUID of the expense claim' })
  @ApiResponse({ status: 201, description: 'Payment initiated successfully' })
  @ApiResponse({ status: 400, description: 'Invalid status transition' })
  @ApiResponse({ status: 403, description: 'Unauthorized role' })
  @ApiResponse({ status: 404, description: 'Claim not found' })
  @ApiResponse({ status: 409, description: 'Payment already initiated' })
  async initiatePayment(
    @Req() req: Request,
    @Param('id') claimId: string,
  ) {
    const tenantId = req['tenantId'];
    const actorId = req['user'].sub;

    const result = await this.paymentService.initiatePayment(tenantId, actorId, claimId);
    return result;
  }

  @Post('payments/:paymentId/complete')
  @Roles('Finance')
  @ApiOperation({ summary: 'Mark payment as Paid or Failed (Simulated Webhook)' })
  @ApiParam({ name: 'paymentId', description: 'The UUID of the payment record' })
  @ApiBody({ schema: { type: 'object', properties: { status: { type: 'string', enum: ['Paid', 'Failed'] } } } })
  @ApiResponse({ status: 201, description: 'Payment completed successfully' })
  @ApiResponse({ status: 400, description: 'Invalid status' })
  @ApiResponse({ status: 403, description: 'Unauthorized role' })
  @ApiResponse({ status: 404, description: 'Payment or Claim not found' })
  @ApiResponse({ status: 409, description: 'Payment already completed' })
  async completePayment(
    @Req() req: Request,
    @Param('paymentId') paymentId: string,
    @Body() body: { status: string },
  ) {
    const tenantId = req['tenantId'];
    const actorId = req['user'].sub;

    if (body.status !== 'Paid' && body.status !== 'Failed') {
      throw new BadRequestException('Status must be Paid or Failed');
    }

    const result = await this.paymentService.completePayment(tenantId, actorId, paymentId, body.status as 'Paid' | 'Failed');
    return result;
  }
}
