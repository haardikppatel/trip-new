import { Controller, Post, Param, Body, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { ReceiptService } from '../services/receipt.service';
import { GenerateUploadUrlDto, GenerateUploadUrlSchema, ConfirmUploadDto, ConfirmUploadSchema } from '../dto/receipt.dto';
import { ZodValidationPipe } from '../dto/create-expense.dto';
import { Roles } from '../common/decorators/roles.decorator';
import { RolesGuard } from '../common/guards/roles.guard';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth, ApiParam } from '@nestjs/swagger';

@ApiTags('Receipts')
@ApiBearerAuth('JWT-auth')
@Controller('api/expenses')
@UseGuards(RolesGuard)
export class ReceiptController {
  constructor(private readonly receiptService: ReceiptService) {}

  @Post(':id/receipt/upload-url')
  @Roles('Employee')
  @ApiOperation({ summary: 'Generate a presigned S3 URL for receipt upload' })
  @ApiParam({ name: 'id', description: 'The UUID of the expense claim' })
  @ApiResponse({ status: 200, description: 'Presigned URL generated successfully' })
  @ApiResponse({ status: 400, description: 'Validation error' })
  @ApiResponse({ status: 403, description: 'Not the claim owner' })
  @ApiResponse({ status: 404, description: 'Claim not found' })
  @ApiResponse({ status: 409, description: 'Invalid claim status' })
  async generateUploadUrl(
    @Req() req: Request,
    @Param('id') claimId: string,
    @Body(new ZodValidationPipe(GenerateUploadUrlSchema)) dto: GenerateUploadUrlDto,
  ) {
    const tenantId = req['tenantId'];
    const employeeId = req['user'].sub;

    const result = await this.receiptService.generateUploadUrl(tenantId, employeeId, claimId, dto);
    return result;
  }

  @Post(':id/receipt/confirm')
  @Roles('Employee')
  @ApiOperation({ summary: 'Confirm a receipt upload to S3' })
  @ApiParam({ name: 'id', description: 'The UUID of the expense claim' })
  @ApiResponse({ status: 200, description: 'Receipt upload confirmed successfully' })
  @ApiResponse({ status: 400, description: 'File size or type mismatch' })
  @ApiResponse({ status: 403, description: 'Not the claim owner' })
  @ApiResponse({ status: 404, description: 'Claim or upload record not found' })
  @ApiResponse({ status: 500, description: 'S3 validation failed' })
  async confirmUpload(
    @Req() req: Request,
    @Param('id') claimId: string,
    @Body(new ZodValidationPipe(ConfirmUploadSchema)) dto: ConfirmUploadDto,
  ) {
    const tenantId = req['tenantId'];
    const employeeId = req['user'].sub;

    const result = await this.receiptService.confirmUpload(tenantId, employeeId, claimId, dto);
    return result;
  }
}
