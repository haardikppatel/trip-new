export class InvalidStatusTransitionError extends Error {
  public readonly code = 'INVALID_STATUS_TRANSITION';

  constructor(fromStatus: string, toStatus: string) {
    super(`Cannot transition from ${fromStatus} to ${toStatus}`);
    this.name = 'InvalidStatusTransitionError';
    Object.setPrototypeOf(this, InvalidStatusTransitionError.prototype);
  }
}
