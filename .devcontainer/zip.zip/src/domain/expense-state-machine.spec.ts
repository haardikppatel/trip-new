import { ExpenseStatus, isValidTransition, assertValidTransition } from './expense-state-machine';
import { InvalidStatusTransitionError } from './errors/invalid-status-transition.error';

describe('Expense State Machine', () => {
  describe('isValidTransition', () => {
    it('should allow Draft -> Submitted', () => {
      expect(isValidTransition(ExpenseStatus.Draft, ExpenseStatus.Submitted)).toBe(true);
    });

    it('should allow Submitted -> PartiallyApproved', () => {
      expect(isValidTransition(ExpenseStatus.Submitted, ExpenseStatus.PartiallyApproved)).toBe(true);
    });

    it('should allow Submitted -> ApprovedPendingPayment', () => {
      expect(isValidTransition(ExpenseStatus.Submitted, ExpenseStatus.ApprovedPendingPayment)).toBe(true);
    });

    it('should allow Submitted -> Rejected', () => {
      expect(isValidTransition(ExpenseStatus.Submitted, ExpenseStatus.Rejected)).toBe(true);
    });

    it('should allow Submitted -> SentBack', () => {
      expect(isValidTransition(ExpenseStatus.Submitted, ExpenseStatus.SentBack)).toBe(true);
    });

    it('should allow PartiallyApproved -> ApprovedPendingPayment', () => {
      expect(isValidTransition(ExpenseStatus.PartiallyApproved, ExpenseStatus.ApprovedPendingPayment)).toBe(true);
    });

    it('should allow PartiallyApproved -> Rejected', () => {
      expect(isValidTransition(ExpenseStatus.PartiallyApproved, ExpenseStatus.Rejected)).toBe(true);
    });

    it('should allow ApprovedPendingPayment -> PaymentProcessing', () => {
      expect(isValidTransition(ExpenseStatus.ApprovedPendingPayment, ExpenseStatus.PaymentProcessing)).toBe(true);
    });

    it('should allow PaymentProcessing -> Paid', () => {
      expect(isValidTransition(ExpenseStatus.PaymentProcessing, ExpenseStatus.Paid)).toBe(true);
    });

    it('should allow PaymentProcessing -> PaymentFailed', () => {
      expect(isValidTransition(ExpenseStatus.PaymentProcessing, ExpenseStatus.PaymentFailed)).toBe(true);
    });

    it('should allow PaymentFailed -> PaymentProcessing', () => {
      expect(isValidTransition(ExpenseStatus.PaymentFailed, ExpenseStatus.PaymentProcessing)).toBe(true);
    });

    it('should allow SentBack -> Draft', () => {
      expect(isValidTransition(ExpenseStatus.SentBack, ExpenseStatus.Draft)).toBe(true);
    });

    it('should block Draft -> Paid', () => {
      expect(isValidTransition(ExpenseStatus.Draft, ExpenseStatus.Paid)).toBe(false);
    });

    it('should block Submitted -> Paid', () => {
      expect(isValidTransition(ExpenseStatus.Submitted, ExpenseStatus.Paid)).toBe(false);
    });

    it('should block terminal state Rejected -> Draft', () => {
      expect(isValidTransition(ExpenseStatus.Rejected, ExpenseStatus.Draft)).toBe(false);
    });

    it('should block terminal state Paid -> Draft', () => {
      expect(isValidTransition(ExpenseStatus.Paid, ExpenseStatus.Draft)).toBe(false);
    });
  });

  describe('assertValidTransition', () => {
    it('should not throw on valid transition', () => {
      expect(() => assertValidTransition(ExpenseStatus.Draft, ExpenseStatus.Submitted)).not.toThrow();
    });

    it('should throw InvalidStatusTransitionError on invalid transition', () => {
      expect(() => assertValidTransition(ExpenseStatus.Submitted, ExpenseStatus.Paid))
        .toThrow(InvalidStatusTransitionError);
      
      try {
        assertValidTransition(ExpenseStatus.Submitted, ExpenseStatus.Paid);
      } catch (error: any) {
        expect(error).toBeInstanceOf(InvalidStatusTransitionError);
        expect(error.code).toBe('INVALID_STATUS_TRANSITION');
        expect(error.message).toBe('Cannot transition from SUBMITTED to PAID');
      }
    });
  });
});
