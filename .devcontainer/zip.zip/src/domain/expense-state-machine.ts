import { InvalidStatusTransitionError } from './errors/invalid-status-transition.error';

export enum ExpenseStatus {
  Draft = 'DRAFT',
  Submitted = 'SUBMITTED',
  PartiallyApproved = 'PARTIALLY_APPROVED',
  ApprovedPendingPayment = 'APPROVED',
  PaymentProcessing = 'PROCESSING_PAYMENT',
  Paid = 'PAID',
  PaymentFailed = 'PAYMENT_FAILED',
  Rejected = 'REJECTED',
  SentBack = 'SENT_BACK',
}

export type TransitionMap = Readonly<Record<ExpenseStatus, ReadonlyArray<ExpenseStatus>>>;

export const EXPENSE_TRANSITIONS: TransitionMap = Object.freeze({
  [ExpenseStatus.Draft]: [ExpenseStatus.Submitted],
  [ExpenseStatus.Submitted]: [
    ExpenseStatus.PartiallyApproved,
    ExpenseStatus.ApprovedPendingPayment,
    ExpenseStatus.Rejected,
    ExpenseStatus.SentBack,
  ],
  [ExpenseStatus.PartiallyApproved]: [
    ExpenseStatus.ApprovedPendingPayment,
    ExpenseStatus.Rejected,
  ],
  [ExpenseStatus.ApprovedPendingPayment]: [ExpenseStatus.PaymentProcessing],
  [ExpenseStatus.PaymentProcessing]: [ExpenseStatus.Paid, ExpenseStatus.PaymentFailed],
  [ExpenseStatus.PaymentFailed]: [ExpenseStatus.PaymentProcessing],
  [ExpenseStatus.SentBack]: [ExpenseStatus.Draft],
  [ExpenseStatus.Rejected]: [], // Terminal
  [ExpenseStatus.Paid]: [], // Terminal
});

export function isValidTransition(from: ExpenseStatus, to: ExpenseStatus): boolean {
  const allowedTransitions = EXPENSE_TRANSITIONS[from];
  if (!allowedTransitions) {
    return false;
  }
  return allowedTransitions.includes(to);
}

export function assertValidTransition(from: ExpenseStatus, to: ExpenseStatus): void {
  if (!isValidTransition(from, to)) {
    throw new InvalidStatusTransitionError(from, to);
  }
}
