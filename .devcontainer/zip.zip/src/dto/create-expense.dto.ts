import { z } from 'zod';

export const CreateExpenseSchema = z.object({
  claimType: z.enum(['STANDALONE', 'TRAVEL_LINKED']),
  trId: z.string().optional(),
  lineItems: z.array(
    z.object({
      categoryId: z.string().uuid('Invalid category ID format'),
      expenseDate: z.string().datetime({ message: 'Invalid ISO date format' }),
      merchantName: z.string().max(200, 'Merchant name must be 200 characters or less'),
      amountOriginal: z.number().positive('Amount must be greater than 0'),
      currencyOriginal: z.string().length(3, 'Currency must be a 3-letter ISO code'),
      description: z.string().optional(),
    })
  ).min(1, 'At least 1 line item is required'),
}).superRefine((data, ctx) => {
  if (data.claimType === 'TRAVEL_LINKED' && !data.trId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'TravelLinked claims require a trId',
      path: ['trId'],
    });
  }
  if (data.claimType === 'STANDALONE' && data.trId) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Standalone claims must not include a trId',
      path: ['trId'],
    });
  }
});

export type CreateExpenseDto = z.infer<typeof CreateExpenseSchema>;

import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';

@Injectable()
export class ZodValidationPipe implements PipeTransform {
  constructor(private schema: z.ZodSchema<any>) {}

  transform(value: any) {
    try {
      return this.schema.parse(value);
    } catch (error) {
      if (error instanceof z.ZodError) {
        throw new BadRequestException({
          code: 'VALIDATION_ERROR',
          message: 'Validation failed',
          details: error.errors,
        });
      }
      throw new BadRequestException('Validation failed');
    }
  }
}
