import { z } from 'zod';
import { ExpenseClaimStatus, ClaimType } from '@prisma/client';

export const ListExpenseQuerySchema = z.object({
  status: z.nativeEnum(ExpenseClaimStatus).optional(),
  claimType: z.nativeEnum(ClaimType).optional(),
  fromDate: z.string().datetime().optional(),
  toDate: z.string().datetime().optional(),
  minAmount: z.coerce.number().nonnegative().optional(),
  maxAmount: z.coerce.number().positive().optional(),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  cursor: z.string().optional(),
}).superRefine((data, ctx) => {
  if (data.fromDate && data.toDate && new Date(data.fromDate) > new Date(data.toDate)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'fromDate cannot be after toDate',
      path: ['fromDate'],
    });
  }
  if (data.minAmount !== undefined && data.maxAmount !== undefined && data.minAmount > data.maxAmount) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'minAmount cannot be greater than maxAmount',
      path: ['minAmount'],
    });
  }
});

export type ListExpenseQueryDto = z.infer<typeof ListExpenseQuerySchema>;
