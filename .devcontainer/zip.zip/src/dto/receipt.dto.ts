import { z } from 'zod';

export const GenerateUploadUrlSchema = z.object({
  fileName: z.string().min(1).max(200),
  contentType: z.enum(['image/jpeg', 'image/png', 'application/pdf']),
  fileSize: z.number().positive().max(10 * 1024 * 1024, 'File size must be 10MB or less'),
  sha256Hash: z.string().min(1, 'SHA-256 hash is required'),
});

export type GenerateUploadUrlDto = z.infer<typeof GenerateUploadUrlSchema>;

export const ConfirmUploadSchema = z.object({
  s3Key: z.string().min(1, 'S3 key is required'),
});

export type ConfirmUploadDto = z.infer<typeof ConfirmUploadSchema>;
