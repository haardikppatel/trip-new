import { z } from 'zod';

export const RejectExpenseSchema = z.object({
  action: z.enum(['Reject', 'SendBack']),
  reason: z.string().min(1, 'Reason is required').max(1000, 'Reason must be 1000 characters or less'),
});

export type RejectExpenseDto = z.infer<typeof RejectExpenseSchema>;
