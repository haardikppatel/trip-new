export interface ExpenseDraftCreatedEvent { claim_id: string; tenant_id: string; employee_id: string; total_claimed: number; }
export interface ExpenseSubmittedEvent { claim_id: string; tenant_id: string; employee_id: string; total_claimed: number; policy_status: string; }
export interface ExpensePartiallyApprovedEvent { claim_id: string; tenant_id: string; approver_id: string; level: number; total_approved: number; }
export interface ExpenseApprovedFinalEvent { claim_id: string; tenant_id: string; approver_id: string; level: number; total_approved: number; }

export interface ExpenseRejectedEvent {
  claim_id: string;
  tenant_id: string;
  actor_id: string;
  action: 'Reject';
  reason: string;
}

export interface ExpenseSentBackEvent {
  claim_id: string;
  tenant_id: string;
  actor_id: string;
  action: 'SendBack';
  reason: string;
}

export interface ExpenseReceiptUploadedEvent {
  claim_id: string;
  tenant_id: string;
  s3_key: string;
}

export const EXPENSE_EVENTS = {
  DRAFT_CREATED: 'tripaxis.expense.draft_created.v1',
  SUBMITTED: 'tripaxis.expense.submitted.v1',
  PARTIALLY_APPROVED: 'tripaxis.expense.partially_approved.v1',
  APPROVED_FINAL: 'tripaxis.expense.approved_final.v1',
  REJECTED: 'tripaxis.expense.rejected.v1',
  SENT_BACK: 'tripaxis.expense.sent_back.v1',
  RECEIPT_UPLOADED: 'tripaxis.expense.receipt_uploaded.v1',
};
