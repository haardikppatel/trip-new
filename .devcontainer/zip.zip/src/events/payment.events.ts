export interface ExpensePaymentInitiatedEvent {
  payment_id: string;
  claim_id: string;
  tenant_id: string;
  amount: number;
  currency: string;
  initiated_by: string;
}

export interface ExpensePaidEvent {
  payment_id: string;
  claim_id: string;
  tenant_id: string;
  amount: number;
  currency: string;
  paid_at: string;
}

export interface ExpensePaymentFailedEvent {
  payment_id: string;
  claim_id: string;
  tenant_id: string;
  amount: number;
  currency: string;
  failed_at: string;
}

export const PAYMENT_EVENTS = {
  INITIATED: 'tripaxis.expense.payment_initiated.v1',
  PAID: 'tripaxis.expense.paid.v1',
  FAILED: 'tripaxis.expense.payment_failed.v1',
};
