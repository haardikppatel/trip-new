import { PrismaClient } from '@prisma/client';
import { AsyncLocalStorage } from 'async_hooks';

// 1. AsyncLocalStorage to hold tenant context across the request lifecycle
export const tenantContext = new AsyncLocalStorage<{ tenantId: string }>();

// 2. Prisma Extension for RLS
export function getRlsPrismaClient(prisma: PrismaClient) {
  return prisma.$extends({
    query: {
      $allModels: {
        async $allOperations({ args, query }) {
          const context = tenantContext.getStore();
          const tenantId = context?.tenantId;

          if (!tenantId) {
            // If no tenant context is found (e.g., system cron jobs), bypass RLS 
            // OR throw an error depending on strictness requirements.
            throw new Error('Tenant context is missing. Cannot execute query.');
          }

          // 3. Connection Middleware: Set app.tenant_id for the transaction
          return prisma.$transaction(async (tx) => {
            // Set the PostgreSQL session variable. 
            // 'true' means the setting is local to this transaction.
            await tx.$executeRawUnsafe(
              `SELECT set_config('app.tenant_id', $1, true);`, 
              tenantId
            );

            // Execute the actual Prisma query within the RLS-enforced transaction
            return query(args);
          });
        },
      },
    },
  });
}

// Usage Example in an Express/NestJS Middleware:
/*
import { Request, Response, NextFunction } from 'express';

export function tenantMiddleware(req: Request, res: Response, next: NextFunction) {
  const tenantId = req.headers['x-tenant-id'] as string;
  
  if (!tenantId) {
    return res.status(401).json({ error: 'Missing x-tenant-id header' });
  }

  tenantContext.run({ tenantId }, () => {
    next();
  });
}
*/
