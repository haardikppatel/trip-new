import { Injectable, Logger, InternalServerErrorException } from '@nestjs/common';
import { S3Client, PutObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

@Injectable()
export class S3Service {
  private readonly logger = new Logger(S3Service.name);
  private readonly s3Client: S3Client;
  private readonly bucketName: string;

  constructor() {
    this.bucketName = process.env.AWS_S3_BUCKET || 'tripaxis-receipts-dev';
    this.s3Client = new S3Client({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || 'mock-access-key',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || 'mock-secret-key',
      },
    });
  }

  async generatePresignedUrl(key: string, contentType: string, expiresIn: number = 600): Promise<string> {
    try {
      const command = new PutObjectCommand({
        Bucket: this.bucketName,
        Key: key,
        ContentType: contentType,
      });
      return await getSignedUrl(this.s3Client, command, { expiresIn });
    } catch (error) {
      this.logger.error(`Failed to generate presigned URL for key ${key}`, error);
      throw new InternalServerErrorException('Failed to generate upload URL');
    }
  }

  async headObject(key: string): Promise<{ contentLength: number; contentType: string }> {
    try {
      const command = new HeadObjectCommand({
        Bucket: this.bucketName,
        Key: key,
      });
      const response = await this.s3Client.send(command);
      return {
        contentLength: response.ContentLength || 0,
        contentType: response.ContentType || '',
      };
    } catch (error: any) {
      this.logger.error(`Failed to head object for key ${key}`, error);
      if (error.name === 'NotFound') {
        throw new InternalServerErrorException('S3 object not found');
      }
      throw new InternalServerErrorException('S3 validation failed');
    }
  }
}
