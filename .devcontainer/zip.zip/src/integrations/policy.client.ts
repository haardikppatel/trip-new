import { Injectable, Logger } from '@nestjs/common';
import { trace, SpanStatusCode } from '@opentelemetry/api';

export interface PolicyValidationResult {
  policyStatus: 'OK' | 'VIOLATION';
  violations: any[];
}

@Injectable()
export class PolicyGrpcClient {
  private readonly logger = new Logger(PolicyGrpcClient.name);

  async validateExpensePolicy(tenantId: string, claimSummary: any): Promise<PolicyValidationResult> {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('grpc.policy.validate', async (span) => {
      try {
        span.setAttribute('rpc.system', 'grpc');
        span.setAttribute('rpc.service', 'PolicyService');
        span.setAttribute('rpc.method', 'ValidateExpense');
        span.setAttribute('tenant_id', tenantId);

        // Mocking gRPC call to internal Policy Service
        this.logger.debug(`Calling Policy Service for claim ${claimSummary.claim_id}`);
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 50));

        // Mock response: 10% chance of violation for demonstration
        const isViolation = Math.random() > 0.9;
        const result: PolicyValidationResult = {
          policyStatus: isViolation ? 'VIOLATION' : 'OK',
          violations: isViolation ? [{ code: 'AMOUNT_EXCEEDED', message: 'Amount exceeds policy limit' }] : [],
        };

        span.setAttribute('policy_status', result.policyStatus);
        span.setStatus({ code: SpanStatusCode.OK });
        return result;
      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }
}
