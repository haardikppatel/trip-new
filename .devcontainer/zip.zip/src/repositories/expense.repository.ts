import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaClient, ExpenseClaimStatus, ExpenseLineItemStatus, ClaimType } from '@prisma/client';
import { tenantContext } from '../infrastructure/prisma/tenant.context';

@Injectable()
export class ExpenseRepository {
  constructor(private readonly prisma: PrismaClient) {}

  private get tenantId(): string {
    const context = tenantContext.getStore();
    if (!context?.tenantId) {
      throw new Error('Tenant context missing in repository layer');
    }
    return context.tenantId;
  }

  private get rlsClient() {
    return (this.prisma as any).rlsClient || this.prisma;
  }

  async getEmployeePolicy(employeeId: string) {
    // Mocking policy retrieval for the employee
    const policy = await this.rlsClient.policy.findFirst({
      where: { tenant_id: this.tenantId },
    });
    return policy;
  }

  async getSubsidiaryConfig(employeeId: string) {
    // Mocking subsidiary retrieval
    return { id: 'sub-uuid-123', base_currency: 'USD' };
  }

  async getCategories(categoryIds: string[]) {
    return this.rlsClient.expenseCategory.findMany({
      where: {
        tenant_id: this.tenantId,
        id: { in: categoryIds },
      },
    });
  }

  async generateClaimId(): Promise<string> {
    const year = new Date().getFullYear();
    // Using a transaction-safe sequence in PostgreSQL
    const result: any[] = await this.prisma.$queryRaw`SELECT nextval('expense_claim_seq') as seq`;
    const seq = result[0].seq.toString().padStart(5, '0');
    return `EXP-${year}-${seq}`;
  }

  async createDraftClaimWithAudit(
    employeeId: string,
    subsidiaryId: string,
    policyId: string,
    claimId: string,
    claimType: ClaimType,
    trId: string | undefined,
    baseCurrency: string,
    totalClaimed: number,
    lineItemsData: any[]
  ) {
    return this.rlsClient.$transaction(async (tx: any) => {
      // 1. Create Expense Claim
      const claim = await tx.expenseClaim.create({
        data: {
          tenant_id: this.tenantId,
          claim_id: claimId,
          employee_id: employeeId,
          subsidiary_id: subsidiaryId,
          policy_id: policyId,
          tr_id: trId,
          claim_type: claimType,
          status: ExpenseClaimStatus.DRAFT,
          base_currency: baseCurrency,
          total_claimed: totalClaimed,
          version: 1,
          is_locked: false,
        },
      });

      // 2. Create Line Items
      await tx.expenseLineItem.createMany({
        data: lineItemsData.map((item) => ({
          tenant_id: this.tenantId,
          claim_id: claim.id,
          category_id: item.categoryId,
          expense_date: new Date(item.expenseDate),
          merchant_name: item.merchantName,
          amount_original: item.amountOriginal,
          currency_original: item.currencyOriginal,
          fx_rate: item.fxRate,
          amount_base: item.amountBase,
          is_payable: item.isPayable,
          is_billable: item.isBillable,
          status: ExpenseLineItemStatus.PENDING,
          has_receipt: false,
        })),
      });

      // 3. Write Immutable Audit Record
      await tx.expenseAuditLog.create({
        data: {
          tenant_id: this.tenantId,
          claim_id: claim.id,
          actor_id: employeeId,
          action: 'ExpenseDraftCreated',
          details: {
            total_claimed: totalClaimed,
            line_item_count: lineItemsData.length,
          },
        },
      });

      return claim;
    });
  }
}
