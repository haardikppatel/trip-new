import { Injectable, ForbiddenException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaClient, Prisma, ExpenseClaimStatus } from '@prisma/client';
import { ListExpenseQueryDto } from '../dto/list-expense.dto';
import { CursorPaginationHelper } from '../common/utils/pagination.helper';
import { trace, SpanStatusCode } from '@opentelemetry/api';

@Injectable()
export class ExpenseListService {
  private readonly logger = new Logger(ExpenseListService.name);

  constructor(private readonly prisma: PrismaClient) {}

  async listExpenses(tenantId: string, userId: string, roles: string[], query: ListExpenseQueryDto) {
    const tracer = trace.getTracer('tripaxis-expense-service');
    
    return tracer.startActiveSpan('listExpenses', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('user_id', userId);
        span.setAttribute('roles', roles.join(','));

        // 1. Determine Role Scope
        const scopeWhere = await this.buildRoleScopeWhere(tenantId, userId, roles);
        
        // 2. Build Filter Where
        const filterWhere = this.buildFilterWhere(query);
        
        // Combine Where clauses
        const where: Prisma.ExpenseClaimWhereInput = {
          tenant_id: tenantId,
          deleted_at: null,
          AND: [scopeWhere, filterWhere].filter(Boolean) as Prisma.ExpenseClaimWhereInput[],
        };

        span.setAttribute('filter_count', Object.keys(filterWhere).length);

        // 3. Handle Pagination Cursor
        let cursorObj: Prisma.ExpenseClaimWhereUniqueInput | undefined;
        let skip = 0;

        if (query.cursor) {
          const decoded = CursorPaginationHelper.decodeCursor(query.cursor);
          if (!decoded) {
            throw new BadRequestException('Invalid pagination cursor format');
          }
          cursorObj = {
            id: decoded.id,
          };
          skip = 1; // Skip the cursor record itself
        }

        // 4. Execute Query
        const take = query.pageSize + 1; // Fetch one extra to determine if there's a next page

        const claims = await this.prisma.expenseClaim.findMany({
          where,
          take,
          skip,
          cursor: cursorObj,
          orderBy: [
            { created_at: 'desc' },
            { id: 'desc' }, // Stable sort tie-breaker
          ],
          select: {
            id: true,
            claim_id: true,
            status: true,
            claim_type: true,
            total_claimed: true,
            total_approved: true,
            base_currency: true,
            submitted_at: true,
            created_at: true,
          },
        });

        // 5. Process Pagination Result
        let nextCursor: string | undefined;
        
        if (claims.length > query.pageSize) {
          const nextRecord = claims.pop(); // Remove the extra record
          if (nextRecord) {
            nextCursor = CursorPaginationHelper.encodeCursor({
              id: nextRecord.id,
              created_at: nextRecord.created_at.toISOString(),
            });
          }
        }

        span.setAttribute('result_count', claims.length);
        span.setStatus({ code: SpanStatusCode.OK });

        // 6. Map Response
        const data = claims.map(c => ({
          claimId: c.claim_id,
          status: c.status,
          claimType: c.claim_type,
          totalClaimed: Number(c.total_claimed),
          totalApproved: c.total_approved ? Number(c.total_approved) : null,
          baseCurrency: c.base_currency,
          submittedAt: c.submitted_at,
          createdAt: c.created_at,
        }));

        return {
          items: data,
          meta: {
            nextCursor,
            pageSize: query.pageSize,
          }
        };

      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }

  private async buildRoleScopeWhere(tenantId: string, userId: string, roles: string[]): Promise<Prisma.ExpenseClaimWhereInput> {
    if (roles.includes('SaaSAdmin')) {
      throw new ForbiddenException('SaaSAdmin must use the Admin service to view tenant data');
    }

    if (roles.includes('ExpenseAdmin') || roles.includes('ExpenseManager')) {
      return {}; // Can see all within tenant (tenant_id is enforced at the root level)
    }

    if (roles.includes('Finance')) {
      return {
        status: {
          in: [
            ExpenseClaimStatus.APPROVED,
            ExpenseClaimStatus.PARTIALLY_APPROVED,
            ExpenseClaimStatus.PROCESSING_PAYMENT,
            ExpenseClaimStatus.PAID,
          ],
        },
      };
    }

    if (roles.includes('Manager')) {
      // Fetch direct reports
      // In a real system, this would query the HR/User service or a materialized view
      // Mocking for this example:
      const directReportIds = await this.getDirectReportIds(tenantId, userId);
      return {
        employee_id: {
          in: [userId, ...directReportIds], // Can see own claims + direct reports
        },
      };
    }

    if (roles.includes('Employee')) {
      return {
        employee_id: userId,
      };
    }

    throw new ForbiddenException('Unauthorized role for expense listing');
  }

  private buildFilterWhere(query: ListExpenseQueryDto): Prisma.ExpenseClaimWhereInput {
    const where: Prisma.ExpenseClaimWhereInput = {};

    if (query.status) {
      where.status = query.status;
    }

    if (query.claimType) {
      where.claim_type = query.claimType;
    }

    if (query.fromDate || query.toDate) {
      where.created_at = {};
      if (query.fromDate) where.created_at.gte = new Date(query.fromDate);
      if (query.toDate) where.created_at.lte = new Date(query.toDate);
    }

    if (query.minAmount !== undefined || query.maxAmount !== undefined) {
      where.total_claimed = {};
      if (query.minAmount !== undefined) where.total_claimed.gte = query.minAmount;
      if (query.maxAmount !== undefined) where.total_claimed.lte = query.maxAmount;
    }

    return where;
  }

  private async getDirectReportIds(tenantId: string, managerId: string): Promise<string[]> {
    // Mock implementation. In reality, query User/HR service.
    return ['emp-101', 'emp-102'];
  }
}
