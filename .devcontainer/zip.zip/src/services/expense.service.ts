import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { PrismaClient, ExpenseClaimStatus, ApprovalStatus } from '@prisma/client';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { PolicyGrpcClient } from '../integrations/policy.client';
import { ApprovalWorkflowService } from '../workflows/approval.service';
import { EXPENSE_EVENTS } from '../events/expense.events';
import { trace, SpanStatusCode } from '@opentelemetry/api';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { Counter } from 'prom-client';
import { RejectExpenseDto } from '../dto/reject-expense.dto';
import { ExpenseStatus, assertValidTransition } from '../domain/expense-state-machine';

@Injectable()
export class ExpenseService {
  private readonly logger = new Logger(ExpenseService.name);
  private readonly rejectionTotal: Counter<string>;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly rabbitMQPublisher: RabbitMQPublisherService,
    private readonly policyClient: PolicyGrpcClient,
    private readonly workflowService: ApprovalWorkflowService,
    private readonly metricsService: MetricsService,
  ) {
    this.rejectionTotal = new Counter({
      name: 'tripaxis_expense_rejection_total',
      help: 'Total number of expense rejections or send backs',
      labelNames: ['tenant_id', 'action'],
    });
  }

  private get rlsClient() {
    return (this.prisma as any).rlsClient || this.prisma;
  }

  async rejectExpense(tenantId: string, actorId: string, roles: string[], claimId: string, dto: RejectExpenseDto) {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('rejectExpense', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('claim_id', claimId);
        span.setAttribute('action', dto.action);

        // 1. Fetch Claim & Approval Steps
        const claim = await this.rlsClient.expenseClaim.findFirst({
          where: { id: claimId, tenant_id: tenantId },
          include: { approval_steps: { orderBy: { step_number: 'asc' } } },
        });

        if (!claim) {
          throw new HttpException({ code: 'CLAIM_NOT_FOUND', message: 'Claim not found' }, HttpStatus.NOT_FOUND);
        }

        // 2. Determine New Status & Validate Transition via State Machine
        const newStatus = dto.action === 'Reject' ? ExpenseStatus.Rejected : ExpenseStatus.SentBack;
        assertValidTransition(claim.status as ExpenseStatus, newStatus);

        // 3. Validate Approver Rules
        if (claim.employee_id === actorId) {
          throw new HttpException({ code: 'SELF_ACTION_FORBIDDEN', message: 'You cannot reject your own claim' }, HttpStatus.FORBIDDEN);
        }

        const currentStep = claim.approval_steps.find((s: any) => s.status === ApprovalStatus.PENDING);
        if (!currentStep) {
          throw new HttpException({ code: 'INVALID_STATUS', message: 'No pending approval step found' }, HttpStatus.BAD_REQUEST);
        }

        const isFinalStage = currentStep.step_number === claim.approval_steps.length;
        const isCurrentApprover = currentStep.approver_id === actorId;
        const isExpenseManager = roles.includes('ExpenseManager');
        const isFinance = roles.includes('Finance');

        if (!isCurrentApprover && !isExpenseManager && !(isFinance && isFinalStage)) {
          throw new HttpException({ code: 'NOT_CURRENT_APPROVER', message: 'You are not authorized to reject this step' }, HttpStatus.FORBIDDEN);
        }

        // 4. Execute Transaction
        const result = await this.rlsClient.$transaction(async (tx: any) => {
          // Update Claim
          const { count } = await tx.expenseClaim.updateMany({
            where: {
              id: claimId,
              tenant_id: tenantId,
              version: claim.version,
            },
            data: {
              status: newStatus,
              version: { increment: 1 },
            },
          });

          if (count === 0) {
            throw new HttpException({ code: 'ALREADY_TERMINATED', message: 'Claim was modified concurrently' }, HttpStatus.CONFLICT);
          }

          // Close Workflow
          await this.workflowService.closeWorkflow(tx, tenantId, claim.id, actorId, dto.reason);

          // Write Immutable Audit Record
          await tx.$executeRawUnsafe(`
            INSERT INTO expense_audit_logs (id, tenant_id, claim_id, actor_id, action, previous_status, new_status, details, created_at)
            VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7::jsonb, NOW())
          `, tenantId, claim.id, actorId, dto.action === 'Reject' ? 'ExpenseRejected' : 'ExpenseSentBack', claim.status, newStatus, JSON.stringify({ reason: dto.reason }));

          return {
            claimId: claim.claim_id,
            status: dto.action === 'Reject' ? 'Rejected' : 'SentBack',
          };
        });

        // 5. Publish Event
        const eventName = dto.action === 'Reject' ? EXPENSE_EVENTS.REJECTED : EXPENSE_EVENTS.SENT_BACK;
        await this.rabbitMQPublisher.publish(
          'tripaxis.events.topic',
          eventName,
          {
            claim_id: claim.id,
            tenant_id: tenantId,
            actor_id: actorId,
            action: dto.action,
            reason: dto.reason,
          }
        );

        // 6. Record Metrics
        this.rejectionTotal.inc({ tenant_id: tenantId, action: dto.action });
        span.setStatus({ code: SpanStatusCode.OK });

        return result;

      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }
}
