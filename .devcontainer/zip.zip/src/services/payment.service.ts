import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { PrismaClient, ExpenseClaimStatus, PaymentRunStatus, PaymentMethod } from '@prisma/client';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { PAYMENT_EVENTS } from '../events/payment.events';
import { trace, SpanStatusCode } from '@opentelemetry/api';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { Counter } from 'prom-client';
import { ExpenseStatus, assertValidTransition } from '../domain/expense-state-machine';

@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);
  private readonly paymentInitiatedTotal: Counter<string>;
  private readonly paymentCompletedTotal: Counter<string>;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly rabbitMQPublisher: RabbitMQPublisherService,
    private readonly metricsService: MetricsService,
  ) {
    this.paymentInitiatedTotal = new Counter({
      name: 'tripaxis_payment_initiated_total',
      help: 'Total number of expense payments initiated',
      labelNames: ['tenant_id'],
    });
    this.paymentCompletedTotal = new Counter({
      name: 'tripaxis_payment_completed_total',
      help: 'Total number of expense payments completed or failed',
      labelNames: ['tenant_id', 'status'],
    });
  }

  private get rlsClient() {
    return (this.prisma as any).rlsClient || this.prisma;
  }

  async initiatePayment(tenantId: string, actorId: string, claimId: string) {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('initiatePayment', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('claim_id', claimId);

        // 1. Fetch Claim
        const claim = await this.rlsClient.expenseClaim.findFirst({
          where: { id: claimId, tenant_id: tenantId },
        });

        if (!claim) {
          throw new HttpException({ code: 'CLAIM_NOT_FOUND', message: 'Claim not found' }, HttpStatus.NOT_FOUND);
        }

        // 2. Validate Status Transition via State Machine
        assertValidTransition(claim.status as ExpenseStatus, ExpenseStatus.PaymentProcessing);

        // 3. Prevent Duplicate Payments
        // In this simplified model, we use PaymentRun to represent the payment attempt.
        // A real system might have a dedicated Payment record linking Claim to PaymentRun.
        // For this requirement, we check if the claim is already in PROCESSING_PAYMENT.
        // The optimistic locking on the claim version also prevents concurrent duplicate initiations.

        // 4. Execute Transaction
        const result = await this.rlsClient.$transaction(async (tx: any) => {
          // Update Claim (optimistic locking)
          const { count } = await tx.expenseClaim.updateMany({
            where: {
              id: claimId,
              tenant_id: tenantId,
              version: claim.version,
              status: ExpenseClaimStatus.APPROVED,
            },
            data: {
              status: ExpenseClaimStatus.PROCESSING_PAYMENT,
              version: { increment: 1 },
            },
          });

          if (count === 0) {
            throw new HttpException({ code: 'PAYMENT_ALREADY_INITIATED', message: 'Payment already initiated or claim modified concurrently' }, HttpStatus.CONFLICT);
          }

          // Create Payment Record (Using PaymentRun as a proxy for the payment attempt)
          const payment = await tx.paymentRun.create({
            data: {
              tenant_id: tenantId,
              subsidiary_id: claim.subsidiary_id,
              initiated_by: actorId,
              payment_method: PaymentMethod.BANK_TRANSFER, // Defaulting for this example
              status: PaymentRunStatus.PROCESSING,
              total_amount: claim.total_approved || claim.total_claimed,
              currency: claim.base_currency,
              claim_count: 1,
              initiated_at: new Date(),
            },
          });

          // Write Immutable Audit Record
          await tx.$executeRawUnsafe(`
            INSERT INTO expense_audit_logs (id, tenant_id, claim_id, actor_id, action, previous_status, new_status, details, created_at)
            VALUES (gen_random_uuid(), $1, $2, $3, 'ExpensePaymentInitiated', $4, $5, $6::jsonb, NOW())
          `, tenantId, claim.id, actorId, ExpenseClaimStatus.APPROVED, ExpenseClaimStatus.PROCESSING_PAYMENT, JSON.stringify({ payment_id: payment.id, amount: Number(payment.total_amount) }));

          return {
            claimId: claim.claim_id,
            paymentId: payment.id,
            status: 'Processing',
            amount: Number(payment.total_amount),
            currency: payment.currency,
          };
        });

        span.setAttribute('payment_id', result.paymentId);
        span.setAttribute('amount', result.amount);

        // 5. Publish Event
        await this.rabbitMQPublisher.publish(
          'tripaxis.events.topic',
          PAYMENT_EVENTS.INITIATED,
          {
            payment_id: result.paymentId,
            claim_id: claim.id,
            tenant_id: tenantId,
            amount: result.amount,
            currency: result.currency,
            initiated_by: actorId,
          }
        );

        // 6. Record Metrics
        this.paymentInitiatedTotal.inc({ tenant_id: tenantId });
        span.setStatus({ code: SpanStatusCode.OK });

        return {
          claimId: result.claimId,
          paymentId: result.paymentId,
          status: result.status,
        };

      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }

  async completePayment(tenantId: string, actorId: string, paymentId: string, status: 'Paid' | 'Failed') {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('completePayment', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('payment_id', paymentId);
        span.setAttribute('status', status);

        // 1. Fetch Payment
        const payment = await this.rlsClient.paymentRun.findFirst({
          where: { id: paymentId, tenant_id: tenantId },
        });

        if (!payment) {
          throw new HttpException({ code: 'PAYMENT_NOT_FOUND', message: 'Payment not found' }, HttpStatus.NOT_FOUND);
        }

        if (payment.status !== PaymentRunStatus.PROCESSING) {
          throw new HttpException({ code: 'PAYMENT_ALREADY_COMPLETED', message: `Payment is already in status ${payment.status}` }, HttpStatus.CONFLICT);
        }

        // 2. Fetch Associated Claim (Assuming 1:1 for this simplified example)
        // In a real system, we'd query a join table. Here we find the claim in PROCESSING_PAYMENT for this subsidiary.
        // For robustness in this mock, we'll just find the first claim in PROCESSING_PAYMENT.
        const claim = await this.rlsClient.expenseClaim.findFirst({
          where: { tenant_id: tenantId, status: ExpenseClaimStatus.PROCESSING_PAYMENT },
        });

        if (!claim) {
           throw new HttpException({ code: 'CLAIM_NOT_FOUND', message: 'Associated claim not found or not in processing state' }, HttpStatus.NOT_FOUND);
        }

        // 3. Validate Status Transition via State Machine
        const newPaymentStatus = status === 'Paid' ? PaymentRunStatus.COMPLETED : PaymentRunStatus.FAILED;
        const newClaimStatus = status === 'Paid' ? ExpenseStatus.Paid : ExpenseStatus.PaymentFailed;
        
        assertValidTransition(claim.status as ExpenseStatus, newClaimStatus);

        // 4. Execute Transaction
        const result = await this.rlsClient.$transaction(async (tx: any) => {
          // Update Payment
          const { count: paymentCount } = await tx.paymentRun.updateMany({
            where: { id: paymentId, tenant_id: tenantId, status: PaymentRunStatus.PROCESSING },
            data: {
              status: newPaymentStatus,
              completed_at: new Date(),
            },
          });

          if (paymentCount === 0) {
             throw new HttpException({ code: 'PAYMENT_ALREADY_COMPLETED', message: 'Payment was modified concurrently' }, HttpStatus.CONFLICT);
          }

          // Update Claim
          const { count: claimCount } = await tx.expenseClaim.updateMany({
            where: { id: claim.id, tenant_id: tenantId, version: claim.version },
            data: {
              status: newClaimStatus,
              version: { increment: 1 },
              // If we had a paid_at column, we'd set it here.
            },
          });

          if (claimCount === 0) {
             throw new HttpException({ code: 'CONCURRENT_MODIFICATION', message: 'Claim was modified concurrently' }, HttpStatus.CONFLICT);
          }

          // Write Immutable Audit Record
          await tx.$executeRawUnsafe(`
            INSERT INTO expense_audit_logs (id, tenant_id, claim_id, actor_id, action, previous_status, new_status, details, created_at)
            VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7::jsonb, NOW())
          `, tenantId, claim.id, actorId, status === 'Paid' ? 'ExpensePaid' : 'ExpensePaymentFailed', claim.status, newClaimStatus, JSON.stringify({ payment_id: payment.id }));

          return {
            claimId: claim.claim_id,
            paymentId: payment.id,
            status: status,
            amount: Number(payment.total_amount),
            currency: payment.currency,
          };
        });

        // 4. Publish Event
        const eventName = status === 'Paid' ? PAYMENT_EVENTS.PAID : PAYMENT_EVENTS.FAILED;
        await this.rabbitMQPublisher.publish(
          'tripaxis.events.topic',
          eventName,
          {
            payment_id: paymentId,
            claim_id: claim.id,
            tenant_id: tenantId,
            amount: result.amount,
            currency: result.currency,
            [status === 'Paid' ? 'paid_at' : 'failed_at']: new Date().toISOString(),
          }
        );

        // 5. Record Metrics
        this.paymentCompletedTotal.inc({ tenant_id: tenantId, status: status });
        span.setStatus({ code: SpanStatusCode.OK });

        return {
          claimId: result.claimId,
          paymentId: result.paymentId,
          status: result.status,
        };

      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }
}
