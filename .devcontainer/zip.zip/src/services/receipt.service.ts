import { Injectable, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { PrismaClient, ExpenseClaimStatus } from '@prisma/client';
import { S3Service } from '../infrastructure/s3.service';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { GenerateUploadUrlDto, ConfirmUploadDto } from '../dto/receipt.dto';
import { EXPENSE_EVENTS } from '../events/expense.events';
import { trace, SpanStatusCode } from '@opentelemetry/api';
import { Counter } from 'prom-client';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class ReceiptService {
  private readonly logger = new Logger(ReceiptService.name);
  private readonly receiptUploadTotal: Counter<string>;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly s3Service: S3Service,
    private readonly rabbitMQPublisher: RabbitMQPublisherService,
  ) {
    this.receiptUploadTotal = new Counter({
      name: 'tripaxis_receipt_upload_total',
      help: 'Total number of confirmed receipt uploads',
      labelNames: ['tenant_id'],
    });
  }

  private get rlsClient() {
    return (this.prisma as any).rlsClient || this.prisma;
  }

  async generateUploadUrl(tenantId: string, employeeId: string, claimId: string, dto: GenerateUploadUrlDto) {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('generateUploadUrl', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('claim_id', claimId);

        // 1. Validate Claim
        const claim = await this.rlsClient.expenseClaim.findFirst({
          where: { id: claimId, tenant_id: tenantId },
        });

        if (!claim) {
          throw new HttpException({ code: 'CLAIM_NOT_FOUND', message: 'Claim not found' }, HttpStatus.NOT_FOUND);
        }

        if (claim.employee_id !== employeeId) {
          throw new HttpException({ code: 'NOT_CLAIM_OWNER', message: 'You can only upload receipts for your own claims' }, HttpStatus.FORBIDDEN);
        }

        const validStatuses = [ExpenseClaimStatus.DRAFT, 'SENT_BACK' as any];
        if (!validStatuses.includes(claim.status)) {
          throw new HttpException({ code: 'INVALID_CLAIM_STATUS', message: `Cannot upload receipt for claim in status ${claim.status}` }, HttpStatus.CONFLICT);
        }

        // 2. Generate S3 Key
        const sanitizedFileName = dto.fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
        const s3Key = `${tenantId}/claims/${claim.id}/receipts/${uuidv4()}-${sanitizedFileName}`;

        // 3. Generate Presigned URL
        const expiresIn = 600; // 10 minutes
        const uploadUrl = await this.s3Service.generatePresignedUrl(s3Key, dto.contentType, expiresIn);

        // 4. Store Temporary Upload Record
        await this.rlsClient.$executeRawUnsafe(`
          INSERT INTO receipt_uploads (id, tenant_id, claim_id, s3_key, sha256_hash, file_size, content_type, status, created_at)
          VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6, 'PendingUpload', NOW())
        `, tenantId, claim.id, s3Key, dto.sha256Hash, dto.fileSize, dto.contentType);

        span.setStatus({ code: SpanStatusCode.OK });

        return {
          uploadUrl,
          s3Key,
          expiresIn,
        };
      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }

  async confirmUpload(tenantId: string, employeeId: string, claimId: string, dto: ConfirmUploadDto) {
    const tracer = trace.getTracer('tripaxis-expense-service');
    return tracer.startActiveSpan('confirmUpload', async (span) => {
      try {
        span.setAttribute('tenant_id', tenantId);
        span.setAttribute('claim_id', claimId);
        span.setAttribute('s3_key', dto.s3Key);

        // 1. Validate Claim Ownership
        const claim = await this.rlsClient.expenseClaim.findFirst({
          where: { id: claimId, tenant_id: tenantId },
        });

        if (!claim) {
          throw new HttpException({ code: 'CLAIM_NOT_FOUND', message: 'Claim not found' }, HttpStatus.NOT_FOUND);
        }

        if (claim.employee_id !== employeeId) {
          throw new HttpException({ code: 'NOT_CLAIM_OWNER', message: 'You can only confirm receipts for your own claims' }, HttpStatus.FORBIDDEN);
        }

        // 2. Validate Upload Record
        const uploadRecords: any[] = await this.rlsClient.$queryRawUnsafe(`
          SELECT * FROM receipt_uploads 
          WHERE tenant_id = $1 AND claim_id = $2 AND s3_key = $3 AND status = 'PendingUpload'
        `, tenantId, claim.id, dto.s3Key);

        if (!uploadRecords || uploadRecords.length === 0) {
          throw new HttpException({ code: 'UPLOAD_RECORD_NOT_FOUND', message: 'Pending upload record not found' }, HttpStatus.NOT_FOUND);
        }
        const uploadRecord = uploadRecords[0];

        // 3. Verify S3 Object
        let s3Metadata;
        try {
          s3Metadata = await this.s3Service.headObject(dto.s3Key);
        } catch (error) {
          throw new HttpException({ code: 'S3_VALIDATION_FAILED', message: 'Failed to verify object in S3' }, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (s3Metadata.contentLength !== uploadRecord.file_size) {
          throw new HttpException({ code: 'FILE_TOO_LARGE', message: 'Uploaded file size does not match requested size' }, HttpStatus.BAD_REQUEST);
        }

        if (s3Metadata.contentType !== uploadRecord.content_type) {
          throw new HttpException({ code: 'INVALID_FILE_TYPE', message: 'Uploaded file type does not match requested type' }, HttpStatus.BAD_REQUEST);
        }

        // 4. Execute Transaction
        await this.rlsClient.$transaction(async (tx: any) => {
          // Update Claim (optimistic locking)
          const { count } = await tx.expenseClaim.updateMany({
            where: { id: claim.id, tenant_id: tenantId, version: claim.version },
            data: { version: { increment: 1 } },
          });

          if (count === 0) {
            throw new HttpException({ code: 'CONCURRENT_MODIFICATION', message: 'Claim was modified concurrently' }, HttpStatus.CONFLICT);
          }

          // Mark Upload Record Completed
          await tx.$executeRawUnsafe(`
            UPDATE receipt_uploads SET status = 'Completed', updated_at = NOW()
            WHERE id = $1
          `, uploadRecord.id);

          // Write Immutable Audit Record
          await tx.$executeRawUnsafe(`
            INSERT INTO expense_audit_logs (id, tenant_id, claim_id, actor_id, action, details, created_at)
            VALUES (gen_random_uuid(), $1, $2, $3, 'ExpenseReceiptUploaded', $4::jsonb, NOW())
          `, tenantId, claim.id, employeeId, JSON.stringify({ s3_key: dto.s3Key }));
        });

        // 5. Publish Event
        await this.rabbitMQPublisher.publish(
          'tripaxis.events.topic',
          EXPENSE_EVENTS.RECEIPT_UPLOADED,
          {
            claim_id: claim.id,
            tenant_id: tenantId,
            s3_key: dto.s3Key,
          }
        );

        // 6. Record Metrics
        this.receiptUploadTotal.inc({ tenant_id: tenantId });
        span.setStatus({ code: SpanStatusCode.OK });

        return { receiptUploaded: true };

      } catch (error: any) {
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        throw error;
      } finally {
        span.end();
      }
    });
  }
}
