import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import * as request from 'supertest';
import { ExpenseController } from '../controllers/expense.controller';
import { ExpenseService } from '../services/expense.service';
import { ExpenseRepository } from '../repositories/expense.repository';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { ExpenseClaimStatus } from '@prisma/client';

describe('ExpenseController (e2e)', () => {
  let app: INestApplication;
  let rabbitMQPublisherService: RabbitMQPublisherService;
  let expenseRepository: ExpenseRepository;

  const mockTenantId = 'tenant-123';
  const mockEmployeeId = 'emp-456';

  // Mock Middleware to inject tenant and user
  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockEmployeeId, roles: ['Employee'] };
    next();
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [ExpenseController],
      providers: [
        ExpenseService,
        {
          provide: ExpenseRepository,
          useValue: {
            getEmployeePolicy: jest.fn().mockResolvedValue({ id: 'policy-1' }),
            getCategories: jest.fn().mockResolvedValue([{ id: 'cat-1', is_active: true, default_payable: true, default_billable: false }]),
            getSubsidiaryConfig: jest.fn().mockResolvedValue({ id: 'sub-1', base_currency: 'USD' }),
            generateClaimId: jest.fn().mockResolvedValue('EXP-2026-00001'),
            createDraftClaimWithAudit: jest.fn().mockResolvedValue({
              id: 'claim-uuid-1',
              claim_id: 'EXP-2026-00001',
              status: ExpenseClaimStatus.DRAFT,
              total_claimed: 100.0,
            }),
          },
        },
        {
          provide: RabbitMQPublisherService,
          useValue: {
            publish: jest.fn().mockResolvedValue(true),
          },
        },
        {
          provide: MetricsService,
          useValue: {
            incrementErrorCount: jest.fn(),
          },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: (context) => {
        const req = context.switchToHttp().getRequest();
        return req.user.roles.includes('Employee');
      }})
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    rabbitMQPublisherService = app.get<RabbitMQPublisherService>(RabbitMQPublisherService);
    expenseRepository = app.get<ExpenseRepository>(ExpenseRepository);
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses (POST) - Success', async () => {
    const payload = {
      claimType: 'STANDALONE',
      lineItems: [
        {
          categoryId: 'cat-1',
          expenseDate: '2026-02-25T10:00:00Z',
          merchantName: 'Uber',
          amountOriginal: 100,
          currencyOriginal: 'USD',
        },
      ],
    };

    const response = await request(app.getHttpServer())
      .post('/api/expenses')
      .send(payload)
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.claimId).toBe('EXP-2026-00001');
    expect(response.body.data.status).toBe('DRAFT');
    
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.draft_created.v1',
      expect.objectContaining({
        claim_id: 'claim-uuid-1',
        tenant_id: mockTenantId,
        employee_id: mockEmployeeId,
      })
    );
  });

  it('/api/expenses (POST) - Validation Error (Missing trId for TravelLinked)', async () => {
    const payload = {
      claimType: 'TRAVEL_LINKED',
      lineItems: [
        {
          categoryId: 'cat-1',
          expenseDate: '2026-02-25T10:00:00Z',
          merchantName: 'Uber',
          amountOriginal: 100,
          currencyOriginal: 'USD',
        },
      ],
    };

    const response = await request(app.getHttpServer())
      .post('/api/expenses')
      .send(payload)
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('BAD_REQUEST');
    expect(response.body.error.details[0].message).toBe('TravelLinked claims require a trId');
  });

  it('/api/expenses (POST) - Category Not Found', async () => {
    jest.spyOn(expenseRepository, 'getCategories').mockResolvedValueOnce([]);

    const payload = {
      claimType: 'STANDALONE',
      lineItems: [
        {
          categoryId: 'invalid-cat',
          expenseDate: '2026-02-25T10:00:00Z',
          merchantName: 'Uber',
          amountOriginal: 100,
          currencyOriginal: 'USD',
        },
      ],
    };

    const response = await request(app.getHttpServer())
      .post('/api/expenses')
      .send(payload)
      .expect(404);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('CATEGORY_NOT_FOUND');
  });
});
