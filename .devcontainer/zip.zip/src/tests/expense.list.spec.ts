import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { ExpenseListController } from '../controllers/expense-list.controller';
import { ExpenseListService } from '../services/expense-list.service';
import { PrismaClient, ExpenseClaimStatus, ClaimType } from '@prisma/client';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { CursorPaginationHelper } from '../common/utils/pagination.helper';

describe('ExpenseListController (e2e)', () => {
  let app: INestApplication;
  let prismaClient: PrismaClient;

  const mockTenantId = 'tenant-123';
  const mockEmployeeId = 'emp-456';

  let mockRoles = ['Employee'];

  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockEmployeeId, roles: mockRoles };
    next();
  };

  const mockFindMany = jest.fn();

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [ExpenseListController],
      providers: [
        ExpenseListService,
        {
          provide: PrismaClient,
          useValue: {
            expenseClaim: {
              findMany: mockFindMany,
            },
          },
        },
        {
          provide: MetricsService,
          useValue: {
            incrementErrorCount: jest.fn(),
            startTimer: jest.fn().mockReturnValue(jest.fn()),
            incrementRequestCount: jest.fn(),
          },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: () => true }) // Bypass for these tests, we test role logic in service
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    prismaClient = app.get<PrismaClient>(PrismaClient);
  });

  afterEach(() => {
    jest.clearAllMocks();
    mockRoles = ['Employee']; // Reset to default
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses (GET) - Employee Isolation', async () => {
    mockFindMany.mockResolvedValueOnce([
      {
        id: 'uuid-1',
        claim_id: 'EXP-001',
        status: ExpenseClaimStatus.DRAFT,
        claim_type: ClaimType.STANDALONE,
        total_claimed: 100,
        base_currency: 'USD',
        created_at: new Date('2026-01-01T00:00:00Z'),
      }
    ]);

    const response = await request(app.getHttpServer())
      .get('/api/expenses')
      .expect(200);

    expect(response.body.success).toBe(true);
    expect(response.body.data.length).toBe(1);
    
    // Verify Prisma was called with strict tenant and employee filters
    expect(mockFindMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({
        tenant_id: mockTenantId,
        deleted_at: null,
        AND: expect.arrayContaining([
          { employee_id: mockEmployeeId }
        ])
      }),
      take: 21, // default pageSize 20 + 1
    }));
  });

  it('/api/expenses (GET) - Finance Scope Restriction', async () => {
    mockRoles = ['Finance'];

    mockFindMany.mockResolvedValueOnce([]);

    await request(app.getHttpServer())
      .get('/api/expenses')
      .expect(200);

    // Verify Prisma was called with Finance status restrictions
    expect(mockFindMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({
        AND: expect.arrayContaining([
          {
            status: {
              in: ['APPROVED', 'PARTIALLY_APPROVED', 'PROCESSING_PAYMENT', 'PAID']
            }
          }
        ])
      })
    }));
  });

  it('/api/expenses (GET) - SaaSAdmin Denied', async () => {
    mockRoles = ['SaaSAdmin'];

    const response = await request(app.getHttpServer())
      .get('/api/expenses')
      .expect(403);

    expect(response.body.success).toBe(false);
    expect(response.body.error.message).toBe('SaaSAdmin must use the Admin service to view tenant data');
  });

  it('/api/expenses (GET) - Pagination Next Cursor Generation', async () => {
    // Mock returning 3 items when pageSize is 2
    mockFindMany.mockResolvedValueOnce([
      { id: 'uuid-1', claim_id: 'EXP-001', created_at: new Date('2026-01-03T00:00:00Z') },
      { id: 'uuid-2', claim_id: 'EXP-002', created_at: new Date('2026-01-02T00:00:00Z') },
      { id: 'uuid-3', claim_id: 'EXP-003', created_at: new Date('2026-01-01T00:00:00Z') }, // This is the +1 record
    ]);

    const response = await request(app.getHttpServer())
      .get('/api/expenses?pageSize=2')
      .expect(200);

    expect(response.body.data.length).toBe(2); // Should only return 2
    expect(response.body.meta.pageSize).toBe(2);
    expect(response.body.meta.nextCursor).toBeDefined();

    // Verify the cursor encodes the 3rd item (uuid-3)
    const decodedCursor = CursorPaginationHelper.decodeCursor(response.body.meta.nextCursor);
    expect(decodedCursor?.id).toBe('uuid-3');
  });

  it('/api/expenses (GET) - Invalid Date Range Validation', async () => {
    const response = await request(app.getHttpServer())
      .get('/api/expenses?fromDate=2026-12-31T00:00:00Z&toDate=2026-01-01T00:00:00Z')
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.details[0].message).toBe('fromDate cannot be after toDate');
  });
});
