import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { ExpenseController } from '../controllers/expense.controller';
import { ExpenseService } from '../services/expense.service';
import { PrismaClient, ExpenseClaimStatus, ApprovalStatus } from '@prisma/client';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { ApprovalWorkflowService } from '../workflows/approval.service';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';
import { PolicyGrpcClient } from '../integrations/policy.client';

describe('ExpenseController - Reject (e2e)', () => {
  let app: INestApplication;
  let prismaClient: any;
  let rabbitMQPublisherService: RabbitMQPublisherService;

  const mockTenantId = 'tenant-123';
  const mockApproverId = 'manager-456';

  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockApproverId, roles: ['Manager'] };
    next();
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [ExpenseController],
      providers: [
        ExpenseService,
        {
          provide: PrismaClient,
          useValue: {
            rlsClient: {
              expenseClaim: {
                findFirst: jest.fn(),
                updateMany: jest.fn(),
              },
              $transaction: jest.fn((callback) => callback({
                expenseClaim: { updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
                claimApprovalStep: { updateMany: jest.fn() },
                $executeRawUnsafe: jest.fn(),
              })),
            }
          },
        },
        {
          provide: RabbitMQPublisherService,
          useValue: { publish: jest.fn().mockResolvedValue(true) },
        },
        {
          provide: ApprovalWorkflowService,
          useValue: { closeWorkflow: jest.fn() },
        },
        {
          provide: PolicyGrpcClient,
          useValue: {},
        },
        {
          provide: MetricsService,
          useValue: { incrementErrorCount: jest.fn() },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: () => true })
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    prismaClient = app.get<PrismaClient>(PrismaClient);
    rabbitMQPublisherService = app.get<RabbitMQPublisherService>(RabbitMQPublisherService);
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses/:id/reject (POST) - Reject Flow', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      claim_id: 'EXP-001',
      tenant_id: mockTenantId,
      employee_id: 'emp-111',
      status: ExpenseClaimStatus.SUBMITTED,
      version: 1,
      approval_steps: [
        { id: 'step-1', step_number: 1, status: ApprovalStatus.PENDING, approver_id: mockApproverId },
      ],
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/reject')
      .send({ action: 'Reject', reason: 'Out of policy' })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.status).toBe('Rejected');
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.rejected.v1',
      expect.objectContaining({ action: 'Reject', reason: 'Out of policy' })
    );
  });

  it('/api/expenses/:id/reject (POST) - SendBack Flow', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      claim_id: 'EXP-001',
      tenant_id: mockTenantId,
      employee_id: 'emp-111',
      status: ExpenseClaimStatus.SUBMITTED,
      version: 1,
      approval_steps: [
        { id: 'step-1', step_number: 1, status: ApprovalStatus.PENDING, approver_id: mockApproverId },
      ],
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/reject')
      .send({ action: 'SendBack', reason: 'Missing receipt' })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.status).toBe('SentBack');
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.sent_back.v1',
      expect.objectContaining({ action: 'SendBack', reason: 'Missing receipt' })
    );
  });

  it('/api/expenses/:id/reject (POST) - Self Action Blocked', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: mockApproverId, // Same as actor
      status: ExpenseClaimStatus.SUBMITTED,
      approval_steps: [
        { id: 'step-1', step_number: 1, status: ApprovalStatus.PENDING, approver_id: mockApproverId },
      ],
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/reject')
      .send({ action: 'Reject', reason: 'Test' })
      .expect(403);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('FORBIDDEN');
  });

  it('/api/expenses/:id/reject (POST) - Wrong Approver Blocked', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: 'emp-111',
      status: ExpenseClaimStatus.SUBMITTED,
      approval_steps: [
        { id: 'step-1', step_number: 1, status: ApprovalStatus.PENDING, approver_id: 'different-manager' },
      ],
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/reject')
      .send({ action: 'Reject', reason: 'Test' })
      .expect(403);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('FORBIDDEN');
  });
});
