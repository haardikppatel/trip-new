import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { ExpenseController } from '../controllers/expense.controller';
import { ExpenseService } from '../services/expense.service';
import { PrismaClient, ExpenseClaimStatus, ClaimType } from '@prisma/client';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { PolicyGrpcClient } from '../integrations/policy.client';
import { ApprovalWorkflowService } from '../workflows/approval.service';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';

describe('ExpenseController - Submit (e2e)', () => {
  let app: INestApplication;
  let prismaClient: any;
  let rabbitMQPublisherService: RabbitMQPublisherService;

  const mockTenantId = 'tenant-123';
  const mockEmployeeId = 'emp-456';

  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockEmployeeId, roles: ['Employee'] };
    next();
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [ExpenseController],
      providers: [
        ExpenseService,
        {
          provide: PrismaClient,
          useValue: {
            rlsClient: {
              expenseClaim: {
                findFirst: jest.fn(),
                updateMany: jest.fn(),
              },
              $transaction: jest.fn((callback) => callback({
                expenseClaim: { updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
                claimApprovalStep: { createMany: jest.fn() },
                $executeRawUnsafe: jest.fn(),
              })),
            }
          },
        },
        {
          provide: RabbitMQPublisherService,
          useValue: { publish: jest.fn().mockResolvedValue(true) },
        },
        {
          provide: PolicyGrpcClient,
          useValue: { validateExpensePolicy: jest.fn().mockResolvedValue({ policyStatus: 'OK', violations: [] }) },
        },
        {
          provide: ApprovalWorkflowService,
          useValue: { generateInitialWorkflow: jest.fn() },
        },
        {
          provide: MetricsService,
          useValue: { incrementErrorCount: jest.fn() },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: () => true })
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    prismaClient = app.get<PrismaClient>(PrismaClient);
    rabbitMQPublisherService = app.get<RabbitMQPublisherService>(RabbitMQPublisherService);
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses/:id/submit (POST) - Success', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      claim_id: 'EXP-001',
      tenant_id: mockTenantId,
      employee_id: mockEmployeeId,
      status: ExpenseClaimStatus.DRAFT,
      claim_type: ClaimType.STANDALONE,
      version: 1,
      total_claimed: 100,
      line_items: [{ id: 'li-1', category_id: 'cat-1', amount_original: 100 }],
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/submit')
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.status).toBe('Submitted');
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.submitted.v1',
      expect.any(Object)
    );
  });

  it('/api/expenses/:id/submit (POST) - Not Claim Owner', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: 'different-emp',
      status: ExpenseClaimStatus.DRAFT,
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/submit')
      .expect(403);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('FORBIDDEN');
    expect(response.body.error.message).toBe('You can only submit your own claims');
  });

  it('/api/expenses/:id/submit (POST) - Invalid Status Transition', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: mockEmployeeId,
      status: ExpenseClaimStatus.APPROVED,
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/submit')
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('BAD_REQUEST');
    expect(response.body.error.message).toContain('Cannot submit claim in status APPROVED');
  });
});
