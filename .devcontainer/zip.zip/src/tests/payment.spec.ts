import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { PaymentController } from '../controllers/payment.controller';
import { PaymentService } from '../services/payment.service';
import { PrismaClient, ExpenseClaimStatus, PaymentRunStatus } from '@prisma/client';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';

describe('PaymentController (e2e)', () => {
  let app: INestApplication;
  let prismaClient: any;
  let rabbitMQPublisherService: RabbitMQPublisherService;

  const mockTenantId = 'tenant-123';
  const mockFinanceId = 'finance-456';

  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockFinanceId, roles: ['Finance'] };
    next();
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [PaymentController],
      providers: [
        PaymentService,
        {
          provide: PrismaClient,
          useValue: {
            rlsClient: {
              expenseClaim: {
                findFirst: jest.fn(),
                updateMany: jest.fn(),
              },
              paymentRun: {
                create: jest.fn(),
                findFirst: jest.fn(),
                updateMany: jest.fn(),
              },
              $transaction: jest.fn((callback) => callback({
                expenseClaim: { updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
                paymentRun: { 
                  create: jest.fn().mockResolvedValue({ id: 'payment-123', total_amount: 100, currency: 'USD' }),
                  updateMany: jest.fn().mockResolvedValue({ count: 1 })
                },
                $executeRawUnsafe: jest.fn(),
              })),
            }
          },
        },
        {
          provide: RabbitMQPublisherService,
          useValue: { publish: jest.fn().mockResolvedValue(true) },
        },
        {
          provide: MetricsService,
          useValue: { incrementErrorCount: jest.fn() },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: () => true })
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    prismaClient = app.get<PrismaClient>(PrismaClient);
    rabbitMQPublisherService = app.get<RabbitMQPublisherService>(RabbitMQPublisherService);
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses/:id/pay (POST) - Valid Initiation', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      claim_id: 'EXP-001',
      tenant_id: mockTenantId,
      status: ExpenseClaimStatus.APPROVED,
      version: 1,
      total_approved: 100,
      base_currency: 'USD',
      subsidiary_id: 'sub-1',
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/pay')
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.status).toBe('Processing');
    expect(response.body.data.paymentId).toBe('payment-123');
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.payment_initiated.v1',
      expect.any(Object)
    );
  });

  it('/api/expenses/:id/pay (POST) - Invalid Status Transition', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      status: ExpenseClaimStatus.SUBMITTED, // Not APPROVED
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/pay')
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('BAD_REQUEST');
  });

  it('/api/payments/:paymentId/complete (POST) - Payment Success', async () => {
    prismaClient.rlsClient.paymentRun.findFirst.mockResolvedValueOnce({
      id: 'payment-123',
      tenant_id: mockTenantId,
      status: PaymentRunStatus.PROCESSING,
    });

    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      claim_id: 'EXP-001',
      tenant_id: mockTenantId,
      status: ExpenseClaimStatus.PROCESSING_PAYMENT,
      version: 2,
    });

    const response = await request(app.getHttpServer())
      .post('/api/payments/payment-123/complete')
      .send({ status: 'Paid' })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.status).toBe('Paid');
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.paid.v1',
      expect.any(Object)
    );
  });

  it('/api/payments/:paymentId/complete (POST) - Payment Already Completed', async () => {
    prismaClient.rlsClient.paymentRun.findFirst.mockResolvedValueOnce({
      id: 'payment-123',
      tenant_id: mockTenantId,
      status: PaymentRunStatus.COMPLETED, // Already completed
    });

    const response = await request(app.getHttpServer())
      .post('/api/payments/payment-123/complete')
      .send({ status: 'Paid' })
      .expect(409);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('CONFLICT');
  });
});
