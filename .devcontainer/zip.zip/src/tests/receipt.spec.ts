import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import { ReceiptController } from '../controllers/receipt.controller';
import { ReceiptService } from '../services/receipt.service';
import { PrismaClient, ExpenseClaimStatus } from '@prisma/client';
import { S3Service } from '../infrastructure/s3.service';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { MetricsService } from '../infrastructure/observability/metrics.service';
import { RolesGuard } from '../common/guards/roles.guard';
import { GlobalResponseInterceptor } from '../common/interceptors/response.interceptor';
import { GlobalExceptionFilter } from '../common/filters/global-exception.filter';

describe('ReceiptController (e2e)', () => {
  let app: INestApplication;
  let prismaClient: any;
  let s3Service: S3Service;
  let rabbitMQPublisherService: RabbitMQPublisherService;

  const mockTenantId = 'tenant-123';
  const mockEmployeeId = 'emp-456';

  const mockAuthMiddleware = (req: any, res: any, next: any) => {
    req.tenantId = mockTenantId;
    req.user = { sub: mockEmployeeId, roles: ['Employee'] };
    next();
  };

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      controllers: [ReceiptController],
      providers: [
        ReceiptService,
        {
          provide: PrismaClient,
          useValue: {
            rlsClient: {
              expenseClaim: {
                findFirst: jest.fn(),
                updateMany: jest.fn(),
              },
              $queryRawUnsafe: jest.fn(),
              $executeRawUnsafe: jest.fn(),
              $transaction: jest.fn((callback) => callback({
                expenseClaim: { updateMany: jest.fn().mockResolvedValue({ count: 1 }) },
                $executeRawUnsafe: jest.fn(),
              })),
            }
          },
        },
        {
          provide: S3Service,
          useValue: {
            generatePresignedUrl: jest.fn().mockResolvedValue('https://s3.mock/upload'),
            headObject: jest.fn(),
          },
        },
        {
          provide: RabbitMQPublisherService,
          useValue: { publish: jest.fn().mockResolvedValue(true) },
        },
        {
          provide: MetricsService,
          useValue: { incrementErrorCount: jest.fn() },
        },
      ],
    })
      .overrideGuard(RolesGuard)
      .useValue({ canActivate: () => true })
      .compile();

    app = moduleFixture.createNestApplication();
    app.use(mockAuthMiddleware);
    app.useGlobalInterceptors(new GlobalResponseInterceptor());
    app.useGlobalFilters(new GlobalExceptionFilter(app.get(MetricsService)));
    await app.init();

    prismaClient = app.get<PrismaClient>(PrismaClient);
    s3Service = app.get<S3Service>(S3Service);
    rabbitMQPublisherService = app.get<RabbitMQPublisherService>(RabbitMQPublisherService);
  });

  afterAll(async () => {
    await app.close();
  });

  it('/api/expenses/:id/receipt/upload-url (POST) - Valid Flow', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: mockEmployeeId,
      status: ExpenseClaimStatus.DRAFT,
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/receipt/upload-url')
      .send({
        fileName: 'receipt.pdf',
        contentType: 'application/pdf',
        fileSize: 1024,
        sha256Hash: 'hash123',
      })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.uploadUrl).toBe('https://s3.mock/upload');
    expect(response.body.data.s3Key).toContain('tenant-123/claims/claim-123/receipts/');
  });

  it('/api/expenses/:id/receipt/upload-url (POST) - Oversized File Blocked', async () => {
    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/receipt/upload-url')
      .send({
        fileName: 'receipt.pdf',
        contentType: 'application/pdf',
        fileSize: 20 * 1024 * 1024, // 20MB
        sha256Hash: 'hash123',
      })
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.details[0].message).toBe('File size must be 10MB or less');
  });

  it('/api/expenses/:id/receipt/confirm (POST) - Valid Flow', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: mockEmployeeId,
      version: 1,
    });

    prismaClient.rlsClient.$queryRawUnsafe.mockResolvedValueOnce([{
      id: 'upload-123',
      file_size: 1024,
      content_type: 'application/pdf',
    }]);

    jest.spyOn(s3Service, 'headObject').mockResolvedValueOnce({
      contentLength: 1024,
      contentType: 'application/pdf',
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/receipt/confirm')
      .send({ s3Key: 'tenant-123/claims/claim-123/receipts/uuid-receipt.pdf' })
      .expect(201);

    expect(response.body.success).toBe(true);
    expect(response.body.data.receiptUploaded).toBe(true);
    expect(rabbitMQPublisherService.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.expense.receipt_uploaded.v1',
      expect.any(Object)
    );
  });

  it('/api/expenses/:id/receipt/confirm (POST) - Invalid Mime Blocked', async () => {
    prismaClient.rlsClient.expenseClaim.findFirst.mockResolvedValueOnce({
      id: 'claim-123',
      tenant_id: mockTenantId,
      employee_id: mockEmployeeId,
    });

    prismaClient.rlsClient.$queryRawUnsafe.mockResolvedValueOnce([{
      id: 'upload-123',
      file_size: 1024,
      content_type: 'application/pdf',
    }]);

    jest.spyOn(s3Service, 'headObject').mockResolvedValueOnce({
      contentLength: 1024,
      contentType: 'image/jpeg', // Mismatch!
    });

    const response = await request(app.getHttpServer())
      .post('/api/expenses/claim-123/receipt/confirm')
      .send({ s3Key: 'tenant-123/claims/claim-123/receipts/uuid-receipt.pdf' })
      .expect(400);

    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('BAD_REQUEST');
    expect(response.body.error.message).toBe('Uploaded file type does not match requested type');
  });
});
