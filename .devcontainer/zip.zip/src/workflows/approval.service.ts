import { Injectable } from '@nestjs/common';
import { PrismaClient, ApprovalStepType, ApprovalStatus } from '@prisma/client';

@Injectable()
export class ApprovalWorkflowService {
  constructor(private readonly prisma: PrismaClient) {}

  async generateInitialWorkflow(tx: any, tenantId: string, claimId: string, employeeId: string) {
    const managerId = 'manager-uuid-123';
    const financeId = 'finance-uuid-456';
    const now = new Date();

    await tx.claimApprovalStep.createMany({
      data: [
        {
          tenant_id: tenantId,
          claim_id: claimId,
          approver_id: managerId,
          step_type: ApprovalStepType.MANAGER,
          step_number: 1,
          status: ApprovalStatus.PENDING,
          sla_deadline: new Date(now.getTime() + 24 * 60 * 60 * 1000),
        },
        {
          tenant_id: tenantId,
          claim_id: claimId,
          approver_id: financeId,
          step_type: ApprovalStepType.FINANCE,
          step_number: 2,
          status: ApprovalStatus.PENDING,
          sla_deadline: new Date(now.getTime() + 48 * 60 * 60 * 1000),
        },
      ],
    });
  }

  async closeWorkflow(tx: any, tenantId: string, claimId: string, actorId: string, reason: string) {
    await tx.claimApprovalStep.updateMany({
      where: {
        tenant_id: tenantId,
        claim_id: claimId,
        status: ApprovalStatus.PENDING,
      },
      data: {
        status: ApprovalStatus.REJECTED,
        decided_at: new Date(),
        decided_by: actorId,
        decision: 'REJECT',
        comment: reason,
      },
    });
  }
}
