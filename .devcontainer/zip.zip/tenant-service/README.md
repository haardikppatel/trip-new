# TripAxis Tenant Service

## Folder Structure
```
/tenant-service
  /prisma
    schema.prisma
  /src
    main.ts
    app.module.ts
    /common
      /decorators
        roles.decorator.ts
      /guards
        roles.guard.ts
    /infrastructure
      /messaging
        rabbitmq.service.ts
      /prisma
        prisma.service.ts
    /tenants
      tenants.controller.ts
      tenants.service.ts
      /dto
        create-tenant.dto.ts
        update-tenant.dto.ts
  /test
    tenants.service.spec.ts
  /docs
    openapi.yaml
```
