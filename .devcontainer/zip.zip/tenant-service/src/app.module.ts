import { Module } from '@nestjs/common';
import { TenantsController } from './tenants/tenants.controller';
import { TenantsService } from './tenants/tenants.service';
import { PrismaService } from './infrastructure/prisma/prisma.service';
import { RabbitMQPublisherService } from './infrastructure/messaging/rabbitmq.service';

@Module({
  imports: [],
  controllers: [TenantsController],
  providers: [TenantsService, PrismaService, RabbitMQPublisherService],
})
export class AppModule {}
