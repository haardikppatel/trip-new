import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class RabbitMQPublisherService {
  private readonly logger = new Logger(RabbitMQPublisherService.name);

  async publish(exchange: string, routingKey: string, payload: any): Promise<boolean> {
    this.logger.log(`Publishing event to ${exchange} with key ${routingKey}`);
    // Mock implementation for RabbitMQ
    return true;
  }
}
