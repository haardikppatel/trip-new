import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { AsyncLocalStorage } from 'async_hooks';

export const tenantContext = new AsyncLocalStorage<{ tenantId: string; roles: string[] }>();

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }

  get rlsClient() {
    return this.$extends({
      query: {
        $allModels: {
          async $allOperations({ args, query }) {
            const context = tenantContext.getStore();
            const tenantId = context?.tenantId;
            const roles = context?.roles || [];

            // SaaSAdmin bypasses RLS
            if (roles.includes('SaaSAdmin')) {
              return query(args);
            }

            if (!tenantId) {
              throw new Error('Tenant context is missing. Cannot execute query.');
            }

            return (this as any).$transaction(async (tx: any) => {
              await tx.$executeRawUnsafe(
                `SELECT set_config('app.tenant_id', $1, true);`,
                tenantId
              );
              return query(args);
            });
          },
        },
      },
    });
  }
}
