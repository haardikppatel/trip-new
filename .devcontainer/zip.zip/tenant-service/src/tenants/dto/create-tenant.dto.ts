import { IsString, IsEnum, IsNotEmpty, IsOptional, MaxLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { SubscriptionPlan, TenantStatus } from '@prisma/client';

export class CreateTenantDto {
  @ApiProperty({ example: 'Acme Corp' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  name: string;

  @ApiProperty({ example: 'acme.com' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  domain: string;

  @ApiPropertyOptional({ enum: SubscriptionPlan, default: SubscriptionPlan.BASIC })
  @IsEnum(SubscriptionPlan)
  @IsOptional()
  subscription_plan?: SubscriptionPlan;

  @ApiPropertyOptional({ enum: TenantStatus, default: TenantStatus.PENDING })
  @IsEnum(TenantStatus)
  @IsOptional()
  status?: TenantStatus;
}
