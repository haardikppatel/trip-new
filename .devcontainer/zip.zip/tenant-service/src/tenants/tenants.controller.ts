import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Req } from '@nestjs/common';
import { TenantsService } from './tenants.service';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateTenantDto } from './dto/update-tenant.dto';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { Request } from 'express';
import { tenantContext } from '../infrastructure/prisma/prisma.service';

@ApiTags('Tenants')
@ApiBearerAuth('JWT-auth')
@UseGuards(RolesGuard)
@Controller('api/tenants')
export class TenantsController {
  constructor(private readonly tenantsService: TenantsService) {}

  @Post()
  @Roles('SaaSAdmin')
  @ApiOperation({ summary: 'Create a new enterprise tenant' })
  @ApiResponse({ status: 201, description: 'Tenant created successfully' })
  async create(@Body() createTenantDto: CreateTenantDto, @Req() req: Request) {
    const actorId = req['user'].sub;
    return new Promise((resolve, reject) => {
      tenantContext.run({ tenantId: req['tenantId'], roles: req['user'].roles }, () => {
        this.tenantsService.create(createTenantDto, actorId).then(resolve).catch(reject);
      });
    });
  }

  @Get()
  @Roles('SaaSAdmin')
  @ApiOperation({ summary: 'List all tenants' })
  @ApiResponse({ status: 200, description: 'List of tenants' })
  async findAll(@Req() req: Request) {
    return new Promise((resolve, reject) => {
      tenantContext.run({ tenantId: req['tenantId'], roles: req['user'].roles }, () => {
        this.tenantsService.findAll().then(resolve).catch(reject);
      });
    });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get tenant details' })
  @ApiResponse({ status: 200, description: 'Tenant details' })
  @ApiResponse({ status: 404, description: 'Tenant not found' })
  async findOne(@Param('id') id: string, @Req() req: Request) {
    const userTenantId = req['tenantId'];
    const roles = req['user'].roles || [];
    return new Promise((resolve, reject) => {
      tenantContext.run({ tenantId: userTenantId, roles }, () => {
        this.tenantsService.findOne(id, userTenantId, roles).then(resolve).catch(reject);
      });
    });
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update subscription plan or status' })
  @ApiResponse({ status: 200, description: 'Tenant updated successfully' })
  async update(@Param('id') id: string, @Body() updateTenantDto: UpdateTenantDto, @Req() req: Request) {
    const userTenantId = req['tenantId'];
    const roles = req['user'].roles || [];
    const actorId = req['user'].sub;
    return new Promise((resolve, reject) => {
      tenantContext.run({ tenantId: userTenantId, roles }, () => {
        this.tenantsService.update(id, updateTenantDto, userTenantId, roles, actorId).then(resolve).catch(reject);
      });
    });
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete a tenant (set status to suspended)' })
  @ApiResponse({ status: 200, description: 'Tenant suspended successfully' })
  async remove(@Param('id') id: string, @Req() req: Request) {
    const userTenantId = req['tenantId'];
    const roles = req['user'].roles || [];
    const actorId = req['user'].sub;
    return new Promise((resolve, reject) => {
      tenantContext.run({ tenantId: userTenantId, roles }, () => {
        this.tenantsService.remove(id, userTenantId, roles, actorId).then(resolve).catch(reject);
      });
    });
  }
}
