import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../infrastructure/prisma/prisma.service';
import { RabbitMQPublisherService } from '../infrastructure/messaging/rabbitmq.service';
import { CreateTenantDto } from './dto/create-tenant.dto';
import { UpdateTenantDto } from './dto/update-tenant.dto';
import { TenantStatus } from '@prisma/client';

@Injectable()
export class TenantsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly rabbitMQPublisher: RabbitMQPublisherService,
  ) {}

  private get rlsClient() {
    return (this.prisma as any).rlsClient || this.prisma;
  }

  async create(createTenantDto: CreateTenantDto, actorId: string) {
    const tenant = await this.rlsClient.tenant.create({
      data: createTenantDto,
    });

    await this.rabbitMQPublisher.publish('tripaxis.events.topic', 'tripaxis.tenant.created.v1', {
      tenant_id: tenant.id,
      actor_id: actorId,
      action: 'TenantCreated',
      data: tenant,
    });

    return tenant;
  }

  async findAll() {
    return this.rlsClient.tenant.findMany({
      where: { deleted_at: null },
    });
  }

  async findOne(id: string, userTenantId: string, roles: string[]) {
    if (!roles.includes('SaaSAdmin') && id !== userTenantId) {
      throw new ForbiddenException('You can only access your own tenant');
    }

    const tenant = await this.rlsClient.tenant.findFirst({
      where: { id, deleted_at: null },
    });

    if (!tenant) {
      throw new NotFoundException(`Tenant with ID ${id} not found`);
    }

    return tenant;
  }

  async update(id: string, updateTenantDto: UpdateTenantDto, userTenantId: string, roles: string[], actorId: string) {
    if (!roles.includes('SaaSAdmin') && id !== userTenantId) {
      throw new ForbiddenException('You can only update your own tenant');
    }

    const tenant = await this.findOne(id, userTenantId, roles);

    const updatedTenant = await this.rlsClient.tenant.update({
      where: { id: tenant.id },
      data: updateTenantDto,
    });

    await this.rabbitMQPublisher.publish('tripaxis.events.topic', 'tripaxis.tenant.updated.v1', {
      tenant_id: updatedTenant.id,
      actor_id: actorId,
      action: 'TenantUpdated',
      data: updatedTenant,
    });

    return updatedTenant;
  }

  async remove(id: string, userTenantId: string, roles: string[], actorId: string) {
    if (!roles.includes('SaaSAdmin') && id !== userTenantId) {
      throw new ForbiddenException('You can only delete your own tenant');
    }

    const tenant = await this.findOne(id, userTenantId, roles);

    const deletedTenant = await this.rlsClient.tenant.update({
      where: { id: tenant.id },
      data: {
        status: TenantStatus.SUSPENDED,
        deleted_at: new Date(),
      },
    });

    await this.rabbitMQPublisher.publish('tripaxis.events.topic', 'tripaxis.tenant.deleted.v1', {
      tenant_id: deletedTenant.id,
      actor_id: actorId,
      action: 'TenantDeleted',
    });

    return deletedTenant;
  }
}
