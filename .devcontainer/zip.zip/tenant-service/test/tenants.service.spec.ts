import { describe, it, expect, beforeEach, vi } from 'vitest';
import { TenantsService } from '../src/tenants/tenants.service';
import { TenantStatus, SubscriptionPlan } from '@prisma/client';

describe('TenantsService', () => {
  let service: TenantsService;
  let mockPrisma: any;
  let mockRabbitMQ: any;

  beforeEach(() => {
    mockPrisma = {
      rlsClient: {
        tenant: {
          create: vi.fn(),
          findMany: vi.fn(),
          findFirst: vi.fn(),
          update: vi.fn(),
        },
      },
    };

    mockRabbitMQ = {
      publish: vi.fn(),
    };

    service = new TenantsService(mockPrisma as any, mockRabbitMQ as any);
  });

  it('should create a tenant', async () => {
    const dto = { name: 'Test', domain: 'test.com' };
    const mockTenant = { id: '1', ...dto, status: TenantStatus.PENDING, subscription_plan: SubscriptionPlan.BASIC };
    mockPrisma.rlsClient.tenant.create.mockResolvedValue(mockTenant);

    const result = await service.create(dto, 'admin-1');

    expect(result).toEqual(mockTenant);
    expect(mockRabbitMQ.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.tenant.created.v1',
      expect.objectContaining({ tenant_id: '1', action: 'TenantCreated' })
    );
  });

  it('should find one tenant if SaaSAdmin', async () => {
    const mockTenant = { id: '1', name: 'Test' };
    mockPrisma.rlsClient.tenant.findFirst.mockResolvedValue(mockTenant);

    const result = await service.findOne('1', 'other-tenant', ['SaaSAdmin']);
    expect(result).toEqual(mockTenant);
  });

  it('should forbid finding another tenant if not SaaSAdmin', async () => {
    await expect(service.findOne('1', '2', ['Employee'])).rejects.toThrow('You can only access your own tenant');
  });

  it('should soft delete a tenant', async () => {
    const mockTenant = { id: '1', name: 'Test' };
    mockPrisma.rlsClient.tenant.findFirst.mockResolvedValue(mockTenant);
    mockPrisma.rlsClient.tenant.update.mockResolvedValue({ ...mockTenant, status: TenantStatus.SUSPENDED });

    const result = await service.remove('1', '1', ['TenantAdmin'], 'actor-1');
    expect(result.status).toBe(TenantStatus.SUSPENDED);
    expect(mockRabbitMQ.publish).toHaveBeenCalledWith(
      'tripaxis.events.topic',
      'tripaxis.tenant.deleted.v1',
      expect.objectContaining({ tenant_id: '1', action: 'TenantDeleted' })
    );
  });
});
