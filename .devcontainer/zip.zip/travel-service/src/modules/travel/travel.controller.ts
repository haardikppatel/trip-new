import { Controller, Post, Body, Param, UseGuards } from '@nestjs/common';
import { TravelService } from './travel.service';
import { ApiResponse, TenantContext } from '@tripaxis/core';
import { TenantGuard } from '../../common/guards/tenant.guard';

@UseGuards(TenantGuard)
@Controller('v1/travel')
export class TravelController {
  constructor(private readonly travelService: TravelService) {}

  @Post('submit')
  async submit(@Body() dto: any) {
    const result = await this.travelService.submitRequest(dto);
    return ApiResponse.success(result);
  }

  @Post(':id/approve')
  async approve(@Param('id') id: string, @Body('reason') reason?: string) {
    const result = await this.travelService.approveRequest(id, reason);
    return ApiResponse.success(result);
  }
}
