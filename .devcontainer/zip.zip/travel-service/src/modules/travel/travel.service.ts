import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaClient, TravelStatus } from '@prisma/client';
import { TenantContext, InvalidStateTransitionError } from '@tripaxis/core';
import { EventPublisher } from '../../infrastructure/events/event.publisher';

@Injectable()
export class TravelService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly eventPublisher: EventPublisher,
  ) {}

  async submitRequest(dto: any) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();

    // 1. Policy Validation (Mocked sync call or internal logic)
    // const policyCheck = await this.policyClient.validate(...);
    // if (!policyCheck.valid) throw new PolicyViolationError(...);

    // 2. Create Request & Legs in Transaction
    const request = await this.prisma.$transaction(async (tx) => {
      const tr = await tx.travelRequest.create({
        data: {
          tenantId,
          userId,
          purpose: dto.purpose,
          totalBudget: dto.totalBudget,
          currency: dto.currency,
          status: TravelStatus.PENDING_APPROVAL,
          legs: {
            create: dto.legs.map((leg: any) => ({
              tenantId,
              origin: leg.origin,
              destination: leg.destination,
              departureDate: new Date(leg.departureDate),
              returnDate: leg.returnDate ? new Date(leg.returnDate) : null,
              transportMode: leg.transportMode,
              estimatedCost: leg.estimatedCost,
            })),
          },
        },
        include: { legs: true },
      });

      // 3. Audit Log
      await tx.travelAuditLog.create({
        data: {
          tenantId,
          travelRequestId: tr.id,
          action: 'SUBMITTED',
          changedBy: userId,
          previousStatus: TravelStatus.DRAFT,
          newStatus: TravelStatus.PENDING_APPROVAL,
          reason: 'Initial submission',
        },
      });

      return tr;
    });

    // 4. Emit Event
    await this.eventPublisher.publish('TravelRequestSubmitted:v1', {
      travelRequestId: request.id,
      userId,
      totalBudget: request.totalBudget,
    });

    return request;
  }

  async approveRequest(id: string, reason?: string) {
    const tenantId = TenantContext.getTenantId();
    const userId = TenantContext.getUserId();

    const request = await this.prisma.travelRequest.findUnique({ where: { id } });
    if (!request) throw new NotFoundException('Travel request not found');
    if (request.status !== TravelStatus.PENDING_APPROVAL) {
      throw new InvalidStateTransitionError(request.status, TravelStatus.APPROVED);
    }

    const updated = await this.prisma.$transaction(async (tx) => {
      const tr = await tx.travelRequest.update({
        where: { id },
        data: { status: TravelStatus.APPROVED },
      });

      await tx.travelAuditLog.create({
        data: {
          tenantId,
          travelRequestId: tr.id,
          action: 'APPROVED',
          changedBy: userId,
          previousStatus: request.status,
          newStatus: TravelStatus.APPROVED,
          reason,
        },
      });

      return tr;
    });

    // Triggers Booking Integration
    await this.eventPublisher.publish('TravelRequestApproved:v1', {
      travelRequestId: updated.id,
      employeeId: updated.userId,
      budget: updated.totalBudget,
      currency: updated.currency,
    });

    return updated;
  }
}
