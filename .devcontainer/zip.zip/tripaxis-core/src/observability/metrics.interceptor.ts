import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Histogram, Counter } from 'prom-client';

@Injectable()
export class MetricsInterceptor implements NestInterceptor {
  private static requestDuration = new Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code', 'tenant_id'],
    buckets: [0.05, 0.1, 0.2, 0.3, 0.5, 1, 2, 5, 10], // SLA buckets (e.g., 300ms = 0.3)
  });

  private static requestCount = new Counter({
    name: 'http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method', 'route', 'status_code', 'tenant_id'],
  });

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const req = context.switchToHttp().getRequest();
    const res = context.switchToHttp().getResponse();
    
    const method = req.method;
    const route = req.route ? req.route.path : req.url;
    const tenantId = req.headers['x-tenant-id'] || 'unknown';
    
    const endTimer = MetricsInterceptor.requestDuration.startTimer();

    return next.handle().pipe(
      tap({
        next: () => {
          const statusCode = res.statusCode;
          endTimer({ method, route, status_code: statusCode, tenant_id: tenantId });
          MetricsInterceptor.requestCount.inc({ method, route, status_code: statusCode, tenant_id: tenantId });
        },
        error: (err) => {
          const statusCode = err.status || 500;
          endTimer({ method, route, status_code: statusCode, tenant_id: tenantId });
          MetricsInterceptor.requestCount.inc({ method, route, status_code: statusCode, tenant_id: tenantId });
        },
      }),
    );
  }
}
