import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { TransactionalOutboxService } from './outbox.service';

@Injectable()
export class OutboxProcessorCron {
  private readonly logger = new Logger(OutboxProcessorCron.name);

  constructor(private readonly outboxService: TransactionalOutboxService) {}

  // Run every 5 seconds to sweep the outbox table for unpublished events
  @Cron('*/5 * * * * *')
  async handleCron() {
    try {
      await this.outboxService.processOutbox();
    } catch (error) {
      this.logger.error('Error processing outbox events', error);
    }
  }
}
