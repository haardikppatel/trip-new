import { Injectable, Inject } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { ClientProxy } from '@nestjs/microservices';
import { v4 as uuidv4 } from 'uuid';

@Injectable()
export class TransactionalOutboxService {
  constructor(
    @Inject('PRISMA_CLIENT') private readonly prisma: PrismaClient,
    @Inject('RABBITMQ_SERVICE') private readonly messageBroker: ClientProxy,
  ) {}

  /**
   * Saves an event to the outbox table within the same database transaction as the business logic.
   */
  async saveEvent(tx: any, tenantId: string, correlationId: string, eventType: string, payload: any): Promise<void> {
    await tx.$executeRaw`
      INSERT INTO "event_outbox" ("id", "tenant_id", "correlation_id", "event_type", "payload", "status", "created_at")
      VALUES (${uuidv4()}::uuid, ${tenantId}::uuid, ${correlationId}::uuid, ${eventType}, ${payload}::jsonb, 'PENDING', NOW())
    `;
  }

  /**
   * Background processor to publish pending events.
   * Ensures at-least-once delivery.
   */
  async processOutbox(): Promise<void> {
    const pendingEvents = await this.prisma.$queryRaw<any[]>`
      SELECT * FROM "event_outbox" WHERE "status" = 'PENDING' ORDER BY "created_at" ASC LIMIT 100 FOR UPDATE SKIP LOCKED
    `;

    for (const event of pendingEvents) {
      try {
        // Publish to RabbitMQ
        await this.messageBroker.emit(event.event_type, {
          eventId: event.id,
          tenantId: event.tenant_id,
          correlationId: event.correlation_id,
          eventType: event.event_type,
          payload: event.payload,
          timestamp: event.created_at,
        }).toPromise();

        // Mark as published
        await this.prisma.$executeRaw`
          UPDATE "event_outbox" SET "status" = 'PUBLISHED', "published_at" = NOW() WHERE "id" = ${event.id}::uuid
        `;
      } catch (error) {
        console.error(`Failed to publish event ${event.id}`, error);
        // Will be retried on next cron execution
      }
    }
  }
}
