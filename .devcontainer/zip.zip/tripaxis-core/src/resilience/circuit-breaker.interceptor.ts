import { Injectable, NestInterceptor, ExecutionContext, CallHandler, RequestTimeoutException, ServiceUnavailableException } from '@nestjs/common';
import { Observable, throwError, TimeoutError } from 'rxjs';
import { catchError, timeout } from 'rxjs/operators';
import * as CircuitBreaker from 'opossum';

@Injectable()
export class CircuitBreakerInterceptor implements NestInterceptor {
  private static breakers: Map<string, CircuitBreaker> = new Map();

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const handlerName = context.getHandler().name;
    const className = context.getClass().name;
    const breakerKey = `${className}.${handlerName}`;

    let breaker = CircuitBreakerInterceptor.breakers.get(breakerKey);

    if (!breaker) {
      // Enterprise defaults for sync inter-service calls (e.g., Policy Service)
      const options = {
        timeout: 3000, // 3 seconds timeout
        errorThresholdPercentage: 50, // Trip if 50% of requests fail
        resetTimeout: 10000, // Wait 10s before trying again (Half-Open)
      };

      breaker = new CircuitBreaker(async (action: () => Promise<any>) => await action(), options);
      
      breaker.on('open', () => console.warn(`[CIRCUIT BREAKER OPEN] ${breakerKey} - Failing fast`));
      breaker.on('halfOpen', () => console.log(`[CIRCUIT BREAKER HALF-OPEN] ${breakerKey} - Testing downstream`));
      breaker.on('close', () => console.log(`[CIRCUIT BREAKER CLOSED] ${breakerKey} - Service recovered`));

      CircuitBreakerInterceptor.breakers.set(breakerKey, breaker);
    }

    return new Observable((observer) => {
      breaker.fire(() => next.handle().toPromise())
        .then((result) => {
          observer.next(result);
          observer.complete();
        })
        .catch((err) => {
          if (err.type === 'open') {
            observer.error(new ServiceUnavailableException('Downstream service is currently unavailable (Circuit Open)'));
          } else {
            observer.error(err);
          }
        });
    });
  }
}
