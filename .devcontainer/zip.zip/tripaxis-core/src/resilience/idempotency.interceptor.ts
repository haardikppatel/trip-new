import { Injectable, NestInterceptor, ExecutionContext, CallHandler, ConflictException, Inject } from '@nestjs/common';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Redis } from 'ioredis';

@Injectable()
export class IdempotencyInterceptor implements NestInterceptor {
  constructor(@Inject('REDIS_CLIENT') private readonly redis: Redis) {}

  async intercept(context: ExecutionContext, next: CallHandler): Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest();
    
    // For HTTP requests, use header. For events, use payload.eventId
    const idempotencyKey = request.headers['x-idempotency-key'] || request.body?.eventId || request.body?.correlationId;
    const tenantId = request.headers['x-tenant-id'] || request.body?.tenantId;

    if (!idempotencyKey || !tenantId) {
      return next.handle(); // Skip if no key provided (or enforce strictly depending on route)
    }

    const redisKey = `idempotency:${tenantId}:${idempotencyKey}`;

    // Try to acquire lock / check if exists
    const isNew = await this.redis.set(redisKey, 'PROCESSING', 'NX', 'EX', 86400); // 24 hours TTL

    if (!isNew) {
      const status = await this.redis.get(redisKey);
      if (status === 'PROCESSING') {
        throw new ConflictException('Request is already being processed');
      }
      // If completed, return cached response
      try {
        const cachedResponse = JSON.parse(status);
        return of(cachedResponse);
      } catch {
        return of({ message: 'Acknowledged (Duplicate)' }); // Fallback for events
      }
    }

    return next.handle().pipe(
      tap(async (response) => {
        // Store successful response
        await this.redis.set(redisKey, JSON.stringify(response || { success: true }), 'EX', 86400);
      }),
    );
  }
}
